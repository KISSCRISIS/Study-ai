const CACHE_VERSION = "emergency-room-parking-offline-v33";

const OFFLINE_ASSETS = [
  "./index.html",
  "./portal.html",
  "./verify.html",
  "./profile.html",
  "./login.html",
  "./admin_dashboard.html",
  "./admin-live.js",
  "./global-leadership.js",
  "./global-theme.css",
  "./access-control.js",
  "./app-runtime.js",
  "./manifest.json",
  "./qrcode.min.js",
  "./jsqr.min.js",
  "./supabase.min.js",
  "./favicon.svg",
  "./albashir-gate-logo.png",
  "./hospital-hero.png",
  "./logo.jpeg",
  "./hero.jpeg",
  "./assets/js/ui-components.js",
  "./assets/js/app-state.js",
  "./assets/css/responsive.css",
  "./assets/css/components.css",
  "./assets/css/design-system.css",
  "./index.css",
  "./verify.css",
  "./admin_dashboard.css",
  "./portal.css",
  "./profile.css",
  "./verify-shared.js",
  "./employee-photo.js",
  "./operational-snapshot.js",

  "./register.html"
];

// A failed preparation keeps the active worker and its cache. No forced takeover.
async function fetchWithDeadline(request,options={}){const target=new URL(typeof request==='string'?request:request.url,self.location.href);if(target.origin!==self.location.origin||!['https:','http:'].includes(target.protocol)||target.username||target.password||((request.method||options.method||'GET')!=='GET'))throw Error('SW_NETWORK_ORIGIN_REJECTED');const controller=new AbortController();let timer;try{return await Promise.race([(async()=>{const endpoint=new URL(self.location.origin);endpoint.pathname=target.pathname;endpoint.search=target.search;const inherited=typeof request==='string'?{}:{headers:request.headers,credentials:request.credentials,cache:request.cache,mode:request.mode==='navigate'?'same-origin':request.mode,referrer:request.referrer,referrerPolicy:request.referrerPolicy,integrity:request.integrity};const response=await fetch(endpoint.href,{...inherited,...options,signal:controller.signal,redirect:'error'});if(response.clone?.().arrayBuffer)await response.clone().arrayBuffer();return response;})(),new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(Error('SW_NETWORK_TIMEOUT'));},8000);})]);}finally{clearTimeout(timer);}}
self.addEventListener('install',event=>{event.waitUntil((async()=>{
 const prepared=await Promise.all(OFFLINE_ASSETS.map(async asset=>{const response=await fetchWithDeadline(asset,{cache:'reload'});if(!response.ok&&response.status!==200)throw Error('SW_PREPARE_FAILED');return {asset,response};}));
 const cache=await caches.open(CACHE_VERSION);for(const {asset,response}of prepared)if(cacheable(response))await cache.put(asset,response);
})());});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(key=>key.startsWith('emergency-room-parking-offline-')&&key!==CACHE_VERSION).map(key=>caches.delete(key)));await self.clients.claim();})());});
self.addEventListener('message',event=>{
 if(event.data?.type!=='ACTIVATE_SAFE_UPDATE'||event.data.confirmed!==true)return;
 const source=event.source;
 if(!source?.id||!self.clients?.get)return;
 event.waitUntil((async()=>{
  const client=await self.clients.get(source.id);
  if(!client||client.id!==source.id)return;
  try{if(new URL(client.url).origin!==self.location.origin)return;}catch(_){return;}
  await self.skipWaiting();
 })());
});
// Only these static assets may be persisted offline. Never cache URLs carrying
// QR tokens, query credentials, authenticated responses or arbitrary GET data.
const STATIC_ASSET_PATHS = new Set(OFFLINE_ASSETS.map(asset =>
  new URL(asset, self.location.href).pathname
));
const OFFLINE_PAGE_PATHS = new Set(
  OFFLINE_ASSETS.filter(asset => asset.endsWith(".html")).map(asset =>
    new URL(asset, self.location.href).pathname
  )
);
function cacheable(response) {
  const policy = response.headers?.get("cache-control") || "";
  return response.status === 200 && !/\b(?:no-store|private)\b/i.test(policy);
}
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  // Explicitly bypass Supabase auth, database, storage and edge-function traffic.
  if (url.hostname.endsWith(".supabase.co")) {
    event.respondWith(fetch(request));
    return;
  }
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/auth/") || url.pathname.startsWith("/rest/") ||
      url.pathname.startsWith("/storage/") || url.pathname.startsWith("/functions/")) return;

  if (request.mode === "navigate") {
    const isRoot = url.pathname === "/";
    const pagePath = isRoot ? new URL("./portal.html", self.location.href).pathname : url.pathname;
    // QR tokens in navigation query strings must never be persisted.
    const canCache = !url.search && OFFLINE_PAGE_PATHS.has(pagePath);
    event.respondWith(
      fetchWithDeadline(request).then(response => {
        if (canCache && cacheable(response)) {
          event.waitUntil(caches.open(CACHE_VERSION).then(cache =>
            cache.put(pagePath, response.clone())
          ).catch(error => console.warn("[SW] Page cache write failed", error)));
        }
        return response;
      }).catch(async () => {
        if (canCache || isRoot) {
          const cached = await (await caches.open(CACHE_VERSION)).match(pagePath);
          if (cached) return cached;
        }
        // Never substitute a cached page for a credential-bearing QR URL.
        return Response.error();
      })
    );
    return;
  }
  if (!url.search && STATIC_ASSET_PATHS.has(url.pathname)) {
    event.respondWith(
      fetchWithDeadline(request).then(response => {
        if (cacheable(response)) {
          event.waitUntil(caches.open(CACHE_VERSION).then(cache =>
            cache.put(url.pathname, response.clone())
          ).catch(error => console.warn("[SW] Asset cache write failed", error)));
        }
        return response;
      }).catch(async () => {
        const cached = await (await caches.open(CACHE_VERSION)).match(url.pathname);
        if (cached) return cached;
        return Response.error();
      })
    );
  }
});

self.addEventListener('push',event=>{
 event.waitUntil((async()=>{let data;try{data=event.data.json();}catch(_){return;}
 const targets=new Set(['registrations','profileChanges','violations','limits','logs','guardRequests']);
 if(typeof data.event_id!=='string'||!/^[a-f0-9-]{36}$/.test(data.event_id)||!targets.has(data.target))return;
 await self.registration.showNotification(String(data.title||'إشعار الإدارة').slice(0,100),{body:String(data.body||'').slice(0,300),tag:'admin-'+data.event_id,icon:'./icon-192.png',badge:'./icon-192.png',data:{target:data.target,event_id:data.event_id}});
 })());
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil((async()=>{
 const target=event.notification.data?.target;const allowed=new Set(['registrations','profileChanges','violations','limits','logs','guardRequests']);
 const url=new URL('./admin_dashboard.html',self.location.href);url.searchParams.set('section',allowed.has(target)?target:'notifications');
 const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});
 const existing=windows.find(w=>new URL(w.url).origin===url.origin&&new URL(w.url).pathname===url.pathname);
 if(existing){await existing.navigate(url.href);await existing.focus();}else await self.clients.openWindow(url.href);
})());});
