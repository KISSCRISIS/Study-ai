(() => {
  'use strict';
  const $ = id => document.getElementById(id), storageKey = 'alb_guard_session_v1';
  let token = '', busy = false, pending = null, emergencyEnabled = false;
  try { token = localStorage.getItem(storageKey) || ''; } catch (_) {}
  const message = text => { if ($('guardManualMessage')) $('guardManualMessage').textContent = text; };

  function isQrHealthyOnScreen() {
    return Boolean(
      typeof current !== 'undefined' &&
      current &&
      typeof current.deadline === 'number' &&
      performance.now() < current.deadline &&
      $('qr') &&
      $('qr').hidden === false
    );
  }

  function getScreenReadKeyForEntry() {
    if (typeof current === 'undefined' || !current || !current.readKey) return '';
    if (typeof current.readDeadline === 'number' && performance.now() >= current.readDeadline) return '';
    return current.readKey;
  }

  function syncEmergencyControls() {
    const qrHealthy = isQrHealthyOnScreen();
    const canEnterManually = emergencyEnabled && !qrHealthy;
    if ($('guardEmergencyToggle')) {
      $('guardEmergencyToggle').textContent = canEnterManually ? 'إيقاف وضع الطوارئ' : 'تفعيل الدخول اليدوي عند تعطل QR';
      $('guardEmergencyToggle').disabled = busy || (qrHealthy && !emergencyEnabled);
    }
    if ($('guardEntryButton')) {
      $('guardEntryButton').disabled = busy || !canEnterManually;
    }
  }

  function panelState(open) {
    document.body.classList.toggle('guard-panel-open', open);
    for (const child of document.querySelector('main').children) {
      if (!['guardManualPanel', 'result'].includes(child.id)) child.inert = open;
    }
  }

  function clearSession() {
    token = ''; pending = null; emergencyEnabled = false;
    try { localStorage.removeItem(storageKey); } catch (_) {}
    $('guardLoginForm').hidden = false; $('guardEntryForm').hidden = true;
    $('manualEmployeeId').value = ''; $('guardPhone').value = '';
    if ($('guardSessionHeader')) $('guardSessionHeader').hidden = true;
    if ($('guardAvatar')) { $('guardAvatar').hidden = true; $('guardAvatar').removeAttribute('src'); }
    syncEmergencyControls();
  }

  async function showIdentity() {
    if (!token || !$('guardSessionHeader')) return;
    try {
      const data = await rpc('guard_session_profile', { p_token: token });
      $('guardSessionName').textContent = data.full_name || 'حارس';
      $('guardSessionTime').textContent = 'وقت الدخول: ' + new Date(data.logged_in_at).toLocaleString('ar-JO', { timeZone: 'Asia/Amman' });
      $('guardAvatar').hidden = !data.photo_base64;
      if (data.photo_base64) $('guardAvatar').src = 'data:image/jpeg;base64,' + data.photo_base64.replace(/\s/g, '');
      else $('guardAvatar').removeAttribute('src');
      $('guardSessionHeader').hidden = false;
    } catch (err) { message(err.message); }
  }

  function authenticated(data) {
    $('guardLoginForm').hidden = true; $('guardEntryForm').hidden = false;
    $('guardWelcome').textContent = data.full_name ? 'مرحبًا ' + data.full_name : 'مرحبًا بك في شاشة الحارس';
    const qrHealthy = isQrHealthyOnScreen();
    emergencyEnabled = Boolean(data.emergency_enabled === true && !qrHealthy);
    syncEmergencyControls();
    if (qrHealthy) {
      message('رمز المربع (QR) يعمل الآن بشكل سليم على الشاشة. اطلب من الموظف مسح الرمز بهاتفه؛ لا يُسمح بالدخول اليدوي طالما أن الرمز يعمل.');
    } else if (emergencyEnabled) {
      message('وضع الطوارئ مفعّل الآن بسبب تعطل رمز QR. اكتب الرقم الوظيفي أو الوطني للموظف في المربع أدناه ثم اضغط (تأكيد دخول الموظف).');
      $('manualEmployeeId').focus();
    } else {
      message('عند تعطل رمز QR على الشاشة، اضغط زر (تفعيل الدخول اليدوي عند تعطل QR) ليتحقق الخادم ويفعّل الطوارئ؛ تُسجّل الزيارات وتُحتسب ضمن الحد اليومي.');
    }
  }

  async function rpc(name, payload) {
    const { data, error } = await guardRpc(name, payload, 8000);
    if (error) {
      const netErr = Error('تعذر الاتصال بالخادم. حاول مجددًا.');
      netErr.isTransportError = true;
      throw netErr;
    }
    if (data?.ok !== true) {
      if (data?.error === 'AUTH_REQUIRED') clearSession();
      if (data?.emergency_enabled === false || data?.error === 'QR_AVAILABLE' || data?.error === 'QR_NOT_FAILED') {
        emergencyEnabled = false;
        syncEmergencyControls();
      }
      const appErr = Error(data?.message || 'تعذر إكمال الطلب؛ سجل دخول الحارس مجددًا.');
      appErr.code = data?.error || 'REQUEST_REJECTED';
      throw appErr;
    }
    return data;
  }

  $('manualOpen').onclick = async () => {
    $('guardManualPanel').hidden = false; panelState(true); message('');
    if (!token) { clearSession(); $('guardIdentity').focus(); return; }
    try { authenticated(await rpc('guard_session_status', { p_token: token })); }
    catch (err) { message(err.message); }
  };

  $('manualClose').onclick = () => {
    $('guardManualPanel').hidden = true; panelState(false); $('manualEmployeeId').value = ''; $('manualOpen').focus();
  };

  $('guardManualPanel').addEventListener('keydown', event => {
    if (event.key === 'Escape') { event.preventDefault(); $('manualClose').click(); return; }
    if (event.key !== 'Tab') return;
    const controls = [...$('guardManualPanel').querySelectorAll('button,input,a,summary')].filter(e => !e.disabled && e.getClientRects().length);
    const first = controls[0], last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  });

  $('guardLoginForm').onsubmit = async event => {
    event.preventDefault(); if (busy) return;
    busy = true; $('guardLoginButton').disabled = true;
    try {
      const data = await rpc('guard_login', { p_identity: $('guardIdentity').value.trim(), p_phone: $('guardPhone').value });
      token = data.token;
      try { localStorage.setItem(storageKey, token); } catch (_) {}
      $('guardPhone').value = '';
      try {
        authenticated(await rpc('guard_session_status', { p_token: token }));
      } catch (_) {
        authenticated(data);
      }
      await showIdentity();
    } catch (err) { message(err.message); }
    finally { busy = false; $('guardLoginButton').disabled = false; syncEmergencyControls(); }
  };

  $('guardLogoutButton').onclick = async () => {
    if (busy) return;
    try { await rpc('guard_logout', { p_token: token }); clearSession(); message('تم تسجيل خروج الحارس.'); }
    catch (err) { message('تعذر إلغاء الجلسة؛ أعد محاولة الخروج عند عودة الاتصال.'); }
  };

  if ($('guardEmergencyToggle')) $('guardEmergencyToggle').onclick = async () => {
    if (busy || !token) return;
    if (!emergencyEnabled && isQrHealthyOnScreen()) {
      syncEmergencyControls();
      message('رمز المربع (QR) يعمل حاليًا بشكل سليم؛ لا يُسمح بتفعيل وضع الطوارئ إلا عند تعطل توليد الرمز.');
      return;
    }
    busy = true; syncEmergencyControls();
    try {
      const data = await rpc('guard_set_emergency', { p_token: token, p_enabled: !emergencyEnabled });
      authenticated(await rpc('guard_session_status', { p_token: token }));
      message(data.message);
    } catch (err) { message(err.message); }
    finally { busy = false; syncEmergencyControls(); }
  };

  $('guardEntryForm').onsubmit = async event => {
    event.preventDefault(); if (busy || !token) return;
    if (isQrHealthyOnScreen()) {
      emergencyEnabled = false;
      pending = null;
      syncEmergencyControls();
      message('رمز المربع (QR) يعمل الآن بشكل سليم على الشاشة؛ اطلب من الموظف مسح الرمز ولا تستخدم الدخول اليدوي.');
      return;
    }
    const employeeId = $('manualEmployeeId').value.trim();
    if (!employeeId) return;
    const screenKey = getScreenReadKeyForEntry();
    if (!pending || pending.employeeId !== employeeId || Date.now() - (pending.createdAt || 0) >= 30000) {
      pending = { employeeId, id: crypto.randomUUID(), screenKey, createdAt: Date.now() };
    }
    busy = true; syncEmergencyControls(); message('جارِ التحقق وتسجيل الزيارة...');
    try {
      const data = await rpc('guard_manual_employee_entry_v2', {
        p_token: token,
        p_employee_id: employeeId,
        p_request_id: pending.id,
        p_screen_read_key: pending.screenKey
      });
      pending = null; $('manualEmployeeId').value = ''; $('guardManualPanel').hidden = true; panelState(false);
      // Reuse the existing result/photo display and its ten-second cleanup.
      startResultPrivacy();
      $('result').className = ({ ALLOWED: 'allowed', LIMITED: 'limited', DENIED: 'denied' })[data.result] || 'denied';
      $('decision').textContent = ({ ALLOWED: 'مسموح بالدخول', LIMITED: 'مسموح بشكل مؤقت', DENIED: 'غير مسموح بالدخول' })[data.result] || 'غير مسموح بالدخول';
      const employee = data.employee || {};
      $('name').textContent = employee.full_name || '';
      $('job').textContent = employee.job_type ? 'الوظيفة: ' + employee.job_type : '';
      $('specialty').textContent = employee.specialty ? 'الاختصاص: ' + employee.specialty : '';
      photoGeneration++; $('photo').hidden = true; $('photo').removeAttribute('src');
      if (photoBlob) { URL.revokeObjectURL(photoBlob); photoBlob = null; }
      $('result').hidden = false; $('qrPanel').hidden = true;
      if (employee.has_photo && data.read_key) loadPhoto(data.read_key);
    } catch (err) {
      if (err.isTransportError) {
        message('لم تُؤكد نتيجة الطلب. ' + err.message + ' إعادة المحاولة بنفس الرقم لا تحتسب زيارة ثانية.');
      } else {
        pending = null;
        message(err.message);
      }
    } finally {
      busy = false; syncEmergencyControls();
    }
  };

  window.addEventListener('guard-qr-health-change', async () => {
    if (isQrHealthyOnScreen()) {
      const wasEmergency = emergencyEnabled;
      emergencyEnabled = false;
      pending = null;
      syncEmergencyControls();
      if (wasEmergency || !$('guardManualPanel').hidden) {
        message('عاد رمز المربع (QR) للعمل تلقائيًا وتم إيقاف وضع الطوارئ. اطلب من الموظف مسح الرمز الظاهر على الشاشة.');
      }
      return;
    }
    syncEmergencyControls();
    if (token && !$('guardManualPanel').hidden && !busy && !emergencyEnabled) {
      try { authenticated(await rpc('guard_session_status', { p_token: token })); }
      catch (_) {}
    }
  });

  if ($('guardSharedLogin')) $('guardSharedLogin').onclick = () => { $('guardIdentity').value = '7000000000'; $('guardPhone').focus(); };
  showIdentity();
})();
