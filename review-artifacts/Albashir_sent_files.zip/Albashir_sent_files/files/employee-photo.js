// ============================================================================
// employee-photo.js — client for the employee-photo-url resolver
//
// The employee-photos bucket is private: the browser can no longer build a
// permanent public URL. Every photo is displayed through a 60-second signed URL
// minted by the employee-photo-url Edge Function after it verifies the actor.
//
// Usage
//   render:  <img data-photo-ref="<path-or-legacy-url>" data-photo-fallback="./logo.jpeg">
//   hydrate: EmployeePhoto.hydrate(rootElement, actor, config)
//   manual:  const url = await EmployeePhoto.resolve(ref, actor, config)
//
// Actors
//   { type: "admin",           access_token }                      // reviews any employee
//   { type: "employee",        employee_id, mobile_number }        // own photo only
//   { type: "employee_device", device_token, device_id }           // own photo only
//   { type: "guard_device",    device_code, device_token }         // gate screen
//
// Cache policy
//   A signed URL is a temporary credential, so it must not be stored anywhere.
//   The URL is fetched with cache: "no-store" and displayed as a same-origin
//   blob URL, and it is never written to localStorage/sessionStorage. The
//   service worker never caches *.supabase.co responses. Failed no-store fetches
//   show the configured placeholder; signed URLs never become src or href.
// ============================================================================
(function () {
  "use strict";

  const RESOLVER_PATH = "/functions/v1/employee-photo-url";
  const NEW_RESOLVER_PATH = "/functions/v1/employee-photo-url-new";
  const NEW_SHA256_FOLDER_PATTERN = /^registrations\/[0-9a-f]{64}\/[A-Za-z0-9-]{1,80}\.jpg$/;
  const SIGNED_URL_TTL_SECONDS = 60;
  const CACHE_SKEW_MS = 10000;
  const REQUEST_TIMEOUT_MS = 8000;
  const MAX_INPUT_LENGTH = 512;
  const PATH_PATTERN = /^registrations\/[A-Za-z0-9_-]{1,64}\/[A-Za-z0-9._-]{1,120}$/;
  const ALLOWED_EXTENSIONS = ["jpg", "jpeg", "png", "webp"];
  const PUBLIC_MARKER = "/storage/v1/object/public/employee-photos/";
  const SIGNED_MARKER = "/storage/v1/object/sign/employee-photos/";

  const urlCache = new Map();
  const inflight = new Map();
  const warned = new Set();
  const blobCache = new Map();
  const blobIndex = new Map();
  const blobInflight = new Map();
  const pendingElements = new Map();
  const lazyTasks = new Map();
  let lazyObserver = null;
  let blobCacheBytes = 0;
  const MAX_BLOB_CACHE_ENTRIES = 40;
  const MAX_BLOB_CACHE_BYTES = 20 * 1024 * 1024;
  const BLOB_CACHE_TTL_MS = SIGNED_URL_TTL_SECONDS * 1000 - CACHE_SKEW_MS;
  const objectUrls = new Map(); // element -> blob cache key
  let generation = 0;
  const renderVersions = new WeakMap();

  function normalizePath(value) {
    const raw = String(value ?? "").trim();
    if (!raw || raw.length > MAX_INPUT_LENGTH) return "";
    if (raw.startsWith("registrations/")) return isWellFormedPath(raw) ? raw : "";
    let candidate = "";
    if (raw.includes(PUBLIC_MARKER)) candidate = raw.split(PUBLIC_MARKER)[1] || "";
    else if (raw.includes(SIGNED_MARKER)) candidate = (raw.split(SIGNED_MARKER)[1] || "").split("?")[0];
    if (!candidate) return "";
    try {
      candidate = decodeURIComponent(candidate);
    } catch {
      return "";
    }
    candidate = candidate.trim();
    return isWellFormedPath(candidate) ? candidate : "";
  }

  function isWellFormedPath(path) {
    if (!PATH_PATTERN.test(path)) return false;
    return ALLOWED_EXTENSIONS.includes(path.split(".").pop().toLowerCase());
  }

  function actorKey(actor) {
    if (!actor || typeof actor !== "object") return "";
    const type = String(actor.type || "");
    const credentials =
      type === "employee" ? [actor.employee_id, actor.mobile_number] :
      type === "guard_device" ? [actor.device_code, actor.device_token] :
      type === "employee_device" ? [actor.device_token, actor.device_id] :
      type === "admin" ? [actor.access_token] : [];
    if (!credentials.length || credentials.some(value => !String(value || "").trim())) return "";
    // Credentials stay only in this page's memory; never log or persist this key.
    return JSON.stringify([type, ...credentials]);
  }

  function photoCacheKey(value, actor, options = {}) {
    const path = normalizePath(value);
    const identity = actorKey(actor);
    return path && identity ? `${shouldUseNewResolver(path, actor, options) ? "new" : "legacy"}|${identity}|${path}` : "";
  }

  function shouldUseNewResolver(path, actor, options) {
    if (options?.newOnly === true) return true;
    const type = String(actor?.type || "");
    if (type !== "employee" && type !== "employee_device") return false;
    return NEW_SHA256_FOLDER_PATTERN.test(String(path || ""));
  }

  function endpoint(config, useNew = false) {
    const base = String(config?.SUPABASE_URL || "").replace(/\/+$/, "");
    if (!base) return "";
    return `${base}${useNew ? NEW_RESOLVER_PATH : RESOLVER_PATH}`;
  }

  function readCached(key) {
    const entry = urlCache.get(key);
    if (!entry) return "";
    if (entry.expiresAt <= Date.now()) {
      urlCache.delete(key);
      return "";
    }
    return entry.url;
  }

  function deleteBlobCacheEntry(blobKey) {
    const entry = blobCache.get(blobKey);
    if (!entry || entry.refs > 0) return false;
    blobCache.delete(blobKey);
    if (blobIndex.get(entry.cacheKey) === blobKey) blobIndex.delete(entry.cacheKey);
    blobCacheBytes = Math.max(0, blobCacheBytes - entry.size);
    try { URL.revokeObjectURL(entry.url); } catch {}
    return true;
  }

  function evictBlobCache() {
    for (const [blobKey, entry] of Array.from(blobCache.entries())) {
      if (entry.expiresAt <= Date.now() && entry.refs === 0) deleteBlobCacheEntry(blobKey);
    }
    while (blobCache.size > MAX_BLOB_CACHE_ENTRIES || blobCacheBytes > MAX_BLOB_CACHE_BYTES) {
      let oldestKey = "";
      let oldestTime = Infinity;
      for (const [blobKey, entry] of blobCache.entries()) {
        if (entry.refs === 0 && entry.lastUsed < oldestTime) {
          oldestKey = blobKey;
          oldestTime = entry.lastUsed;
        }
      }
      if (!oldestKey) break;
      deleteBlobCacheEntry(oldestKey);
    }
  }

  function readCachedBlob(cacheKey) {
    const blobKey = blobIndex.get(cacheKey);
    if (!blobKey) return null;
    const entry = blobCache.get(blobKey);
    if (!entry) {
      blobIndex.delete(cacheKey);
      return null;
    }
    if (entry.expiresAt <= Date.now()) {
      if (blobIndex.get(cacheKey) === blobKey) blobIndex.delete(cacheKey);
      if (entry.refs === 0) deleteBlobCacheEntry(blobKey);
      return null;
    }
    entry.lastUsed = Date.now();
    return { key: blobKey, entry };
  }

  function warnOnce(reason) {
    const key = String(reason || "UNKNOWN");
    if (warned.has(key)) return;
    warned.add(key);
    try {
      console.warn("[employee-photo] resolver denied the request:", key);
    } catch {}
  }

  async function requestResolver(config, payload, useNew = false) {
    const url = endpoint(config, useNew);
    const anonKey = String(config?.SUPABASE_ANON_KEY || "");
    if (!url || !anonKey) return null;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(url, {
        method: "POST",
        cache: "no-store", credentials: "omit", referrerPolicy: "no-referrer",
        headers: {
          "content-type": "application/json",
          apikey: anonKey,
          authorization: `Bearer ${anonKey}`
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data || data.ok !== true) {
        warnOnce(data?.reason || `HTTP_${response.status}`);
        return null;
      }
      return data;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Resolves a photo reference into a short-lived signed URL.
   * Returns "" when the actor is not authorised, the photo is missing, or the
   * resolver is unreachable — callers must always have a fallback.
   */
  async function resolve(value, actor, config, options = {}) {
    const path = normalizePath(value);
    const key = actorKey(actor);
    if (!path || !key) return "";

    const useNew = shouldUseNewResolver(path, actor, options);
    const cacheKey = `${useNew ? "new" : "legacy"}|${key}|${path}`;
    if (options.force !== true) {
      const cached = readCached(cacheKey);
      if (cached) return cached;
    }

    if (inflight.has(cacheKey)) return inflight.get(cacheKey);

    const requestGeneration = generation;
    const requestStart = Date.now();
    const task = (async () => {
      const reqPayload = useNew && actor?.employee_id && !options?.omitEmployeeId ? { action: "resolve", path, employee_id: actor.employee_id, actor } : { action: "resolve", path, actor };
      const data = await requestResolver(config, reqPayload, useNew);
      if (!data?.url || requestGeneration !== generation) return "";
      const ttlSeconds = Number(data.expires_in) > 0 ? Number(data.expires_in) : SIGNED_URL_TTL_SECONDS;
      urlCache.set(cacheKey, {
        url: data.url,
        expiresAt: requestStart + ttlSeconds * 1000 - CACHE_SKEW_MS
      });
      return data.url;
    })().finally(() => { if (inflight.get(cacheKey) === task) inflight.delete(cacheKey); });

    inflight.set(cacheKey, task);
    return task;
  }

  function applyFallback(element, fallback) {
    // The only approved fallback used by the app is its bundled placeholder.
    if (fallback === "./logo.jpeg") {
      element.src = "./logo.jpeg";
      element.removeAttribute("data-photo-ref");
      return;
    }
    element.removeAttribute("src");
    element.style.display = "none";
  }

  function releaseObjectUrl(element) {
    const blobKey = objectUrls.get(element);
    if (!blobKey) return;
    objectUrls.delete(element);
    const entry = blobCache.get(blobKey);
    if (!entry) return;
    entry.refs = Math.max(0, entry.refs - 1);
    entry.lastUsed = Date.now();
    evictBlobCache();
  }

  function release(root) {
    if (!root) return 0;
    const targets = new Set([...pendingElements.keys(), ...objectUrls.keys(), ...lazyTasks.keys()]);
    let released = 0;
    for (const element of targets) {
      let inside = root === element;
      if (!inside && typeof root.contains === "function") {
        try { inside = root.contains(element); } catch {}
      }
      if (!inside) continue;
      renderVersions.set(element, (renderVersions.get(element) || 0) + 1);
      if (lazyTasks.has(element)) {
        lazyObserver?.unobserve(element);
        lazyTasks.delete(element);
      }
      releaseObjectUrl(element);
      try {
        element.removeAttribute("src");
        element.removeAttribute("href");
      } catch {}
      released += 1;
    }
    evictBlobCache();
    return released;
  }

  function releaseAllObjectUrls() {
    for (const element of Array.from(objectUrls.keys())) {
      releaseObjectUrl(element);
      try {
        element.removeAttribute("src");
        element.removeAttribute("href");
      } catch {}
    }
    for (const blobKey of Array.from(blobCache.keys())) {
      const entry = blobCache.get(blobKey);
      if (entry) entry.refs = 0;
      deleteBlobCacheEntry(blobKey);
    }
    blobIndex.clear();
    blobInflight.clear();
    blobCacheBytes = 0;
  }

  function beginPending(element) {
    pendingElements.set(element, (pendingElements.get(element) || 0) + 1);
  }

  function endPending(element) {
    const count = pendingElements.get(element) || 0;
    if (count <= 1) pendingElements.delete(element);
    else pendingElements.set(element, count - 1);
  }

  function queueLazy(element, actor, config, options) {
    const Observer = window.IntersectionObserver;
    if (options?.eager === true || typeof Observer !== "function") return false;
    if (!lazyObserver) {
      lazyObserver = new Observer(entries => {
        const jobs = [];
        for (const entry of entries) {
          if (!entry.isIntersecting && entry.intersectionRatio <= 0) continue;
          const target = entry.target;
          lazyObserver?.unobserve(target);
          const task = lazyTasks.get(target);
          lazyTasks.delete(target);
          if (!task || task.generation !== generation || target.isConnected === false) continue;
          jobs.push(hydrate(target, task.actor, task.config, { ...task.options, eager: true, single: true }));
        }
        return Promise.all(jobs);
      }, { rootMargin: "250px 0px", threshold: 0.01 });
    }
    lazyTasks.set(element, { actor, config, options, generation });
    lazyObserver.observe(element);
    return true;
  }

  function observeDetachedPhotoElements() {
    try {
      const doc = window.document;
      const Observer = window.MutationObserver;
      if (!doc?.documentElement || typeof Observer !== "function") return;
      const observer = new Observer(records => {
        for (const record of records) {
          for (const node of record.removedNodes || []) {
            if (node && node.isConnected !== true) release(node);
          }
        }
      });
      observer.observe(doc.documentElement, { childList: true, subtree: true });
    } catch {}
  }

  /**
   * Fetches a signed URL without touching any cache and returns a same-origin
   * blob URL. Returns "" when the browser refuses the fetch (CORS, offline),
   * so the caller can show a placeholder.
   */
  async function fetchAsObjectUrl(url, cacheKey, renderGeneration) {
    const cached = readCachedBlob(cacheKey);
    if (cached) return cached;
    if (!url || !cacheKey) return null;

    const blobKey = `${cacheKey}|${url}`;
    if (blobInflight.has(blobKey)) return blobInflight.get(blobKey);

    const task = (async () => {
      try {
        const downloadUrl = url + (url.includes('?') ? '&' : '?') + 'cacheNonce=' + encodeURIComponent(crypto.randomUUID());
        const response = await (window.ALBASHIRRuntime?.fetchWithTimeout || fetch)(downloadUrl, {
          cache: "no-store",
          credentials: "omit",
          mode: "cors",
          referrerPolicy: "no-referrer"
        });
        if (!response.ok || renderGeneration !== generation) return null;
        const blob = await response.blob();
        if (!blob || blob.size === 0 || renderGeneration !== generation) return null;
        const signedEntry = urlCache.get(cacheKey);
        const expiresAt = Math.min(
          signedEntry?.expiresAt ?? (Date.now() + BLOB_CACHE_TTL_MS),
          Date.now() + BLOB_CACHE_TTL_MS
        );
        if (expiresAt <= Date.now()) return null;

        const objectUrl = URL.createObjectURL(blob);
        const entry = {
          cacheKey,
          url: objectUrl,
          size: Number(blob.size) || 0,
          expiresAt,
          refs: 0,
          lastUsed: Date.now()
        };
        blobCache.set(blobKey, entry);
        blobIndex.set(cacheKey, blobKey);
        blobCacheBytes += entry.size;
        return { key: blobKey, entry };
      } catch {
        return null;
      }
    })().finally(() => {
      if (blobInflight.get(blobKey) === task) blobInflight.delete(blobKey);
    });

    blobInflight.set(blobKey, task);
    return task;
  }

  /**
   * Displays one resolved photo. The signed URL never becomes the element's
   * src; a failed no-store fetch shows the placeholder.
   */
  async function display(element, url, fallback, renderGeneration, version, cacheKey, isLink = false) {
    if (renderGeneration !== generation || renderVersions.get(element) !== version) return false;
    releaseObjectUrl(element);
    const cached = cacheKey ? await fetchAsObjectUrl(url, cacheKey, renderGeneration) : null;
    if (renderGeneration !== generation || renderVersions.get(element) !== version) return false;
    if (!cached?.entry?.url) {
      window.ALBASHIRRuntime?.report('photo', 'failed');
      if (isLink) {
        element.removeAttribute("href");
        element.href = "";
      } else applyFallback(element, fallback);
      return false;
    }
    const entry = blobCache.get(cached.key);
    if (!entry) return false;
    entry.refs += 1;
    entry.lastUsed = Date.now();
    objectUrls.set(element, cached.key);
    window.ALBASHIRRuntime?.report('photo', 'ready');
    element[isLink ? "href" : "src"] = entry.url;
    element.style.display = "";
    element.removeAttribute(isLink ? "data-photo-href" : "data-photo-ref");
    evictBlobCache();
    return true;
  }

  /**
   * Resolves every [data-photo-ref] element inside `root`.
   * `data-photo-fallback` keeps its current visual behaviour when resolution
   * fails (for example "./logo.jpeg" on the guard screen).
   * `data-photo-href` elements (thumbnails wrapped in a link) receive the
   * blob URL as their href.
   */
  async function hydrate(root, actor, config, options = {}) {
    const scope = root || document;
    const elements = options.single ? [] : typeof scope.querySelectorAll === "function" ? Array.from(scope.querySelectorAll("[data-photo-ref]")) : [];
    const links = options.single ? [] : typeof scope.querySelectorAll === "function" ? Array.from(scope.querySelectorAll("[data-photo-href]")) : [];
    if (scope.matches && scope.matches("[data-photo-ref]")) elements.unshift(scope);
    if (scope.matches && scope.matches("[data-photo-href]")) links.unshift(scope);
    const renderGeneration = generation;
    await Promise.all([
      ...elements.map(async (element) => {
        const version = (renderVersions.get(element) || 0) + 1;
        renderVersions.set(element, version);
        if (queueLazy(element, actor, config, options)) return;
        beginPending(element);
        try {
          const reference = element.getAttribute("data-photo-ref");
          const fallback = element.getAttribute("data-photo-fallback") || "";
          const cacheKey = photoCacheKey(reference, actor, options);
          const cached = cacheKey ? readCachedBlob(cacheKey) : null;
          const url = cached ? "" : await resolve(reference, actor, config, options);
          await display(element, url, fallback, renderGeneration, version, cacheKey);
        } finally {
          endPending(element);
        }
      }),
      ...links.map(async (element) => {
        const version = (renderVersions.get(element) || 0) + 1;
        renderVersions.set(element, version);
        if (queueLazy(element, actor, config, options)) return;
        beginPending(element);
        try {
          const reference = element.getAttribute("data-photo-href");
          const cacheKey = photoCacheKey(reference, actor, options);
          const cached = cacheKey ? readCachedBlob(cacheKey) : null;
          const url = cached ? "" : await resolve(reference, actor, config, options);
          await display(element, url, "", renderGeneration, version, cacheKey, true);
        } finally {
          endPending(element);
        }
      })
    ]);
    return elements.length + links.length;
  }

  function peek(value, actor) {
    const path = normalizePath(value);
    const key = actorKey(actor);
    if (!path || !key) return "";
    return readCached(`${key}|${path}`);
  }

  function clearCache() {
    generation += 1;
    releaseAllObjectUrls();
    urlCache.clear();
    inflight.clear();
    blobInflight.clear();
    lazyObserver?.disconnect();
    lazyObserver = null;
    lazyTasks.clear();
  }

  observeDetachedPhotoElements();
  window.addEventListener?.("pagehide", clearCache);
  window.EmployeePhoto = {
    normalizePath,
    resolve,
    hydrate,
    release,
    peek,
    clearCache,
    SIGNED_URL_TTL_SECONDS,
    CACHE_SKEW_MS,
    RESOLVER_PATH
  };
})();
