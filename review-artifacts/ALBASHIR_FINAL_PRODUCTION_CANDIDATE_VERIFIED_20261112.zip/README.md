# ALBASHIR Emergency Hospital Gate

مستشفى الإسعاف والطوارئ / البشير — المصدر الوحيد للتطبيق.

## Current source and environments

- Private repository: KISSCRISIS/albashir-stone-karag; active release branch: main.
- [Production](https://albashir-stone-karag.vercel.app/portal.html)
- [Staging](https://albashir-staging.vercel.app/portal.html)
- Both Vercel projects build the same source with separate Supabase databases. Staging uses ALBASHIR_ENVIRONMENT=staging, its approved URL and public browser key. Production is the default; invalid or secret configuration fails the build.
- The build publishes only the 75 files in config/runtime-files.json. Their reviewed fingerprints are in config/runtime-baseline.json. Source documentation, SQL, tests, archives and credentials are excluded from public hosting.
- The unused legacy support image was removed in PR #22. All remaining runtime assets retain their approved bytes.

## Application and security contract

Employee registration, review, employee directory, administrator appointments and profiles, guard accounts and profiles, QR verification, private employee photos, result recovery, operational snapshots, the support page and portal clock remain in the current runtime.

QR tokens are opaque and server-issued, with authoritative 30-second expiry. The public screen read_key stays separate from the QR. Claim/request identity and the entry decision remain server-controlled. A saved phone or cached page does not grant entry permission. Employee result details clear after ten seconds. Administrator photos remain private and owner-scoped. Never place a service-role key in browser code.

The owner left supabase/staging_alignment_reviewed.sql **for review; do not apply it**. Staging's administrator-avatar storage and v2 emergency manual-entry endpoint still require that separate database decision. Manual entry is limited to an authenticated guard and a server-confirmed QR failure on the same screen. No new SQL, migrations, Storage policies, Edge Functions or account-creation feature are authorized by repository cleanup.

## Mobile help on the About page

The About page includes three screenshots of the current registration and employee-login interface at phone widths, using empty forms without employee data. It explains required registration fields, approval before login, same-browser saved access, and QR verification at the gate. Safari/iPhone and Chrome/Android home-screen instructions link to the official browser guidance and explain that a shortcut may require login again; it does not grant entry or remove the internet requirement. The founder and support cards remain below the guide. The founder title names ALBASHIR Gate and describes staff-access operations. Registration/login instructions apply to both Android and iPhone; home-screen installation instructions remain browser-specific. This addition changes no authentication, database, RLS, decision logic or audit behavior. To roll back, revert the About-page guide commit, including its three assets and runtime manifest fingerprints.

## Shared-link preview

The six shared entry/help pages explicitly advertise the approved ALBASHIR Gate PNG icon and the correct Arabic hospital name through static Open Graph metadata. Their home-screen touch icon uses the existing PNG icon instead of the historical logo.jpeg. Staging builds point the public preview image to the Staging origin. No employee photo or access token is included in this metadata. Historical logo.jpeg fallbacks remain separate from link previews; previously sent messenger cards may retain cached images. Revert the link-preview commit to restore the previous metadata.

## Administrator activation and connection

The owner approved account activation inside the Super Admin's appointment cards and a recent-connection directory. The owner explicitly confirms the email/account belongs to the named approved employee, then activates that existing password account without an email message. Other accounts retain their Auth settings. Connection is a 30-second heartbeat with 120-second expiry; stale data is shown as unknown. See [scope, tests and rollback](docs/ADMIN_MANAGEMENT_20261012.md). The additive reviewed SQL does not include the declined Staging alignment. Tests use synthetic accounts and do not prove real-phone login. Activation and existing role/disable/revoke operations are audited; heartbeat updates do not generate a noisy audit event per tick.

## Build and checks

The dashboard now uses a compact phone masthead and complete labelled table cards below 760px, preserving all fields and original actions. The owner explicitly approved Super Admin deletion of an employee registration, associated employee photos and enrollment credentials while preserving entry/audit history; existing administrator appointments must first be revoked. The directory requires typed employee-number confirmation. Private deletion jobs track incomplete Storage cleanup, with a visible retry action. No real employee is deleted by installing the feature. See [scope, checks and deletion limits](docs/ADMIN_MOBILE_DELETE_20261012.md).

The owner-approved second Hospital Leadership name is `Dr.Suleiman M.S Abuawwad`. The shared list also corrects that exact historical second name when read from browser cache or server settings; other names and job titles remain unchanged. This is a display correction with no database, RLS or audit mutation. To roll back, revert the name correction and its runtime fingerprint.

### Build commands

Run node scripts/build-public-runtime.cjs to build Production. For Staging, set ALBASHIR_ENVIRONMENT=staging, ALBASHIR_SUPABASE_URL to the approved Staging project and ALBASHIR_SUPABASE_PUBLISHABLE_KEY to its public key, then run the same builder.

Install pinned test dependencies using npm ci --prefix tests --ignore-scripts. Run npm --prefix tests test, npm --prefix tests run test:staging-alignment and npm --prefix tests run test:browser. Browser checks require the pinned Playwright Chromium installation. CI runs these checks and git diff --check. SQL tests use isolated synthetic databases; browser tests mock backend traffic. These results do not prove real-phone or live employee acceptance.

## Operations and project rules

- [Current operating checklist](OPERATIONS_24_7.md)
- [Mandatory project rules](PROJECT_RULES.md)
- [Source and environment unification history](docs/UNIFIED_RUNTIME_20261011.md)
- [Backend differences and approval boundary](docs/BACKEND_UNIFICATION_REVIEW_20261011.md)
- [Private photo architecture](docs/PRIVATE_EMPLOYEE_PHOTOS_ARCHITECTURE.md)
- [Archive index and retired branch decisions](docs/archive/README.md)

The 300/400 simultaneous result-read test passed, but was not a complete 400-employee entry workload. The old 24-hour soak stopped at 28.26% coverage. The replacement run remains unaccepted until it completes 24 hours with at least 95% sample coverage and no errors. Real-phone photo/result acceptance and full daily-limit load remain separate checks.

## Repository cleanup — 2026-10-11

Historical root reports and the previous long README are retained under docs/archive/pre-unification-20261011, explicitly marked as historical. The old independent load script is archived rather than presented as a current operating procedure. No historical SQL or fixtures were removed or rewritten. The owner explicitly approved retirement of the 24 listed branches and closure of PRs #17–#19. All 24 remote archive tags were verified before branch deletion; the three proposals are closed as archived, without merging their code or applying SQL. main and this cleanup branch remain. Exact heads and file comparisons are recorded under docs/archive/branch-heads-20261011.json, with a verified full-history Git bundle also retained locally.

This cleanup changes documentation and source organization only. The 72 published runtime fingerprints, database, RLS and audit behavior are unchanged. Revert the cleanup commit to restore previous paths and documentation. Archive tags and the recorded heads restore retired branches. A main merge can trigger both Vercel builds; verify the resulting commit and artifact before calling the cleanup deployed.
