// One reviewed source tree; publish only explicit application assets.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),out=path.resolve(root,'public-runtime');
if(out!==path.join(root,'public-runtime'))throw Error('Invalid build output');
const configuredEnvironment=process.env.ALBASHIR_ENVIRONMENT||'production';
if(!['production','staging'].includes(configuredEnvironment))throw Error('Unknown application environment');
const environment=process.argv.includes('--staging')?'staging':configuredEnvironment;
const files=JSON.parse(fs.readFileSync(path.join(root,'config/runtime-files.json'),'utf8'));
const prodURL='https://qinsfvlspdticposbvst.supabase.co',prodKey='sb_publishable_okoDqbwZNNvrCZQ025RkPw_qFXkA7I8';
let stageURL,stageKey;
if(environment==='staging'){
 stageURL=process.env.ALBASHIR_SUPABASE_URL;stageKey=process.env.ALBASHIR_SUPABASE_PUBLISHABLE_KEY;
 if(stageURL!=='https://adwvokwucotohwayorgx.supabase.co'||!stageKey||!/^(sb_publishable_|eyJ)/.test(stageKey))throw Error('Staging requires its approved URL and public browser key');
 if(stageKey===prodKey||/service_role|sb_secret_/i.test(stageKey))throw Error('Invalid staging public key');
 if(stageKey.startsWith('eyJ')){let payload;try{payload=JSON.parse(Buffer.from(stageKey.split('.')[1],'base64url'));}catch{throw Error('Invalid public JWT');}if(payload.role!=='anon')throw Error('Staging JWT must have anon role');}
}
for(const name of files){if(name.includes('..')||path.isAbsolute(name)||! /\.(html|js|css|png|jpe?g|svg|webp|ico|woff2?|ttf|json|txt)$/i.test(name)||/^\.|(^|\/)(sources|tests|supabase|docs|scripts)(\/|$)/.test(name))throw Error('Disallowed runtime path: '+name);if(!fs.statSync(path.join(root,name)).isFile())throw Error('Missing asset: '+name);}
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
for(const name of files){let data=fs.readFileSync(path.join(root,name));if(environment==='staging'&&/\.(html|js|json)$/i.test(name)){
 let text=data.toString('utf8').split(prodURL).join(stageURL).split(prodKey).join(stageKey).split('https://albashir-stone-karag.vercel.app/icon-512.png').join('https://albashir-staging.vercel.app/icon-512.png');
 if(/^(guard|verify)\.html$/.test(name)){
  const hashes=[...text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].filter(m=>!/\bsrc\s*=/i.test(m[1])).map(m=>"'sha256-"+crypto.createHash('sha256').update(m[2].replace(/\r\n?/g,'\n')).digest('base64')+"'");
  text=text.replace(/script-src 'self'[^;]*;/g,"script-src 'self' "+hashes.join(' ')+";");
 }
 data=Buffer.from(text);
}fs.mkdirSync(path.dirname(path.join(out,name)),{recursive:true});fs.writeFileSync(path.join(out,name),data);}
if(environment==='staging'){
 const prohibitedHosts=['qinsfvlspdticposbvst.supabase.co','albashir-stone-karag.vercel.app'];
 for(const name of files.filter(f=>/\.(html|js|json)$/i.test(f))){
  const builtText=fs.readFileSync(path.join(out,name),'utf8');
  for(const host of prohibitedHosts){
   if(builtText.includes(host)){
    throw Error('STAGING BUILD BLOCKED: Unauthorized Production reference ('+host+') detected in generated Staging artifact: '+name);
   }
  }
 }
}
console.log('Built '+files.length+' allowlisted runtime files for '+environment+'.');
