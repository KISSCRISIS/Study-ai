'use strict';
(function(){
  var toast=document.querySelector('.copy-toast');
  var timeoutId=0;
  function message(text){if(!toast)return;toast.textContent=text;toast.hidden=false;window.clearTimeout(timeoutId);timeoutId=window.setTimeout(function(){toast.hidden=true},2200)}
  function fallbackCopy(value){var input=document.createElement('textarea');input.value=value;input.setAttribute('readonly','');input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);input.select();var copied=false;try{copied=document.execCommand('copy')}catch(e){}input.remove();return copied}
  document.querySelectorAll('[data-copy]').forEach(function(button){button.addEventListener('click',async function(){var value=button.getAttribute('data-copy')||'';try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(value);message('تم النسخ بنجاح ✓')}else if(fallbackCopy(value)){message('تم النسخ بنجاح ✓')}else{message('تعذر النسخ التلقائي؛ يمكنك تحديد النص ونسخه')}}catch(e){message('تعذر النسخ التلقائي؛ يمكنك تحديد النص ونسخه')}})})
})();
