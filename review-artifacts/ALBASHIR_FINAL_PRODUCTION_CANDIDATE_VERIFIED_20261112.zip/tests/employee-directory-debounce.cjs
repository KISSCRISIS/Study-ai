// Functional regression test for the employee directory search debounce.
// Runs in Node with a deliberately small DOM shim; no browser or backend is used.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "../employee-directory.js"), "utf8");
const ids = [
  "directorySearch", "directoryCategory", "directoryStatus", "directoryJob",
  "directorySpecialty", "directoryEntity", "directoryDepartment",
  "directoryCards", "directoryCount", "directoryPage", "directoryPrevious",
  "directoryNext", "directorySummary", "directoryCatalogStatus",
  "employeeDeletionJobs", "employeeDeletionStatus"
];

class FakeOption {
  constructor(text, value) {
    this.text = text;
    this.textContent = text;
    this.label = text;
    this.value = value;
  }
}

function makeElement(id) {
  const listeners = new Map();
  return {
    id,
    value: "",
    options: [],
    children: [],
    disabled: false,
    textContent: "",
    replaceCount: 0,
    addEventListener(type, callback) {
      if (!listeners.has(type)) listeners.set(type, []);
      listeners.get(type).push(callback);
    },
    fire(type) {
      for (const callback of listeners.get(type) || []) callback({ target: this });
    },
    replaceChildren(...children) {
      this.children = children;
      if (id === "directoryCards") this.replaceCount += 1;
      if (id.startsWith("directory") && id !== "directoryCards") this.options = children;
    },
    add(option) {
      this.options.push(option);
    }
  };
}

(async () => {
  const elements = new Map(ids.map((id) => [id, makeElement(id)]));
  const timers = new Map();
  let timerId = 0;
  const document = {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, makeElement(id));
      return elements.get(id);
    },
    createElement(tag) {
      return { tagName: tag.toUpperCase(), children: [], append(...items) { this.children.push(...items); } };
    },
    createTextNode(text) {
      return { textContent: String(text) };
    }
  };

  const sourceSelects = new Map(
    ["jobType", "specialty", "affiliatedEntity", "department"].map((id) => [
      id,
      { options: [new FakeOption("قيمة اختبار", "TEST_VALUE")] }
    ])
  );
  class FakeDOMParser {
    parseFromString() {
      return { getElementById: (id) => sourceSelects.get(id) || null };
    }
  }

  const context = {
    document,
    Option: FakeOption,
    DOMParser: FakeDOMParser,
    fetch: async () => ({ ok: true, text: async () => "<html></html>" }),
    hydrateAdminPhotos() {},
    setTimeout(callback, delay) {
      const id = ++timerId;
      timers.set(id, { callback, delay });
      return id;
    },
    clearTimeout(id) {
      timers.delete(id);
    },
    console: { warn() {}, error() {}, log() {} }
  };
  context.window = context;
  vm.runInNewContext(source, context, { filename: "employee-directory.js" });

  // Let the mocked registration catalogue load and trigger the first render.
  await new Promise((resolve) => setImmediate(resolve));
  const search = elements.get("directorySearch");
  const category = elements.get("directoryCategory");
  const cards = elements.get("directoryCards");
  assert.equal(cards.replaceCount, 1, "the directory should render once after initialization");

  // A burst of input events should schedule one render, not one render per key.
  for (const value of ["A", "Al", "Ali", "Alia", "Alias", "Alia S", "Alia Sm", "Alia Smi", "Alia Smith"]) {
    search.value = value;
    search.fire("input");
  }
  assert.equal(cards.replaceCount, 1, "typing must not rebuild the cards immediately");
  assert.equal(timers.size, 1, "only the latest debounce timer should remain");
  const [[id, pending]] = [...timers.entries()];
  assert.equal(pending.delay, 300, "directory search debounce must be 300ms");
  timers.delete(id);
  pending.callback();
  assert.equal(cards.replaceCount, 2, "one render should happen after the debounce window");

  // A non-search filter remains immediate and cancels any pending search render.
  search.value = "employee";
  search.fire("input");
  assert.equal(timers.size, 1);
  category.value = "TEMPORARY";
  category.fire("change");
  assert.equal(cards.replaceCount, 3, "category filters must still render immediately");
  assert.equal(timers.size, 0, "changing another filter must cancel a pending search render");

  console.log("PASS directory search debounces a typing burst to one render; other filters remain immediate");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
