"use strict";
const fs=require("node:fs"),path=require("node:path"),assert=require("node:assert/strict"),crypto=require("node:crypto");
const root=path.join(__dirname,".."),read=p=>fs.readFileSync(path.join(root,p)),txt=p=>read(p).toString("utf8"),hash=p=>crypto.createHash("sha256").update(read(p)).digest("hex");
const original="e29cfac99933ef24f054216421588f68c0503245511e928a667f7e3e87aa084f";
assert.equal(hash("register.html"),original,"CANONICAL EXISTING REGISTRATION CHANGED");
assert.equal(hash("register-existing.html"),original,"Classic alias diverged");
assert.deepEqual(read("register.html"),read("register-existing.html"));
assert.match(txt("register.html"),/rpc\("register_employee_request", payload\)/);
assert.doesNotMatch(txt("register.html"),/rpc\("register_new_employee_request", payload\)/);
assert.match(txt("register-new.html"),/rpc\("register_new_employee_request", payload\)/);
assert.match(txt("register-new.html"),/functions\/v1\/employee-photo-upload-new/);
assert.doesNotMatch(txt("register-new.html"),/functions\/v1\/employee-photo-upload(?![-A-Za-z0-9_])/);
assert.doesNotMatch(txt("register-new.html"),/rpc\("register_employee_request", payload\)/);
assert(fs.existsSync(path.join(root,"supabase/functions/employee-photo-upload-new/index.ts")),"Standalone upload Edge entry point missing");
assert(fs.existsSync(path.join(root,"supabase/functions/employee-photo-upload-new/handler.mjs")),"Standalone upload Edge handler missing");
const files=JSON.parse(txt("config/runtime-files.json")),hashes=JSON.parse(txt("config/runtime-baseline.json"));
for(const f of files){const x=hashes.find(e=>e.file===f);assert(x,"Unlisted runtime "+f);assert.equal(hash(f),x.sha256,"Hash mismatch: "+f);}
assert.deepEqual(files.filter(e=>e.startsWith("register")),["register-existing.html","register-new.html","register.html"]);
console.log("PASS original employee frontend untouched; only additive new-only registration route and standalone employee-photo-upload-new");
