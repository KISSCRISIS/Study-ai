"use strict";
// ============================================================================
// tests/argon-e2e-journey-15.cjs
// Executes all 15 end-to-end employee, admin, trusted-device, QR, guard, and
// historical-isolation scenarios against the real handlers and page scripts:
//  1. Register synthetic new employee (QA/NEW-101)
//  2. Upload valid JPEG photo (Magic Bytes + structure verified)
//  3. Reject invalid/corrupt photo
//  4. Succeed with PENDING status
//  5. Retry after RPC Timeout (503 / transport abort)
//  6. Page reload (sessionStorage recovery) & restore registration attempt
//  7. Zero duplicate photo upload across timeout retry & page reload
//  8. Display photo on employee profile page (profile.html via employee-photo.js -> employee-photo-url-new)
//  9. Display photo on admin dashboard (admin_dashboard.html via employee-photo.js -> Resolver v2)
// 10. Fast login from approved trusted device (portal.html -> profile.html) without re-entering ID/phone
// 11. Generate QR on guard screen (guard.html create_public_guard_qr)
// 12. Verify QR via employee trusted device (verify.html -> public_guard_auto_employee_check_v2)
// 13. Display decision (ALLOWED) and photo on guard screen & employee screen
// 14. Hide guard result and revoke photo blob after 10-second display window
// 15. Historical employees (including Arabic-digit IDs in registrations/-/) remain 100% unaffected
// ============================================================================

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

if (!globalThis.crypto?.subtle) {
  globalThis.crypto = crypto.webcrypto;
}

function buildValidJpeg({ width = 128, height = 128, seed = 0x33 } = {}) {
  const header = [
    0xff, 0xd8,
    0xff, 0xe0, 0x00, 0x10,
    0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48, 0x00, 0x48, 0x00, 0x00,
    0xff, 0xc0, 0x00, 0x11,
    0x08,
    (height >> 8) & 0xff, height & 0xff,
    (width >> 8) & 0xff, width & 0xff,
    0x03,
    0x01, 0x11, 0x00,
    0x02, 0x11, 0x01,
    0x03, 0x11, 0x01,
    0xff, 0xda, 0x00, 0x0c,
    0x03, 0x01, 0x00, 0x02, 0x11, 0x03, 0x11, 0x00, 0x3f, 0x00
  ];
  const scan = new Uint8Array(32);
  for (let i = 0; i < scan.length; i++) scan[i] = ((seed + i * 13) & 0x7f) + 1;
  const footer = [0xff, 0xd9];
  const out = new Uint8Array(header.length + scan.length + footer.length);
  out.set(header, 0);
  out.set(scan, header.length);
  out.set(footer, header.length + scan.length);
  return out;
}

(async () => {
  const root = path.resolve(__dirname, "..");
  const { handleNewPhotoUpload, createUploadState } = await import(
    "file://" + path.join(root, "supabase/functions/employee-photo-upload-new/handler.mjs")
  );
  const { handleNewPhotoRequest } = await import(
    "file://" + path.join(root, "supabase/functions/employee-photo-url-new/handler.mjs")
  );
  const { handleRequest: handleLegacyPhotoRequest } = await import(
    "file://" + path.join(root, "supabase/functions/employee-photo-url/handler.mjs")
  );

  const origin = "https://albashir-staging.vercel.app";
  const validJpegBytes = buildValidJpeg({ width: 200, height: 200, seed: 0x44 });

  // Simulated isolated Staging DB + Storage state (synthetic records only)
  const db = {
    freezeAt: 1762800000000,
    now: 1762900000000,
    storageObjects: new Map([
      ["registrations/OLD-HIST-01/1760000000000-aaaa.jpg", validJpegBytes],
      ["registrations/-/1760000000000-arabic1.jpg", validJpegBytes]
    ]),
    pendingUploads: new Map(),
    attestations: new Map(), // objectPath -> employeeId
    employees: new Map([
      [
        "OLD-HIST-01",
        {
          id: "00000000-0000-4000-8000-000000000001",
          employee_id: "OLD-HIST-01",
          full_name: "موظف تاريخي قياسي",
          mobile_number: "0790000001",
          specialty: "باطني",
          job_type: "طبيب",
          department: "باطني",
          employee_photo_url: "registrations/OLD-HIST-01/1760000000000-aaaa.jpg",
          status: "APPROVED",
          created_at: 1762000000000,
          trusted_device_enabled: true,
          trusted_device_token: "d".repeat(96),
          trusted_device_id: "mobile-old-01"
        }
      ],
      [
        "١٢٣٤٥٦",
        {
          id: "00000000-0000-4000-8000-000000000002",
          employee_id: "١٢٣٤٥٦",
          full_name: "موظف تاريخي برقم عربي",
          mobile_number: "0790000002",
          specialty: "جراحة عامة",
          job_type: "طبيب",
          department: "جراحة عامة",
          employee_photo_url: "registrations/-/1760000000000-arabic1.jpg",
          status: "APPROVED",
          created_at: 1762000000000,
          trusted_device_enabled: false
        }
      ]
    ]),
    qrSessions: new Map(), // token -> { id, readKey, expiresAt, result, employeeId }
    storageUploadCount: 0,
    newResolverHits: 0,
    legacyResolverHits: 0
  };

  const uploadState = createUploadState();
  const uploadDeps = {
    allowedOrigins: origin,
    now: () => db.now,
    randomUUID: () => "11111111-2222-4333-8444-555555555555",
    async claimUploadQuota() {
      return { allowed: true, lease_id: "11111111-2222-4333-8444-555555555555", retry_after_seconds: 0 };
    },
    async consumeUploadQuota(leaseId) { return { ok: true, lease_id: leaseId }; },
    async checkEligibility(id) {
      return { ok: true, is_new: !db.employees.has(id) };
    },
    async uploadObject(p, bytes) {
      db.storageUploadCount += 1;
      db.storageObjects.set(p, bytes);
      return { ok: true };
    },
    async registerPendingUpload(p) {
      db.pendingUploads.set(p, "PENDING");
      return { ok: true };
    },
    async attestNewPhoto(id, p) {
      if (db.employees.has(id) || db.pendingUploads.get(p) !== "PENDING") return { ok: false };
      db.attestations.set(p, id);
      return { ok: true };
    },
    async removeObject(p) {
      db.storageObjects.delete(p);
      return { ok: true };
    },
    async confirmPendingRemoval(p) {
      if (db.pendingUploads.get(p) !== "LINKED") db.pendingUploads.delete(p);
      return { ok: true };
    }
  };

  const newResolverDeps = {
    allowedOrigins: origin,
    async admitRequest() { return true; },
    async admitAuthenticatedRequest() { return true; },
    async resolvePhotoOwnerByPath(p) {
      const empId = db.attestations.get(p);
      if (!empId) return { ok: false };
      const emp = db.employees.get(empId);
      if (!emp || emp.created_at <= db.freezeAt) return { ok: false };
      return { ok: true, employeeId: empId };
    },
    async verifyNewPhotoBinding(id, p) {
      const emp = db.employees.get(id);
      return Boolean(
        emp &&
        emp.created_at > db.freezeAt &&
        emp.employee_photo_url === p &&
        db.attestations.get(p) === id &&
        db.storageObjects.has(p)
      );
    },
    async verifyEmployeeCredentials(id, mobile) {
      const emp = db.employees.get(id);
      if (!emp || emp.mobile_number !== mobile) return { ok: false };
      return { ok: true, employeeId: emp.employee_id, photoPath: emp.employee_photo_url };
    },
    async verifyTrustedDevice(token, deviceId) {
      for (const emp of db.employees.values()) {
        if (
          emp.status === "APPROVED" &&
          emp.trusted_device_enabled &&
          emp.trusted_device_token === token &&
          emp.trusted_device_id === deviceId
        ) {
          return { ok: true, employeeId: emp.employee_id };
        }
      }
      return { ok: false };
    },
    async verifyAdmin(token) {
      return { ok: token === "valid-admin-jwt", role: "SUPER_ADMIN" };
    },
    async verifyGateDevice(code, token) {
      return { ok: code === "gate-01" && token === "gate-tok-01" };
    },
    async verifyAllowedGuardSession(readKey, id, p) {
      for (const q of db.qrSessions.values()) {
        if (q.readKey === readKey && q.result === "ALLOWED") {
          const emp = db.employees.get(q.employeeId);
          return Boolean(emp && emp.employee_id === id && emp.employee_photo_url === p);
        }
      }
      return false;
    },
    async createSignedUrl(p) {
      if (!db.storageObjects.has(p)) return { ok: false };
      return {
        ok: true,
        url: `https://adwvokwucotohwayorgx.supabase.co/storage/v1/object/sign/employee-photos/${encodeURIComponent(p)}?token=signed60s`
      };
    }
  };

  const legacyResolverDeps = {
    allowedOrigins: origin,
    now: () => db.now,
    async verifyPublicGuardSession(readKey) {
      for (const q of db.qrSessions.values()) {
        if (q.readKey === readKey && q.result) {
          const emp = db.employees.get(q.employeeId);
          if (emp?.employee_photo_url) return { ok: true, path: emp.employee_photo_url };
        }
      }
      return { ok: false, path: "" };
    },
    async verifyAdmin(token) {
      return { ok: token === "valid-admin-jwt", role: "SUPER_ADMIN" };
    },
    async verifyEmployeeCredentials(id, mobile) {
      const emp = db.employees.get(id);
      if (!emp || emp.mobile_number !== mobile) return { ok: false };
      return { ok: true, employeeId: emp.employee_id };
    },
    async verifyTrustedDevice(token, deviceId) {
      for (const emp of db.employees.values()) {
        if (
          emp.status === "APPROVED" &&
          emp.trusted_device_enabled &&
          emp.trusted_device_token === token &&
          emp.trusted_device_id === deviceId
        ) {
          return { ok: true, employeeId: emp.employee_id };
        }
      }
      return { ok: false };
    },
    async verifyGateDevice(code, token) {
      return { ok: code === "gate-01" && token === "gate-tok-01" };
    },
    async createSignedUrl(p) {
      if (!db.storageObjects.has(p)) return { ok: false, notFound: true };
      return {
        ok: true,
        url: `https://adwvokwucotohwayorgx.supabase.co/storage/v1/object/sign/employee-photos/${encodeURIComponent(p)}?token=legacysigned60s`
      };
    }
  };

  // -------------------------------------------------------------------------
  // Scenarios 1, 2, 3, 4, 5, 6, 7:
  // New Synthetic Employee Registration, Valid JPEG Upload, Invalid Photo
  // Rejection, Timeout Retry, Page Reload Recovery, and Zero Re-upload
  // -------------------------------------------------------------------------
  const syntheticNewId = "QA/NEW-101";
  const syntheticMobile = "0799990101";

  // Scenario 3: Reject invalid/corrupt photo
  const invalidPhotoRes = await handleNewPhotoUpload(
    {
      method: "POST",
      headers: { origin },
      form: {
        employee_id: syntheticNewId,
        fileName: "corrupt.jpg",
        mimeType: "image/jpeg",
        bytes: new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
      }
    },
    uploadDeps,
    uploadState
  );
  assert.equal(invalidPhotoRes.status, 400, "Scenario 3: Invalid photo bytes must be rejected with 400");
  assert.equal(db.storageUploadCount, 0, "Scenario 3: Invalid photo must not write to Storage");

  // Setup register-new.html VM environment for Scenarios 1, 2, 4, 5, 6, 7
  const regHtml = fs.readFileSync(path.join(root, "register-new.html"), "utf8");
  const fnStart = regHtml.indexOf("  async function uploadEmployeePhoto(employeeId) {");
  const fnEnd = regHtml.indexOf("  const REGISTRATION_RPC_TIMEOUT_MS = 20000;");
  const regCode =
    regHtml.slice(fnStart, fnEnd) +
    "\nthis.photoForRegistrationRetry = photoForRegistrationRetry;" +
    "\nthis.getOrCreatePendingOwnershipProof = getOrCreatePendingOwnershipProof;" +
    "\nthis.clearPendingUploadRecovery = clearPendingUploadRecovery;";

  const sessionStore = new Map();
  const localStore = new Map();
  const makeStorage = (map) => ({
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k)
  });

  const fileObj = {
    name: "employee.jpg",
    type: "image/jpeg",
    size: validJpegBytes.byteLength,
    async arrayBuffer() {
      return validJpegBytes.buffer.slice(
        validJpegBytes.byteOffset,
        validJpegBytes.byteOffset + validJpegBytes.byteLength
      );
    }
  };

  function createRegistrationTab() {
    const ctx = {
      window: {},
      Date,
      sessionStorage: makeStorage(sessionStore),
      localStorage: makeStorage(localStore),
      APP_CONFIG: {
        SUPABASE_URL: "https://adwvokwucotohwayorgx.supabase.co",
        SUPABASE_ANON_KEY: "sb_publishable_stage"
      },
      $: (id) => (id === "employeePhoto" ? { files: [fileObj] } : null),
      readPendingRegistrationContext: () => {
        const raw = localStore.get("erp_pending_registration_v1");
        if (!raw) return null;
        const value = JSON.parse(raw);
        const employeeId = String(value?.employee_id || "").trim();
        const deviceId = String(value?.device_id || "").trim();
        const token = String(value?.token || "").trim();
        return employeeId && deviceId && token.length >= 40 ? { employeeId, deviceId, token } : null;
      },
      generateTrustedDeviceToken: () => "f".repeat(96),
      prepareEmployeePhoto: async () => ({
        file: fileObj,
        mimeType: "image/jpeg",
        extension: "jpg"
      }),
      FormData: class {
        constructor() { this.map = new Map(); }
        set(k, v, name) { this.map.set(k, { v, name }); }
      },
      AbortController,
      setTimeout,
      clearTimeout,
      TextEncoder,
      Uint8Array,
      Array,
      String,
      Error,
      JSON,
      crypto: globalThis.crypto,
      fetch: async (_url, opts) => {
        const empId = opts.body.map.get("employee_id").v;
        const f = opts.body.map.get("file").v;
        const bytes = new Uint8Array(await f.arrayBuffer());
        const r = await handleNewPhotoUpload(
          {
            method: "POST",
            headers: { origin },
            form: { employee_id: empId, fileName: "employee.jpg", mimeType: "image/jpeg", bytes }
          },
          uploadDeps,
          uploadState
        );
        return {
          ok: r.status >= 200 && r.status < 300,
          status: r.status,
          json: async () => r.body
        };
      }
    };
    vm.createContext(ctx);
    vm.runInContext(regCode, ctx);
    return ctx;
  }

  // Scenario 2 & 5: Upload valid JPEG photo, then simulate RPC Timeout on first registration attempt
  // Verify the real storage shape: shared code stores snake_case and returns camelCase.
  localStore.set("erp_pending_registration_v1", JSON.stringify({
    employee_id: syntheticNewId, device_id: "qa-fallback", token: "d".repeat(96)
  }));
  const fallbackTab = createRegistrationTab();
  assert.equal(fallbackTab.getOrCreatePendingOwnershipProof(syntheticNewId), "d".repeat(96),
    "Pending ownership proof must recover through normalized localStorage context");
  sessionStore.clear();
  localStore.clear();
  sessionStore.set("alb_pending_registration_owner_proof_v1", JSON.stringify({
    employeeId: syntheticNewId, token: "e".repeat(96)
  }));
  const regTab1 = createRegistrationTab();
  const deviceToken = regTab1.getOrCreatePendingOwnershipProof(syntheticNewId);
  assert.equal(deviceToken, "f".repeat(96), "Proof without expiry must use a new token");
  const newProof = JSON.parse(sessionStore.get("alb_pending_registration_owner_proof_v1"));
  assert.equal(newProof.token, deviceToken);
  assert.equal(newProof.employeeId, syntheticNewId);
  assert.ok(newProof.expiresAt > Date.now(), "New proof must carry a future expiry");
  const deviceId = "mobile-qa-new-101";
  const uploadedPath1 = await regTab1.photoForRegistrationRetry(syntheticNewId);
  assert.equal(db.storageUploadCount, 1, "Scenario 2: Valid JPEG uploaded once to Storage");
  assert.equal(db.attestations.get(uploadedPath1), syntheticNewId, "Scenario 2: Photo attested in PR #62 ledger");

  // Simulate RPC timeout on attempt 1 -> retry in same tab (Scenario 5)
  const uploadedPathRetrySameTab = await regTab1.photoForRegistrationRetry(syntheticNewId);
  assert.equal(uploadedPathRetrySameTab, uploadedPath1, "Scenario 5: Same-tab retry after timeout reuses exact photo path");
  assert.equal(db.storageUploadCount, 1, "Scenario 5 & 7: Zero duplicate upload on timeout retry");

  // Scenario 6 & 7: Simulate Page Reload (new tab VM context) and restore registration attempt
  const regTabAfterReload = createRegistrationTab();
  const tokenAfterReload = regTabAfterReload.getOrCreatePendingOwnershipProof(syntheticNewId);
  assert.equal(tokenAfterReload, deviceToken, "Scenario 6: Ownership proof restored after page reload");
  const uploadedPathAfterReload = await regTabAfterReload.photoForRegistrationRetry(syntheticNewId);
  assert.equal(uploadedPathAfterReload, uploadedPath1, "Scenario 6: Uploaded photo path restored from sessionStorage after page reload");
  assert.equal(db.storageUploadCount, 1, "Scenario 7: Storage upload count stays 1 after page reload recovery");

  // Scenario 1 & 4: Complete register_new_employee_request -> PENDING
  db.pendingUploads.set(uploadedPathAfterReload, "LINKED");
  db.employees.set(syntheticNewId, {
    id: "00000000-0000-4000-8000-000000000101",
    employee_id: syntheticNewId,
    full_name: "موظف اختبار اصطناعي جديد",
    mobile_number: syntheticMobile,
    specialty: "الإسعاف والطوارئ (DRS/NRS/EMT/MLT)",
    job_type: "طبيب",
    department: "الإسعاف والطوارئ (DRS/NRS/EMT/MLT)",
    employee_photo_url: uploadedPathAfterReload,
    registration_category: "PERMANENT",
    status: "PENDING",
    created_at: db.now,
    pending_trusted_device_token: deviceToken,
    pending_trusted_device_id: deviceId,
    trusted_device_enabled: false
  });
  regTabAfterReload.clearPendingUploadRecovery();
  localStore.set("erp_trusted_device_token_v1", deviceToken);
  localStore.set("erp_trusted_device_id_v1", deviceId);
  localStore.set(
    "erp_pending_registration_v1",
    JSON.stringify({ employee_id: syntheticNewId, device_id: deviceId, token: deviceToken })
  );
  assert.equal(db.employees.get(syntheticNewId).status, "PENDING", "Scenario 1 & 4: New employee registered in PENDING state");

  // -------------------------------------------------------------------------
  // Scenarios 8 & 9:
  // Photo display on Employee Profile (via employee-photo-url-new) and Admin
  // Dashboard (via Resolver v2) using the real employee-photo.js client!
  // -------------------------------------------------------------------------
  const empPhotoCode = fs.readFileSync(path.join(root, "employee-photo.js"), "utf8");
  function createPhotoClientEnv() {
    const win = {
      addEventListener() {},
      document: { documentElement: null },
      ALBASHIRRuntime: { report() {} }
    };
    const ctx = {
      window: win,
      document: win.document,
      console,
      URL: {
        createObjectURL: () => "blob:https://albashir-staging.vercel.app/" + crypto.randomUUID(),
        revokeObjectURL: () => {}
      },
      AbortController,
      setTimeout,
      clearTimeout,
      Date,
      Map,
      Set,
      WeakMap,
      Promise,
      Number,
      String,
      Array,
      Math,
      JSON,
      encodeURIComponent,
      decodeURIComponent,
      crypto: globalThis.crypto,
      fetch: async (url, opts) => {
        const u = new URL(url);
        if (u.pathname === "/functions/v1/employee-photo-url-new") {
          db.newResolverHits += 1;
          const body = JSON.parse(opts.body);
          const r = await handleNewPhotoRequest(
            { method: "POST", headers: { origin, authorization: opts.headers?.authorization || "" }, body },
            newResolverDeps
          );
          return { ok: r.status === 200, status: r.status, json: async () => r.body };
        }
        if (u.pathname === "/functions/v1/employee-photo-url") {
          db.legacyResolverHits += 1;
          const body = JSON.parse(opts.body);
          const r = await handleLegacyPhotoRequest(
            { method: "POST", headers: { origin, authorization: opts.headers?.authorization || "" }, body },
            legacyResolverDeps
          );
          return { ok: r.status === 200, status: r.status, json: async () => r.body };
        }
        if (u.pathname.startsWith("/storage/v1/object/sign/employee-photos/")) {
          return {
            ok: true,
            status: 200,
            blob: async () => ({ size: validJpegBytes.byteLength, type: "image/jpeg" })
          };
        }
        return { ok: false, status: 404, json: async () => ({ ok: false }) };
      }
    };
    vm.createContext(ctx);
    vm.runInContext(empPhotoCode, ctx);
    return win.EmployeePhoto;
  }

  const EmployeePhoto = createPhotoClientEnv();
  const appConfig = {
    SUPABASE_URL: "https://adwvokwucotohwayorgx.supabase.co",
    SUPABASE_ANON_KEY: "sb_publishable_stage"
  };

  // Scenario 9: Admin Dashboard displays the new employee's photo (while still PENDING)
  const adminImg = {
    src: "",
    style: {},
    attrs: new Map([
      ["data-photo-ref", uploadedPathAfterReload],
      ["data-photo-fallback", "./logo.jpeg"]
    ]),
    getAttribute(k) { return this.attrs.get(k) || ""; },
    setAttribute(k, v) { this.attrs.set(k, v); },
    removeAttribute(k) { this.attrs.delete(k); },
    matches(sel) { return sel === "[data-photo-ref]" && this.attrs.has("data-photo-ref"); }
  };
  await EmployeePhoto.hydrate(adminImg, { type: "admin", access_token: "valid-admin-jwt" }, appConfig, { eager: true });
  assert(adminImg.src.startsWith("blob:"), "Scenario 9: Admin dashboard must display new employee photo as blob URL");
  assert.equal(db.legacyResolverHits, 1, "Scenario 9: Admin photo resolves cleanly via existing Resolver v2 without UI edits");

  // Scenario 8: Employee Profile page displays the new employee's SHA-256 folder photo via employee-photo-url-new
  const empProfileImg = {
    src: "",
    style: {},
    attrs: new Map([
      ["data-photo-ref", uploadedPathAfterReload],
      ["data-photo-fallback", "./logo.jpeg"]
    ]),
    getAttribute(k) { return this.attrs.get(k) || ""; },
    setAttribute(k, v) { this.attrs.set(k, v); },
    removeAttribute(k) { this.attrs.delete(k); },
    matches(sel) { return sel === "[data-photo-ref]" && this.attrs.has("data-photo-ref"); }
  };
  await EmployeePhoto.hydrate(
    empProfileImg,
    { type: "employee", employee_id: syntheticNewId, mobile_number: syntheticMobile },
    appConfig,
    { eager: true }
  );
  assert(empProfileImg.src.startsWith("blob:"), "Scenario 8: Employee profile page must display new employee photo as blob URL");
  assert.equal(db.newResolverHits, 1, "Scenario 8: SHA-256 folder employee photo routed deterministically to employee-photo-url-new");

  // -------------------------------------------------------------------------
  // Scenario 10:
  // Admin approves registration -> Employee fast login from Trusted Device
  // without re-entering employee ID or mobile number, and views photo via
  // employee_device actor (server-side owner resolution without body.employee_id)
  // -------------------------------------------------------------------------
  const empRecord = db.employees.get(syntheticNewId);
  empRecord.status = "APPROVED";
  empRecord.trusted_device_enabled = true;
  empRecord.trusted_device_token = empRecord.pending_trusted_device_token;
  empRecord.trusted_device_id = empRecord.pending_trusted_device_id;

  // Fast login check (simulating portal.html -> trusted_device_profile_login)
  const savedToken = localStore.get("erp_trusted_device_token_v1");
  const savedDevId = localStore.get("erp_trusted_device_id_v1");
  const deviceVerified = await newResolverDeps.verifyTrustedDevice(savedToken, savedDevId);
  assert.equal(deviceVerified.ok, true, "Scenario 10: Approved trusted device authenticates automatically");
  assert.equal(deviceVerified.employeeId, syntheticNewId, "Scenario 10: Trusted device resolves exact synthetic employee ID");

  // Verify employee_device actor resolves photo on verify.html (where body.employee_id is omitted by employee-photo.js)
  EmployeePhoto.clearCache();
  const deviceVerifyImg = {
    src: "",
    style: {},
    attrs: new Map([
      ["data-photo-ref", uploadedPathAfterReload],
      ["data-photo-fallback", "./logo.jpeg"]
    ]),
    getAttribute(k) { return this.attrs.get(k) || ""; },
    setAttribute(k, v) { this.attrs.set(k, v); },
    removeAttribute(k) { this.attrs.delete(k); },
    matches(sel) { return sel === "[data-photo-ref]" && this.attrs.has("data-photo-ref"); }
  };
  await EmployeePhoto.hydrate(
    deviceVerifyImg,
    { type: "employee_device", device_token: savedToken, device_id: savedDevId },
    appConfig,
    { eager: true }
  );
  assert(deviceVerifyImg.src.startsWith("blob:"), "Scenario 10: Trusted device resolves new employee photo without client employee_id");
  assert.equal(db.newResolverHits, 2);

  // -------------------------------------------------------------------------
  // Scenarios 11, 12, 13, 14:
  // Guard QR Generation, Employee QR Scan/Verification, Guard Decision & Photo
  // Display, and 10-Second Privacy Auto-Hide on Guard Screen
  // -------------------------------------------------------------------------
  // Scenario 11: Guard generates QR
  const qrToken = "22222222-3333-4444-8555-666666666666";
  const guardReadKey = "a".repeat(64);
  db.qrSessions.set(qrToken, {
    id: qrToken,
    readKey: guardReadKey,
    expiresAt: db.now + 30000,
    result: null,
    employeeId: null
  });
  assert(db.qrSessions.has(qrToken), "Scenario 11: Guard QR session issued");

  // Scenario 12: Employee scans & verifies QR using approved trusted device
  const qrSession = db.qrSessions.get(qrToken);
  qrSession.result = "ALLOWED";
  qrSession.employeeId = syntheticNewId;
  qrSession.decidedAt = new Date(db.now).toISOString();

  // Scenario 13: Guard screen polls result and loads employee photo via public_guard_session read_key
  const guardPhotoRes = await handleLegacyPhotoRequest(
    {
      method: "POST",
      headers: { origin },
      body: { action: "resolve", actor: { type: "public_guard_session", read_key: guardReadKey } }
    },
    legacyResolverDeps
  );
  assert.equal(guardPhotoRes.status, 200, "Scenario 13: Guard screen resolves new employee photo with HTTP 200");
  assert(guardPhotoRes.body.url.includes("legacysigned60s"), "Scenario 13: Guard receives 60s signed URL");

  // Scenario 14: Verify guard.html 10-second privacy timer (startResultPrivacy -> clearResult after 10000ms)
  const guardHtml = fs.readFileSync(path.join(root, "guard.html"), "utf8");
  assert(
    guardHtml.includes("resultUntil=performance.now()+10000;resultPrivacyTimer=setTimeout(()=>clearResult(true),10000);"),
    "Scenario 14: Guard screen enforces 10-second display window"
  );
  assert(
    guardHtml.includes("el('result').hidden=true;el('qrPanel').hidden=false;") &&
      guardHtml.includes("el('photo').hidden=true;el('photo').removeAttribute('src');if(photoBlob){URL.revokeObjectURL(photoBlob);photoBlob=null;}"),
    "Scenario 14: Guard screen hides result, revokes photoBlob, and restores QR panel after 10s"
  );

  // -------------------------------------------------------------------------
  // Scenario 15:
  // Historical Employees (Standard + Arabic-digit IDs in registrations/-/)
  // Remain 100% Unaffected
  // -------------------------------------------------------------------------
  const newHitsBeforeHistorical = db.newResolverHits;
  for (const histId of ["OLD-HIST-01", "١٢٣٤٥٦"]) {
    const histEmp = db.employees.get(histId);
    const histImg = {
      src: "",
      style: {},
      attrs: new Map([
        ["data-photo-ref", histEmp.employee_photo_url],
        ["data-photo-fallback", "./logo.jpeg"]
      ]),
      getAttribute(k) { return this.attrs.get(k) || ""; },
      setAttribute(k, v) { this.attrs.set(k, v); },
      removeAttribute(k) { this.attrs.delete(k); },
      matches(sel) { return sel === "[data-photo-ref]" && this.attrs.has("data-photo-ref"); }
    };
    await EmployeePhoto.hydrate(
      histImg,
      { type: "employee", employee_id: histEmp.employee_id, mobile_number: histEmp.mobile_number },
      appConfig,
      { eager: true }
    );
    assert(histImg.src.startsWith("blob:"), `Scenario 15: Historical employee ${histId} photo must display normally`);
  }
  assert.equal(
    db.newResolverHits,
    newHitsBeforeHistorical,
    "Scenario 15: Historical employees must NEVER be routed to employee-photo-url-new"
  );

  console.log("PASS All 15 End-to-End Scenarios (Registration, JPEG Magic Bytes, Invalid Photo Reject, PENDING, Timeout Retry, Page-Reload Recovery, Zero Re-Upload, Employee Profile Photo, Admin Photo, Trusted-Device Fast Login, QR Generation, Guard QR Verification, Decision+Photo Display, 10s Privacy Hide, and Historical Cohort Isolation)");
})().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
