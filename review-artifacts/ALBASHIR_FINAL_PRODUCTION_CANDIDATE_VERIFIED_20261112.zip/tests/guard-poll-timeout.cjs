const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path'),{createHash}=require('node:crypto');
const html=fs.readFileSync(path.join(__dirname,'../guard.html'),'utf8');
const helper=html.slice(html.indexOf('async function guardRpc('),html.indexOf('async function createCandidate('));
const poll=html.slice(html.indexOf('function sessionActive(s)'),html.indexOf("el('refresh').onclick"));
(async()=>{
  let stalled=true,aborted=false,calls=0,warnings=0;
  const callOrder=[],timers=new Set();
  const subtle={digest:async(algorithm,bytes)=>Uint8Array.from(createHash('sha256').update(Buffer.from(bytes)).digest()).buffer};
  const c={navigator:{onLine:true},window:{crypto:{subtle}},TextEncoder,el:()=>({textContent:''}),AbortController,Date,Promise,Error,performance,resultUntil:0,pollSequence:0,deliveredResults:new Map(),pendingSignalSessions:new Set(),forcePollPending:false,polling:false,lastHealthyAt:0,current:null,
    RESULT_POLL_CURRENT_MS:5000,RESULT_POLL_RECENT_MS:5000,RESULT_POLL_OLD_MS:15000,RESULT_RECENT_WINDOW_MS:60000,
    sessions:[{key:'OLD',until:Date.now()+60000,displayed:true,nextPollAt:0,realtimeSubscribed:false,createdAt:performance.now()-120000},{key:'NEW',until:Date.now()+60000,displayed:true,nextPollAt:0,realtimeSubscribed:false,createdAt:performance.now()}],
    setTimeout:(fn,ms)=>{const t=setTimeout(fn,Math.min(ms,10));timers.add(t);return t;},clearTimeout:t=>{clearTimeout(t);timers.delete(t);},
    unavailable:()=>warnings++,client:{rpc:(name,payload)=>{calls++;callOrder.push(payload.p_read_key);assert.equal(name,'get_public_guard_result');assert(['NEW','OLD'].includes(payload.p_read_key));return {abortSignal:signal=>{signal.addEventListener('abort',()=>aborted=true);return stalled?new Promise(()=>{}):Promise.resolve({data:{ok:true,result:'WAITING'}});}}},removeChannel:async()=>{}}
  };
  vm.createContext(c);vm.runInContext(helper+poll,c);
  const key='a'.repeat(64),readHash=createHash('sha256').update(key).digest('hex');
  const expected={topic:'guard-result:'+createHash('sha256').update('guard-result-topic:'+readHash).digest('hex'),proof:createHash('sha256').update('guard-result-signal:'+readHash).digest('hex')};
  const credentials=await c.resultSignalCredentials(key);assert.equal(credentials.topic,expected.topic);assert.equal(credentials.proof,expected.proof);
  await c.poll();assert(aborted);assert.equal(c.polling,false);assert.equal(warnings,2);assert.equal(timers.size,0);assert.deepEqual(callOrder,['NEW','OLD']);
  stalled=false;c.sessions=c.sessions.slice(1);c.sessions[0].nextPollAt=0;await c.poll();assert.equal(c.polling,false);assert.equal(calls,3);assert.equal(timers.size,0);assert(c.lastHealthyAt>0);
  assert.equal(c.sessions[0].recoveryRequired,false);c.sessions[0].createdAt=performance.now()-120000;c.sessions[0].realtimeSubscribed=true;c.sessions[0].recoveryRequired=false;c.sessions[0].nextPollAt=0;c.current=null;assert.equal(c.resultPollInterval(c.sessions[0]),15000,'healthy Realtime on an older displayed session must use the 15s fallback');const oldPollStarted=performance.now();await c.poll();assert.equal(calls,4);assert(c.sessions[0].nextPollAt-oldPollStarted>14000,'poll scheduler must preserve the 15s interval');
  const other={key:'OTHER',until:Date.now()+60000,displayed:true,nextPollAt:0,realtimeSubscribed:true,createdAt:performance.now()-120000};c.sessions.push(other);c.sessions[0].nextPollAt=Infinity;await c.poll(c.sessions[0],true);assert.equal(calls,5);assert.equal(other.lastPolled,undefined);
  let broadcastHandler=null,channelTopic='',channelConfig=null,channelCreations=0;const signalCalls=[];
  c.client.channel=(topic,config)=>{channelCreations++;channelTopic=topic;channelConfig=config;const channel={on:(type,filter,callback)=>{assert.equal(type,'broadcast');assert.equal(filter.event,'result-ready');broadcastHandler=callback;return channel;},subscribe:callback=>{callback('SUBSCRIBED');return channel;}};return channel;};
  c.poll=async(session,force)=>signalCalls.push({session,force});
  const signalSession={key:'signal-key',topic:'signal-topic',proof:'valid-proof',until:Date.now()+60000,displayed:true,realtimeSubscribed:false,recoveryRequired:false,channel:null};
  c.sessions=[signalSession];c.subscribeResultChannel(signalSession);
  assert.equal(channelTopic,'signal-topic');assert.equal(channelConfig.config.private,false);assert.equal(signalSession.realtimeSubscribed,true);
  broadcastHandler({payload:{proof:'wrong-proof'}});assert.equal(signalCalls.length,0);
  broadcastHandler({payload:{proof:'valid-proof'}});assert.equal(signalCalls.length,1);assert.equal(signalCalls[0].session,signalSession);assert.equal(signalCalls[0].force,true);c.deliveredResults.set(signalSession.key,performance.now()+60000);signalSession.channel=null;c.subscribeResultChannel(signalSession);assert.equal(channelCreations,1,'delivered sessions must not reopen Realtime channels');
  assert(html.includes("guardRpc('create_public_guard_qr')"));
  assert(html.includes("client.channel(s.topic,{config:{private:false}})"));
  assert(html.includes("message?.payload?.proof??message?.proof"));
  assert(html.includes("RESULT_POLL_OLD_MS=15000"));
  assert(html.includes("poll(null,true)"));
  assert(!html.includes("setInterval(poll,1500)"));
  assert(html.includes("function clearResult(restorePending=false)"));
  assert(!html.includes("function clearResult(){") );
  console.log('PASS bounded RPC timeout, lock release, retry recovery, 5s/15s fallback, per-session hash/proof, signal-specific wake-up and proof validation');
})().catch(e=>{console.error(e);process.exitCode=1});
