/**
 * test_backend_pg_real.cjs
 * Comprehensive Real PostgreSQL (PGlite 18.3) Integration & Validation Suite
 * 
 * Executes the EXACT modified SQL against an isolated PostgreSQL engine:
 *  - Full baseline + 20261006190000_private_employee_photos migration
 *  - Reviewed new-only backend SQL (unlocked in-memory)
 *  - Reviewed photo upload quota SQL (unlocked in-memory)
 * 
 * Verifies:
 *  1. Registration & Retry lifecycle (12 scenarios)
 *  2. Atomic Photo Upload Quota RPC (claims, limits, release, roles, privacy)
 *  3. Historical 15-arg function compatibility (6 synthetic profiles)
 *  4. Production Rollback zero-destruction audit
 */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { PGlite } = require("@electric-sql/pglite");
const { pgcrypto } = require("@electric-sql/pglite/contrib/pgcrypto");

const root = path.resolve(__dirname, "..");
const baselineSql = fs.readFileSync(path.join(root, "schema_consolidated_fresh_install.sql"), "utf8");
const photoMigrationSql = fs.readFileSync(path.join(root, "supabase/migrations/20261006190000_private_employee_photos.sql"), "utf8");
const backendReviewSql = fs.readFileSync(path.join(root, "supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql"), "utf8");
const quotaReviewSql = fs.readFileSync(path.join(root, "supabase/review/NEW_ONLY_PHOTO_UPLOAD_QUOTA_REVIEW_LOCKED.sql"), "utf8");
const rollbackReviewSql = fs.readFileSync(path.join(root, "supabase/review/production_backend_ROLLBACK_LOCKED_20261111.sql"), "utf8");

// Helper to strip deployment locks for in-memory testing
function stripLocks(sql) {
  return sql.replace(/DO\s+\$[^$]+\$[\s\S]*?\$[^$]+\$;/g, "-- lock removed for test execution");
}

async function asRole(db, role, fn) {
  await db.exec(`SET ROLE ${role}`);
  try {
    return await fn();
  } finally {
    await db.exec("RESET ROLE");
  }
}

async function setupDatabase() {
  const db = new PGlite({ extensions: { pgcrypto } });

  // 1. Roles and Supabase foundation
  await db.exec(`
    CREATE ROLE anon;
    CREATE ROLE authenticated;
    CREATE ROLE service_role BYPASSRLS;

    CREATE SCHEMA extensions;
    CREATE EXTENSION pgcrypto WITH SCHEMA extensions;

    CREATE SCHEMA auth;
    CREATE TABLE auth.users (id uuid PRIMARY KEY, email text);
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
      SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
    $$;

    CREATE SCHEMA storage;
    CREATE TABLE storage.buckets (
      id text PRIMARY KEY,
      name text NOT NULL,
      public boolean DEFAULT false,
      file_size_limit bigint DEFAULT null,
      allowed_mime_types text[] DEFAULT null,
      created_at timestamptz DEFAULT now()
    );
    CREATE TABLE storage.objects (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      bucket_id text NOT NULL,
      name text NOT NULL,
      metadata jsonb,
      created_at timestamptz DEFAULT now(),
      UNIQUE (bucket_id, name)
    );
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
    CREATE FUNCTION storage.foldername(name text) RETURNS text[] LANGUAGE sql IMMUTABLE AS $$
      SELECT (string_to_array(name, '/'))[1:greatest(array_length(string_to_array(name, '/'), 1) - 1, 0)]
    $$;
    CREATE FUNCTION storage.extension(name text) RETURNS text LANGUAGE sql IMMUTABLE AS $$
      SELECT lower(substring(name FROM '\\.([^.]+)$'))
    $$;

    GRANT USAGE ON SCHEMA public, auth, storage, extensions TO anon, authenticated, service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA storage TO anon, authenticated, service_role;
    CREATE PUBLICATION supabase_realtime;
  `);

  // 2. Baseline consolidated fresh install
  await db.exec(baselineSql);

  // 3. Photo storage migration
  await db.exec(photoMigrationSql);

  // 4. Reviewed backend new-only SQL
  await db.exec(stripLocks(backendReviewSql));

  // 5. Reviewed quota SQL
  await db.exec(stripLocks(quotaReviewSql));

  return db;
}

// Helper to seed a valid pending photo upload
async function seedPhoto(db, employeeId, path) {
  await db.query(`
    INSERT INTO storage.objects (bucket_id, name, metadata)
    VALUES ('employee-photos', $1, '{"size": 1024, "mimetype": "image/jpeg"}'::jsonb)
    ON CONFLICT (bucket_id, name) DO NOTHING
  `, [path]);

  await db.query(`
    INSERT INTO private.pending_employee_uploads (object_path, status)
    VALUES ($1, 'PENDING')
    ON CONFLICT (object_path) DO NOTHING
  `, [path]);

  await db.query(`
    INSERT INTO private.new_employee_photo_attestations (object_path, employee_id)
    VALUES ($1, $2)
    ON CONFLICT (object_path) DO NOTHING
  `, [path, employeeId]);
}

// Helper to call register_new_employee_request
async function callRegisterNew(db, args) {
  const res = await db.query(`
    SELECT public.register_new_employee_request(
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15
    ) as result
  `, [
    args.full_name || 'طبيب تجريبي',
    args.employee_id,
    args.mobile_number || '0791234567',
    args.specialty || 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',
    args.qr_token || null,
    args.job_type || 'طبيب',
    args.department || 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',
    args.photo_url,
    args.device_token,
    args.device_id || 'dev-test-1',
    args.device_type || 'iOS',
    args.device_name || 'iPhone 15',
    args.user_agent || 'Safari Test',
    args.registration_category || 'PERMANENT',
    args.affiliated_entity || null
  ]);
  return res.rows[0].result;
}

// Helper to call claim_new_photo_upload_quota
async function callClaimQuota(db, { employee_id, source, max_emp = 5, max_src = 10, max_global = 100, window_sec = 3600, role = 'service_role' }) {
  return await asRole(db, role, async () => {
    const res = await db.query(`
      SELECT public.claim_new_photo_upload_quota($1, $2, $3, $4, $5, $6) as result
    `, [employee_id, source, max_emp, max_src, max_global, window_sec]);
    return res.rows[0].result;
  });
}

// Helper to call release_new_photo_upload_quota
async function callReleaseQuota(db, leaseIdOrEmp, source = null, role = 'service_role') {
  return await asRole(db, role, async () => {
    if (source === null) {
      const res = await db.query(`SELECT public.release_new_photo_upload_quota($1::uuid) as result`, [leaseIdOrEmp]);
      return res.rows[0].result;
    } else {
      const res = await db.query(`SELECT public.release_new_photo_upload_quota($1, $2) as result`, [leaseIdOrEmp, source]);
      return res.rows[0].result;
    }
  });
}

(async () => {
  console.log("================================================================================");
  console.log("STARTING REAL POSTGRESQL (PGLITE 18.3) INTEGRATION & VALIDATION TEST SUITE");
  console.log("================================================================================\n");

  const db = await setupDatabase();
  console.log("✅ PostgreSQL 18.3 database bootstrapped with all baseline, migration & review SQL.\n");

  const results = [];
  function record(suite, name, passed, detail = "") {
    results.push({ suite, name, passed, detail });
    const mark = passed ? "✅ PASS" : "❌ FAIL";
    console.log(`  ${mark}: [${suite}] ${name} ${detail ? "(" + detail + ")" : ""}`);
  }

  // --------------------------------------------------------------------------
  // PART 1: REGISTRATION & PENDING RETRY LIFECYCLE
  // --------------------------------------------------------------------------
  console.log("--- PART 1: REGISTRATION & RETRY TESTS ---");

  const tokenA = "a".repeat(96);
  const tokenB = "b".repeat(96);
  const emp1 = "EMP-REAL-001";
  const photo1 = `registrations/${emp1}/11111111-2222-3333-4444-555555555555.jpg`;

  await seedPhoto(db, emp1, photo1);

  // 1.1 First-time registration
  const r1 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenA
  });
  record("Registration", "First-time registration creates 1 PENDING row",
    r1.ok === true && r1.result === "PENDING" && r1.message.includes("الرجاء انتظار موافقة"),
    r1.message);

  // 1.2 Automatic Trigger linking
  const ledger1 = (await db.query(`SELECT * FROM private.pending_employee_uploads WHERE object_path = $1`, [photo1])).rows[0];
  const regRow1 = (await db.query(`SELECT * FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0];
  record("Trigger", "trg_link_pending_employee_upload sets status=LINKED and registration_id",
    ledger1.status === "LINKED" && ledger1.employee_id === emp1 && ledger1.registration_id === regRow1.id,
    `status=${ledger1.status}, reg_id=${ledger1.registration_id}`);

  // 1.3 Idempotent retry with SAME token
  const r2 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenA
  });
  const count1 = (await db.query(`SELECT count(*)::int as count FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].count;
  record("Idempotency", "Idempotent retry with same token returns PENDING without duplicate row",
    r2.ok === true && r2.result === "PENDING" && r2.message.includes("تم إرسال طلبك مسبقاً") && count1 === 1,
    `rows=${count1}`);

  // 1.4 Hijacking attempt with FOREIGN token
  const r3 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenB
  });
  const countAfterHijack = (await db.query(`SELECT count(*)::int as count FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].count;
  const hashAfterHijack = (await db.query(`SELECT pending_trusted_device_token_hash FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].pending_trusted_device_token_hash;
  record("Anti-Hijack", "Registration attempt with different device token denied, data preserved",
    r3.ok === false && r3.result === "DENIED" && r3.message.includes("تعذر التحقق من ملكية الطلب المعلق") && countAfterHijack === 1 && hashAfterHijack === regRow1.pending_trusted_device_token_hash,
    r3.message);

  // 1.5 Short/empty token denied
  const r4 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: "short-token"
  });
  record("Proof-Safety", "Short/invalid token denied",
    r4.ok === false && r4.result === "DENIED",
    r4.message);

  // 1.6 Photo replacement attempt during retry denied
  const fakePhoto = `registrations/${emp1}/99999999-8888-7777-6666-555555555555.jpg`;
  await seedPhoto(db, emp1, fakePhoto);
  const r5 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: fakePhoto,
    device_token: tokenA
  });
  record("Photo-Protection", "Photo replacement on PENDING request denied, stored photo preserved",
    r5.ok === false && r5.result === "DENIED" && r5.message.includes("تعذر تغيير صورة الطلب المعلق"),
    r5.message);

  // 1.7 Legitimate owner edit of allow-listed fields
  const r6 = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenA,
    mobile_number: "0799999999" // updated mobile
  });
  const regRowUpdated = (await db.query(`SELECT * FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0];
  record("Owner-Edit", "Verified owner can update allow-listed fields while preserving ID/device/photo",
    r6.ok === true && r6.result === "PENDING" && r6.message.includes("تم تحديث طلبك بنجاح") &&
    regRowUpdated.mobile_number === "0799999999" && regRowUpdated.id === regRow1.id &&
    regRowUpdated.employee_photo_url === photo1 && regRowUpdated.pending_trusted_device_token_hash === regRow1.pending_trusted_device_token_hash,
    `new_mobile=${regRowUpdated.mobile_number}`);

  // 1.8 Re-registration by APPROVED employee denied
  await db.query(`UPDATE public.employee_registrations SET status = 'APPROVED' WHERE employee_id = $1`, [emp1]);
  // 1.8a: Retry with same already-LINKED photo rejected at outer photo gate
  const r7a = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenA
  });
  record("Approved-Guard-Outer", "Re-registration with old linked photo rejected at photo gate",
    r7a.ok === false && r7a.result === "DENIED",
    r7a.message);

  // 1.8b: Re-registration attempt with fresh pending photo reaches core and returns approved domain message
  const photoAppFresh = `registrations/${emp1}/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.jpg`;
  await seedPhoto(db, emp1, photoAppFresh);
  const r7b = await callRegisterNew(db, {
    employee_id: emp1,
    photo_url: photoAppFresh,
    device_token: tokenA
  });
  const approvedStatus = (await db.query(`SELECT status FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].status;
  record("Approved-Guard-Core", "APPROVED employee cannot re-register or overwrite account",
    r7b.ok === false && r7b.result === "DENIED" && r7b.message.includes("تم اعتماد هذا الحساب مسبقاً") && approvedStatus === "APPROVED",
    r7b.message);

  // 1.9 Re-registration by REJECTED employee denied and audited
  const empRej = "EMP-REJ-001";
  const photoRej = `registrations/${empRej}/22222222-3333-4444-5555-666666666666.jpg`;
  await seedPhoto(db, empRej, photoRej);
  await callRegisterNew(db, { employee_id: empRej, photo_url: photoRej, device_token: tokenA });
  await db.query(`UPDATE public.employee_registrations SET status = 'REJECTED' WHERE employee_id = $1`, [empRej]);
  // Fresh pending photo for re-registration attempt
  const photoRejFresh = `registrations/${empRej}/33333333-4444-5555-6666-777777777777.jpg`;
  await seedPhoto(db, empRej, photoRejFresh);
  const r8 = await callRegisterNew(db, { employee_id: empRej, photo_url: photoRejFresh, device_token: tokenA });
  const rejLogs = (await db.query(`SELECT * FROM public.gate_access_logs WHERE employee_id = $1 AND reason = 'REJECTED_EMPLOYEE'`, [empRej])).rows;
  record("Rejected-Guard", "REJECTED employee cannot re-register and attempt is logged",
    r8.ok === true && r8.result === "DENIED" && r8.message.includes("تم رفض الطلب") && rejLogs.length >= 1,
    `logged_reason=${rejLogs[0]?.reason}`);

  // 1.10 Historic employee denied on new route
  const empHist = "EMP-HIST-001";
  const photoHist = `registrations/${empHist}/44444444-5555-6666-7777-888888888888.jpg`;
  // insert directly as historic row before cutoff
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url)
    VALUES ('موظف تاريخي', $1, '0791111111', 'طوارئ', 'APPROVED', now() - interval '1 year', 'registrations/hist/old.jpg')
  `, [empHist]);
  // Fresh pending photo for new route attempt
  await seedPhoto(db, empHist, photoHist);
  const r9 = await callRegisterNew(db, { employee_id: empHist, photo_url: photoHist, device_token: tokenA });
  record("Historic-Guard", "Historic employee denied on new route with redirect message",
    r9.ok === false && r9.result === "DENIED" && r9.message.includes("هذا المسار للموظفين الجدد فقط"),
    r9.message);

  // 1.11 Photo bound to another registration denied
  const empOther = "EMP-OTHER-001";
  const r10 = await callRegisterNew(db, { employee_id: empOther, photo_url: photo1, device_token: tokenA });
  record("Cross-Photo-Guard", "Attaching another employee's photo denied before evaluating ID",
    r10.ok === false && r10.result === "DENIED",
    r10.message);

  // 1.12 SECURITY DEFINER ACL & Direct Private Table Access
  let coreDenied = false;
  try {
    await asRole(db, "anon", async () => {
      await db.query(`SELECT private.register_employee_request_new_core('a','b','c','d',null,'e','f','g','h','i','j','k','l','m','n')`);
    });
  } catch (e) {
    coreDenied = /permission denied/.test(e.message);
  }
  let quotaAnonDenied = false;
  try {
    const qAnon = await callClaimQuota(db, { employee_id: "SYN-1", source: "src-1", role: "anon" });
    quotaAnonDenied = qAnon.allowed === false && qAnon.reason === "UNAUTHORIZED_ROLE";
  } catch (e) {
    quotaAnonDenied = /permission denied/.test(e.message);
  }
  let attestAnonDenied = false;
  try {
    await asRole(db, "anon", async () => {
      await db.query(`SELECT public.attest_new_employee_photo('SYN-1', 'path')`);
    });
  } catch (e) {
    attestAnonDenied = /permission denied/.test(e.message);
  }
  record("ACL-Hardening", "Direct execution of private core, quota RPC & attestation denied to anon",
    coreDenied && quotaAnonDenied && attestAnonDenied,
    `core=${coreDenied}, quota=${quotaAnonDenied}, attest=${attestAnonDenied}`);

  console.log("\n--- PART 2: ATOMIC PHOTO UPLOAD QUOTA TESTS ---");

  // 2.1 Authorized service_role claim
  const q1 = await callClaimQuota(db, {
    employee_id: "EMP-QUOTA-1",
    source: "fingerprint-alpha",
    max_emp: 3,
    max_src: 5,
    max_global: 20
  });
  record("Quota-Claim", "service_role successfully claims upload quota",
    q1.allowed === true && q1.reason === "ALLOWED" && q1.employee_remaining === 2,
    `employee_remaining=${q1.employee_remaining}`);

  // 2.2 Input sanitization & control characters
  const qBadId = await callClaimQuota(db, { employee_id: "BAD\nID", source: "src-1" });
  const qBadSrc = await callClaimQuota(db, { employee_id: "EMP-1", source: "SRC\tBAD" });
  record("Quota-Sanitization", "Control characters and invalid inputs rejected",
    qBadId.allowed === false && qBadId.reason === "INVALID_EMPLOYEE_ID" &&
    qBadSrc.allowed === false && qBadSrc.reason === "INVALID_SOURCE_FINGERPRINT",
    `badId=${qBadId.reason}, badSrc=${qBadSrc.reason}`);

  // 2.3 Per-Employee limit enforcement
  const qEmpExhaust1 = await callClaimQuota(db, { employee_id: "EMP-LIMITED", source: "src-x", max_emp: 2, max_src: 10, max_global: 50 });
  await asRole(db, 'service_role', async () => {
    await db.query(`SELECT public.consume_new_photo_upload_quota($1::uuid)`, [qEmpExhaust1.lease_id]);
    await db.query(`SELECT public.finalize_new_photo_upload_quota($1::uuid)`, [qEmpExhaust1.lease_id]);
  });
  const qEmpExhaust2 = await callClaimQuota(db, { employee_id: "EMP-LIMITED", source: "src-y", max_emp: 2, max_src: 10, max_global: 50 });
  await asRole(db, 'service_role', async () => {
    await db.query(`SELECT public.consume_new_photo_upload_quota($1::uuid)`, [qEmpExhaust2.lease_id]);
    await db.query(`SELECT public.finalize_new_photo_upload_quota($1::uuid)`, [qEmpExhaust2.lease_id]);
  });
  const qEmpExhaust3 = await callClaimQuota(db, { employee_id: "EMP-LIMITED", source: "src-z", max_emp: 2, max_src: 10, max_global: 50 });
  record("Quota-PerEmployee", "Per-Employee quota strictly enforced and returns retry_after_seconds",
    qEmpExhaust1.allowed === true && qEmpExhaust2.allowed === true &&
    qEmpExhaust3.allowed === false && qEmpExhaust3.reason === "QUOTA_EXCEEDED_EMPLOYEE" && qEmpExhaust3.retry_after_seconds > 0,
    `retry_after=${qEmpExhaust3.retry_after_seconds}s`);

  // 2.3b In-Flight Concurrent Upload Lock
  const qInflight1 = await callClaimQuota(db, { employee_id: "EMP-INFLIGHT", source: "src-1" });
  const qInflight2 = await callClaimQuota(db, { employee_id: "EMP-INFLIGHT", source: "src-2" });
  record("Quota-InFlightLock", "Simultaneous active upload for same employee blocked with CONCURRENT_UPLOAD_LOCKED",
    qInflight1.allowed === true && qInflight2.allowed === false && qInflight2.reason === "CONCURRENT_UPLOAD_LOCKED",
    `q1=${qInflight1.allowed}, q2_reason=${qInflight2.reason}`);

  // 2.3c Rollover Immunity: Releasing an old claim after window rollover never decrements new window
  const qRollClaim = await callClaimQuota(db, { employee_id: "EMP-ROLLOVER", source: "src-roll", max_emp: 5, max_src: 10, max_global: 100 });
  // Manually roll the quota window forward and simulate 2 attempts in the new window
  const empScope = (await db.query(`SELECT emp_scope FROM private.new_photo_upload_claims WHERE lease_id = $1`, [qRollClaim.lease_id])).rows[0].emp_scope;
  await db.query(`UPDATE private.new_photo_upload_quotas SET window_started_at = now() + interval '2 hours', attempt_count = 2 WHERE scope_key = $1`, [empScope]);
  // Release the claim from the old window
  const qRollRel = await callReleaseQuota(db, qRollClaim.lease_id);
  const countAfterRollRelease = (await db.query(`SELECT attempt_count FROM private.new_photo_upload_quotas WHERE scope_key = $1`, [empScope])).rows[0].attempt_count;
  record("Quota-RolloverImmunity", "Releasing an old-window claim transitions to RELEASED without decrementing new window counter",
    qRollRel.allowed === true && qRollRel.reason === "RELEASED" && countAfterRollRelease === 2,
    `relReason=${qRollRel.reason}, newWindowCount=${countAfterRollRelease}`);

  // 2.3d Dropped Overload: Ensure public.release_new_photo_upload_quota(text, text) is completely dropped
  let legacyReleaseDropped = false;
  try {
    await db.query(`SELECT public.release_new_photo_upload_quota('EMP-1'::text, 'src-1'::text)`);
  } catch (e) {
    legacyReleaseDropped = /does not exist|no function matches/i.test(e.message);
  }
  record("Quota-DroppedOverload", "Ambiguous two-argument release_new_photo_upload_quota(text, text) removed",
    legacyReleaseDropped, `dropped=${legacyReleaseDropped}`);

  // 2.4 Per-Source limit enforcement
  const qSrc1 = await callClaimQuota(db, { employee_id: "EMP-S1", source: "fingerprint-shared", max_emp: 10, max_src: 2, max_global: 50 });
  const qSrc2 = await callClaimQuota(db, { employee_id: "EMP-S2", source: "fingerprint-shared", max_emp: 10, max_src: 2, max_global: 50 });
  const qSrc3 = await callClaimQuota(db, { employee_id: "EMP-S3", source: "fingerprint-shared", max_emp: 10, max_src: 2, max_global: 50 });
  record("Quota-PerSource", "Per-Source fingerprint quota strictly enforced across different employees",
    qSrc1.allowed === true && qSrc2.allowed === true &&
    qSrc3.allowed === false && qSrc3.reason === "QUOTA_EXCEEDED_SOURCE" && qSrc3.retry_after_seconds > 0,
    `reason=${qSrc3.reason}`);

  // 2.5 Global Hard Cap enforcement
  const currGlobal = (await db.query(`SELECT attempt_count FROM private.new_photo_upload_quotas WHERE scope_key = 'global'`)).rows[0]?.attempt_count || 0;
  const targetCap = currGlobal + 2;
  const qG1 = await callClaimQuota(db, { employee_id: "EMP-G1", source: "src-g1", max_emp: 10, max_src: 10, max_global: targetCap });
  const qG2 = await callClaimQuota(db, { employee_id: "EMP-G2", source: "src-g2", max_emp: 10, max_src: 10, max_global: targetCap });
  const qG3 = await callClaimQuota(db, { employee_id: "EMP-G3", source: "src-g3", max_emp: 10, max_src: 10, max_global: targetCap });
  record("Quota-GlobalCap", "Global hard cap halts claims system-wide when saturated",
    qG1.allowed === true && qG2.allowed === true &&
    qG3.allowed === false && qG3.reason === "QUOTA_EXCEEDED_GLOBAL" && qG3.retry_after_seconds > 0,
    `targetCap=${targetCap}, qG1=${qG1.allowed}, qG2=${qG2.allowed}, qG3_reason=${qG3.reason}`);

  // 2.6 Atomic Release with Lease ID (Anti-Replay / Idempotent)
  const qClaimToRelease = await callClaimQuota(db, { employee_id: "EMP-TO-RELEASE", source: "src-rel", max_emp: 1, max_src: 10, max_global: 50 });
  const leaseId = qClaimToRelease.lease_id;
  assert.ok(leaseId, "claim must issue a valid lease_id");

  // Attempt before release fails because limit is 1
  const qBeforeRel = await callClaimQuota(db, { employee_id: "EMP-TO-RELEASE", source: "src-rel2", max_emp: 1, max_src: 10, max_global: 50 });
  assert.equal(qBeforeRel.allowed, false);

  // First release succeeds
  const qRel1 = await callReleaseQuota(db, leaseId);
  // Duplicate release with SAME lease_id rejected (anti-replay)
  const qRel2 = await callReleaseQuota(db, leaseId);
  // Subsequent claim succeeds because counter was decremented exactly once
  const qAfterRel = await callClaimQuota(db, { employee_id: "EMP-TO-RELEASE", source: "src-new", max_emp: 1, max_src: 10, max_global: 50 });

  record("Quota-AtomicRelease", "Atomic release restores quota and blocks replay attacks",
    qRel1.allowed === true && qRel1.reason === "RELEASED" &&
    qRel2.allowed === false && qRel2.reason === "ALREADY_RELEASED" &&
    qAfterRel.allowed === true,
    `rel1=${qRel1.reason}, rel2=${qRel2.reason}, afterAllowed=${qAfterRel.allowed}`);

  // 2.7 Privacy Verification: No raw IP or identifiers in private.new_photo_upload_quotas
  const rawScopes = (await db.query(`SELECT scope_key FROM private.new_photo_upload_quotas`)).rows.map(r => r.scope_key);
  const privacyClean = rawScopes.every(k => k === "global" || k.startsWith("emp:") || k.startsWith("src:"));
  const noRawValues = rawScopes.every(k => !k.includes("fingerprint") && !k.includes("EMP-") && !k.includes("192.168."));
  record("Quota-Privacy", "Only SHA-256 hashed keys stored in private quota ledger; zero raw IP leakage",
    privacyClean && noRawValues && rawScopes.length > 0,
    `total_scopes=${rawScopes.length}`);

  console.log("\n--- PART 3: HISTORICAL 15-ARG COMPATIBILITY TESTS ---");

  // Helper to test legacy 15-arg call
  async function callLegacy15(db, args) {
    const res = await db.query(`
      SELECT public.register_employee_request(
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15
      ) as result
    `, [
      args.full_name || 'موظف تاريخي',
      args.employee_id,
      args.mobile_number || '0795555555',
      args.specialty || 'تمريض',
      args.qr_token || null,
      args.job_type || 'ممرض',
      args.department || 'تمريض',
      args.photo_url || 'registrations/test/photo.jpg',
      args.device_token || tokenA,
      args.device_id || 'dev-hist-1',
      args.device_type || 'Android',
      args.device_name || 'Galaxy S21',
      args.user_agent || 'Chrome Mobile',
      args.registration_category || 'PERMANENT',
      args.affiliated_entity || null
    ]);
    return res.rows[0].result;
  }

  // 3.1 Historic APPROVED Employee
  const empH1 = "HIST-APP-01";
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('د. أحمد تاريخي', $1, '0795555551', 'جراحة', 'APPROVED', now() - interval '60 days', 'registrations/hist/p1.jpg', 'طبيب', 'جراحة', 'PERMANENT')
  `, [empH1]);
  const leg1 = await callLegacy15(db, { employee_id: empH1, mobile_number: '0795555551', department: 'جراحة', job_type: 'طبيب' });
  record("Legacy-15Arg", "Historic APPROVED employee passes cutoff fence into manual_employee_check branch",
    leg1 !== null && typeof leg1 === "object",
    JSON.stringify(leg1));

  // 3.2 Historic PENDING Employee
  const empH2 = "HIST-PND-02";
  const tokenHist = "h".repeat(96);
  const hashHist = crypto.createHash("sha256").update(tokenHist).digest("hex");
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, pending_trusted_device_token_hash, job_type, department, registration_category)
    VALUES ('ممرض تاريخي', $1, '0795555552', 'تمريض', 'PENDING', now() - interval '40 days', 'registrations/hist/p2.jpg', $2, 'ممرض', 'تمريض', 'PERMANENT')
  `, [empH2, hashHist]);
  const leg2 = await callLegacy15(db, { employee_id: empH2, mobile_number: '0795555552', device_token: tokenHist, department: 'تمريض', job_type: 'ممرض' });
  record("Legacy-15Arg", "Historic PENDING employee passes fence and executes legacy PENDING branch",
    leg2.ok === true && (leg2.result === "PENDING" || leg2.result === "DENIED"),
    `result=${leg2.result}`);

  // 3.3 Historic REJECTED Employee
  const empH3 = "HIST-REJ-03";
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('مرفوض تاريخي', $1, '0795555553', 'صيدلة', 'REJECTED', now() - interval '30 days', 'registrations/hist/p3.jpg', 'صيدلي', 'صيدلة', 'PERMANENT')
  `, [empH3]);
  const leg3 = await callLegacy15(db, { employee_id: empH3, mobile_number: '0795555553', department: 'صيدلة', job_type: 'صيدلي' });
  record("Legacy-15Arg", "Historic REJECTED employee passes fence and returns original rejection message",
    leg3.ok === true && leg3.result === "DENIED" && leg3.message.includes("تم رفض الطلب"),
    leg3.message);

  // 3.4 Non-Standard ID with Arabic Digits (e.g. م-١٢٣٤٥)
  const empH4 = "م-١٢٣٤٥";
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('موظف عربي الأرقام', $1, '0795555554', 'طوارئ', 'APPROVED', now() - interval '50 days', 'registrations/hist/p4.jpg', 'طبيب', 'طوارئ', 'PERMANENT')
  `, [empH4]);
  const leg4 = await callLegacy15(db, { employee_id: empH4, mobile_number: '0795555554', department: 'طوارئ', job_type: 'طبيب' });
  record("Legacy-15Arg", "Historic non-standard Arabic digit ID handled cleanly without corruption",
    leg4 !== null && typeof leg4 === "object",
    JSON.stringify(leg4));

  // 3.5 Historic 10-Digit National ID (e.g. 9988776655)
  const empH5 = "9988776655";
  await db.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('رقم وطني عشري', $1, '0795555555', 'إداري', 'APPROVED', now() - interval '45 days', 'registrations/hist/p5.jpg', 'إداري', 'إداري', 'PERMANENT')
  `, [empH5]);
  const leg5 = await callLegacy15(db, { employee_id: empH5, mobile_number: '0795555555', department: 'إداري', job_type: 'إداري' });
  record("Legacy-15Arg", "Historic 10-digit national ID handled cleanly",
    leg5 !== null && typeof leg5 === "object",
    JSON.stringify(leg5));

  // 3.6 Non-historic employee calling legacy 15-arg blocked by fence
  const empNewCallOld = "NEW-ATTEMPT-OLD";
  const leg6 = await callLegacy15(db, { employee_id: empNewCallOld, mobile_number: '0795555556', department: 'طوارئ', job_type: 'طبيب' });
  record("Legacy-Fence", "Non-historic caller denied by cutoff fence on 15-arg function",
    leg6.ok === false && leg6.result === "DENIED" && leg6.message.includes("هذا المسار للموظفين المسجلين سابقاً فقط"),
    leg6.message);

  console.log("\n--- PART 4: ROLLBACK SAFETY & AUDIT ---");

  // Snapshot before rollback
  const histCountBefore = (await db.query(`SELECT count(*)::int as c FROM public.employee_registrations WHERE created_at < (SELECT freeze_at FROM private.legacy_registration_cutoff LIMIT 1)`)).rows[0].c;
  const photosCountBefore = (await db.query(`SELECT count(*)::int as c FROM storage.objects WHERE bucket_id = 'employee-photos'`)).rows[0].c;

  // Execute rollback script (unlocked in-memory)
  await db.exec(stripLocks(rollbackReviewSql));

  // Verify state after rollback
  const histCountAfter = (await db.query(`SELECT count(*)::int as c FROM public.employee_registrations WHERE created_at < now() - interval '10 days'`)).rows[0].c;
  const photosCountAfter = (await db.query(`SELECT count(*)::int as c FROM storage.objects WHERE bucket_id = 'employee-photos'`)).rows[0].c;

  // Verify new RPC is revoked
  let newRpcRevoked = false;
  try {
    await asRole(db, "anon", async () => {
      await db.query(`SELECT public.register_new_employee_request('a','b','c','d',null,'e','f','g','h','i','j','k','l','m','n')`);
    });
  } catch (e) {
    newRpcRevoked = /permission denied/.test(e.message);
  }

  record("Rollback-ZeroLoss", "Rollback executed cleanly with 0 deleted historic employees or photos",
    histCountBefore === histCountAfter && photosCountBefore === photosCountAfter && histCountAfter >= 5,
    `hist_before=${histCountBefore}, hist_after=${histCountAfter}, photos=${photosCountAfter}`);

  record("Rollback-RPCRevocation", "Rollback successfully revokes new-only registration RPC",
    newRpcRevoked,
    `newRpcRevoked=${newRpcRevoked}`);

  // Summary
  console.log("\n================================================================================");
  const total = results.length;
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  console.log(`TOTAL REAL POSTGRESQL TESTS: ${total} | PASSED: ${passed} | FAILED: ${failed}`);
  console.log("================================================================================");

  if (failed > 0) {
    console.error(`❌ SUITE FAILED with ${failed} failures!`);
    process.exit(1);
  } else {
    console.log("🎉 ALL REAL POSTGRESQL TESTS PASSED PERFECTLY!");
    process.exit(0);
  }
})();
