/**
 * test_backend_pg17_server.cjs
 * Comprehensive Integration & Validation Suite executed against REAL PostgreSQL 17 Server.
 * 
 * Executes all 31 test scenarios over TCP against standalone PostgreSQL 17.2:
 *  1. Registration & Retry lifecycle (12 scenarios)
 *  2. Atomic Photo Upload Quota RPC (claims, limits, release, roles, privacy)
 *  3. Historical 15-arg function compatibility (6 synthetic profiles)
 *  4. Production Rollback zero-destruction audit
 */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { Client } = require("pg");

const root = path.resolve(__dirname, "..");
const dsn = process.env.ALBASHIR_LOCAL_PG_DSN || "postgresql://postgres@127.0.0.1:5432/albashir_qa";

let testResults = [];
function record(testName, description, passed, detail = "") {
  testResults.push({ testName, description, passed, detail });
  const status = passed ? "✅ PASS" : "❌ FAIL";
  console.log(`  ${status}: [${testName}] ${description} (${detail})`);
}

async function asRole(client, role, fn) {
  await client.query(`SET ROLE ${role}`);
  try {
    return await fn();
  } finally {
    await client.query("RESET ROLE");
  }
}

async function seedPhoto(client, employeeId, photoPath) {
  await client.query(`
    INSERT INTO storage.objects (bucket_id, name, metadata)
    VALUES ('employee-photos', $1, '{"size": 1024, "mimetype": "image/jpeg"}'::jsonb)
    ON CONFLICT (bucket_id, name) DO NOTHING
  `, [photoPath]);

  await client.query(`
    INSERT INTO private.pending_employee_uploads (object_path, status)
    VALUES ($1, 'PENDING')
    ON CONFLICT (object_path) DO NOTHING
  `, [photoPath]);

  await client.query(`
    INSERT INTO private.new_employee_photo_attestations (object_path, employee_id)
    VALUES ($1, $2)
    ON CONFLICT (object_path) DO NOTHING
  `, [photoPath, employeeId]);
}

async function callRegisterNew(client, args) {
  const res = await client.query(`
    SELECT public.register_new_employee_request(
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15
    ) as result
  `, [
    args.full_name || 'طبيب تجريبي',
    args.employee_id,
    args.mobile_number || '0791234567',
    args.specialty || 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',
    args.qr_token || null,
    args.job_type || 'طبيب',
    args.department || 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',
    args.photo_url,
    args.device_token || null,
    args.device_id || 'dev-test-1',
    args.device_type || 'mobile',
    args.device_name || 'iPhone 15',
    args.user_agent || 'Mozilla/5.0 iOS Safari',
    args.registration_category || 'PERMANENT',
    args.affiliated_entity || null
  ]);
  return res.rows[0].result;
}

async function callClaimQuota(client, args) {
  return await asRole(client, 'service_role', async () => {
    const res = await client.query(`
      SELECT public.claim_new_photo_upload_quota(
        $1, $2, $3, $4, $5, $6
      ) as quota
    `, [
      args.employee_id,
      args.source || 'fingerprint-default',
      args.max_emp || 5,
      args.max_src || 10,
      args.max_global || 100,
      args.window_sec || 3600
    ]);
    return res.rows[0].quota;
  });
}

async function callReleaseQuota(client, leaseId) {
  return await asRole(client, 'service_role', async () => {
    const res = await client.query(`SELECT public.release_new_photo_upload_quota($1::uuid) as r`, [leaseId]);
    return res.rows[0].r;
  });
}

function stripLocks(sql) {
  return sql.replace(/DO\s+\$[^$]+\$[\s\S]*?\$[^$]+\$;/g, "-- lock removed for test execution");
}

async function setupDatabase(client) {
  await client.query(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    DROP SCHEMA IF EXISTS private CASCADE;
    CREATE SCHEMA private;

    DO $$ BEGIN
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN CREATE ROLE anon; END IF;
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN CREATE ROLE authenticated; END IF;
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'service_role') THEN CREATE ROLE service_role BYPASSRLS; END IF;
    END $$;

    CREATE SCHEMA IF NOT EXISTS extensions;
    CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY, email text);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
      SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
    $$;

    CREATE SCHEMA IF NOT EXISTS storage;
    CREATE TABLE IF NOT EXISTS storage.buckets (
      id text PRIMARY KEY,
      name text NOT NULL,
      public boolean DEFAULT false,
      file_size_limit bigint DEFAULT null,
      allowed_mime_types text[] DEFAULT null,
      created_at timestamptz DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS storage.objects (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      bucket_id text NOT NULL,
      name text NOT NULL,
      metadata jsonb,
      created_at timestamptz DEFAULT now(),
      UNIQUE (bucket_id, name)
    );
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

    CREATE OR REPLACE FUNCTION storage.foldername(name text) RETURNS text[] LANGUAGE sql IMMUTABLE AS $$
      SELECT (string_to_array(name, '/'))[1:greatest(array_length(string_to_array(name, '/'), 1) - 1, 0)]
    $$;
    CREATE OR REPLACE FUNCTION storage.extension(name text) RETURNS text LANGUAGE sql IMMUTABLE AS $$
      SELECT lower(substring(name FROM '\\.([^.]+)$'))
    $$;

    GRANT USAGE ON SCHEMA public, auth, storage, extensions TO anon, authenticated, service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA storage TO anon, authenticated, service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA storage TO anon, authenticated, service_role;

    DO $$ BEGIN
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_publication WHERE pubname = 'supabase_realtime') THEN
        CREATE PUBLICATION supabase_realtime;
      END IF;
    END $$;
  `);

  const baselineSql = fs.readFileSync(path.join(root, "schema_consolidated_fresh_install.sql"), "utf8");
  await client.query(baselineSql);

  const photoMigrationSql = fs.readFileSync(path.join(root, "supabase/migrations/20261006190000_private_employee_photos.sql"), "utf8");
  await client.query(photoMigrationSql);

  const backendReviewSql = fs.readFileSync(path.join(root, "supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql"), "utf8");
  await client.query(stripLocks(backendReviewSql));

  const quotaReviewSql = fs.readFileSync(path.join(root, "supabase/review/NEW_ONLY_PHOTO_UPLOAD_QUOTA_REVIEW_LOCKED.sql"), "utf8");
  await client.query(stripLocks(quotaReviewSql));
}

async function main() {
  console.log("================================================================================");
  console.log("STARTING REAL STANDALONE POSTGRESQL 17 SERVER VALIDATION TEST SUITE");
  console.log("================================================================================");

  const client = new Client({ connectionString: dsn });
  await client.connect();

  const ver = (await client.query("SELECT version()")).rows[0].version;
  console.log(`\n✅ Connected to Standalone Database: ${ver}`);

  await setupDatabase(client);

  console.log("\n--- PART 1: REGISTRATION & RETRY TESTS ---");
  const emp1 = "EMP-REAL-001";
  const photo1 = `registrations/${emp1}/11111111-2222-3333-4444-555555555555.jpg`;
  const tokenA = "a".repeat(48);
  const tokenB = "b".repeat(48);

  await seedPhoto(client, emp1, photo1);

  const r1 = await callRegisterNew(client, { employee_id: emp1, photo_url: photo1, device_token: tokenA });
  record("Registration", "First-time registration creates 1 PENDING row",
    r1.ok === true && r1.result === "PENDING", r1.message);

  const ledgerRow = (await client.query(`SELECT status, registration_id FROM private.pending_employee_uploads WHERE object_path = $1`, [photo1])).rows[0];
  record("Trigger", "trg_link_pending_employee_upload sets status=LINKED and registration_id",
    ledgerRow.status === "LINKED" && ledgerRow.registration_id !== null,
    `status=${ledgerRow.status}, reg_id=${ledgerRow.registration_id}`);

  const r2 = await callRegisterNew(client, { employee_id: emp1, photo_url: photo1, device_token: tokenA });
  const rowCount = (await client.query(`SELECT count(*) as c FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].c;
  record("Idempotency", "Idempotent retry with same token returns PENDING without duplicate row",
    r2.ok === true && r2.result === "PENDING" && Number(rowCount) === 1,
    `rows=${rowCount}`);

  const r3 = await callRegisterNew(client, { employee_id: emp1, photo_url: photo1, device_token: tokenB });
  record("Anti-Hijack", "Registration attempt with different device token denied, data preserved",
    r3.ok === false && r3.result === "DENIED" && r3.message.includes("تعذر التحقق من ملكية الطلب"),
    r3.message);

  const r4 = await callRegisterNew(client, { employee_id: emp1, photo_url: photo1, device_token: "short_tok" });
  record("Proof-Safety", "Short/invalid token denied",
    r4.ok === false && r4.result === "DENIED", r4.message);

  const photoHijack = `registrations/${emp1}/99999999-9999-9999-9999-999999999999.jpg`;
  await seedPhoto(client, emp1, photoHijack);
  const r5 = await callRegisterNew(client, { employee_id: emp1, photo_url: photoHijack, device_token: tokenA });
  const currentPhoto = (await client.query(`SELECT employee_photo_url FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].employee_photo_url;
  record("Photo-Protection", "Photo replacement on PENDING request denied, stored photo preserved",
    r5.ok === false && r5.result === "DENIED" && r5.message.includes("تعذر تغيير صورة الطلب") && currentPhoto === photo1,
    r5.message);

  const r6 = await callRegisterNew(client, {
    employee_id: emp1,
    photo_url: photo1,
    device_token: tokenA,
    mobile_number: "0799999999"
  });
  const updatedMobile = (await client.query(`SELECT mobile_number FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].mobile_number;
  record("Owner-Edit", "Verified owner can update allow-listed fields while preserving ID/device/photo",
    r6.ok === true && r6.result === "PENDING" && updatedMobile === "0799999999",
    `new_mobile=${updatedMobile}`);

  await client.query(`UPDATE public.employee_registrations SET status = 'APPROVED' WHERE employee_id = $1`, [emp1]);
  const r7a = await callRegisterNew(client, { employee_id: emp1, photo_url: photo1, device_token: tokenA });
  record("Approved-Guard-Outer", "Re-registration with old linked photo rejected at photo gate",
    r7a.ok === false && r7a.result === "DENIED", r7a.message);

  const photoAppFresh = `registrations/${emp1}/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.jpg`;
  await seedPhoto(client, emp1, photoAppFresh);
  const r7b = await callRegisterNew(client, { employee_id: emp1, photo_url: photoAppFresh, device_token: tokenA });
  const approvedStatus = (await client.query(`SELECT status FROM public.employee_registrations WHERE employee_id = $1`, [emp1])).rows[0].status;
  record("Approved-Guard-Core", "APPROVED employee cannot re-register or overwrite account",
    r7b.ok === false && r7b.result === "DENIED" && r7b.message.includes("تم اعتماد هذا الحساب مسبقاً") && approvedStatus === "APPROVED",
    r7b.message);

  const empRej = "EMP-REJ-001";
  const photoRej = `registrations/${empRej}/22222222-3333-4444-5555-666666666666.jpg`;
  await seedPhoto(client, empRej, photoRej);
  await callRegisterNew(client, { employee_id: empRej, photo_url: photoRej, device_token: tokenA });
  await client.query(`UPDATE public.employee_registrations SET status = 'REJECTED' WHERE employee_id = $1`, [empRej]);
  const photoRejFresh = `registrations/${empRej}/33333333-4444-5555-6666-777777777777.jpg`;
  await seedPhoto(client, empRej, photoRejFresh);
  const r8 = await callRegisterNew(client, { employee_id: empRej, photo_url: photoRejFresh, device_token: tokenA });
  const rejLogs = (await client.query(`SELECT * FROM public.gate_access_logs WHERE employee_id = $1 AND reason = 'REJECTED_EMPLOYEE'`, [empRej])).rows;
  record("Rejected-Guard", "REJECTED employee cannot re-register and attempt is logged",
    r8.ok === true && r8.result === "DENIED" && r8.message.includes("تم رفض الطلب") && rejLogs.length >= 1,
    `logged_reason=${rejLogs[0]?.reason}`);

  const empHist = "EMP-HIST-001";
  const photoHistFresh = `registrations/${empHist}/44444444-5555-6666-7777-888888888888.jpg`;
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url)
    VALUES ('موظف تاريخي', $1, '0791111111', 'طوارئ', 'APPROVED', now() - interval '1 year', 'registrations/hist/old.jpg')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empHist]);
  await seedPhoto(client, empHist, photoHistFresh);
  const r9 = await callRegisterNew(client, { employee_id: empHist, photo_url: photoHistFresh, device_token: tokenA });
  record("Historic-Guard", "Historic employee denied on new route with redirect message",
    r9.ok === false && r9.result === "DENIED" && r9.message.includes("هذا المسار للموظفين الجدد فقط"),
    r9.message);

  const photoOther = `registrations/OTHER-EMP/55555555-6666-7777-8888-999999999999.jpg`;
  await seedPhoto(client, "OTHER-EMP", photoOther);
  const r10 = await callRegisterNew(client, { employee_id: "ATTACKER-EMP", photo_url: photoOther, device_token: tokenA });
  record("Cross-Photo-Guard", "Attaching another employee's photo denied before evaluating ID",
    r10.ok === false && r10.result === "DENIED", r10.message);

  let deniedCore = false, deniedQuota = false, deniedAttest = false;
  await asRole(client, 'anon', async () => {
    try { await client.query("SELECT private.register_employee_request_new_core('a','b','c','d',null,'e','f','g','h','i','j','k','l','m','n')"); } catch { deniedCore = true; }
    try { await client.query("SELECT public.claim_new_photo_upload_quota('x','y')"); } catch { deniedQuota = true; }
    try { await client.query("SELECT public.attest_new_employee_photo('x','y')"); } catch { deniedAttest = true; }
  });
  record("ACL-Hardening", "Direct execution of private core, quota RPC & attestation denied to anon",
    deniedCore && deniedQuota && deniedAttest,
    `core=${deniedCore}, quota=${deniedQuota}, attest=${deniedAttest}`);

  console.log("\n--- PART 2: ATOMIC PHOTO UPLOAD QUOTA TESTS ---");
  const q1 = await callClaimQuota(client, {
    employee_id: "EMP-QUOTA-TEST-1",
    source: "fingerprint-alpha",
    max_emp: 3, max_src: 5, max_global: 20
  });
  record("Quota-Claim", "service_role successfully claims upload quota",
    q1.allowed === true && q1.reason === "ALLOWED" && q1.employee_remaining === 2,
    `employee_remaining=${q1.employee_remaining}`);

  const qBadId = await callClaimQuota(client, { employee_id: "BAD\nID", source: "src-1" });
  const qBadSrc = await callClaimQuota(client, { employee_id: "EMP-1", source: "SRC\tBAD" });
  record("Quota-Sanitization", "Control characters and invalid inputs rejected",
    qBadId.allowed === false && qBadId.reason === "INVALID_EMPLOYEE_ID" &&
    qBadSrc.allowed === false && qBadSrc.reason === "INVALID_SOURCE_FINGERPRINT",
    `badId=${qBadId.reason}, badSrc=${qBadSrc.reason}`);

  const qEmpExhaust1 = await callClaimQuota(client, { employee_id: "EMP-LIMITED-PG17", source: "src-x", max_emp: 2, max_src: 10, max_global: 50 });
  await asRole(client, 'service_role', async () => {
    await client.query(`SELECT public.consume_new_photo_upload_quota($1::uuid)`, [qEmpExhaust1.lease_id]);
    await client.query(`SELECT public.finalize_new_photo_upload_quota($1::uuid)`, [qEmpExhaust1.lease_id]);
  });
  const qEmpExhaust2 = await callClaimQuota(client, { employee_id: "EMP-LIMITED-PG17", source: "src-y", max_emp: 2, max_src: 10, max_global: 50 });
  await asRole(client, 'service_role', async () => {
    await client.query(`SELECT public.consume_new_photo_upload_quota($1::uuid)`, [qEmpExhaust2.lease_id]);
    await client.query(`SELECT public.finalize_new_photo_upload_quota($1::uuid)`, [qEmpExhaust2.lease_id]);
  });
  const qEmpExhaust3 = await callClaimQuota(client, { employee_id: "EMP-LIMITED-PG17", source: "src-z", max_emp: 2, max_src: 10, max_global: 50 });
  record("Quota-PerEmployee", "Per-Employee quota strictly enforced and returns retry_after_seconds",
    qEmpExhaust1.allowed === true && qEmpExhaust2.allowed === true &&
    qEmpExhaust3.allowed === false && qEmpExhaust3.reason === "QUOTA_EXCEEDED_EMPLOYEE" && qEmpExhaust3.retry_after_seconds > 0,
    `retry_after=${qEmpExhaust3.retry_after_seconds}s`);

  const qInflight1 = await callClaimQuota(client, { employee_id: "EMP-INFLIGHT-PG17", source: "src-1" });
  const qInflight2 = await callClaimQuota(client, { employee_id: "EMP-INFLIGHT-PG17", source: "src-2" });
  record("Quota-InFlightLock", "Simultaneous active upload for same employee blocked with CONCURRENT_UPLOAD_LOCKED",
    qInflight1.allowed === true && qInflight2.allowed === false && qInflight2.reason === "CONCURRENT_UPLOAD_LOCKED",
    `q1=${qInflight1.allowed}, q2_reason=${qInflight2.reason}`);

  const qRollClaim = await callClaimQuota(client, { employee_id: "EMP-ROLLOVER-PG17", source: "src-roll", max_emp: 5, max_src: 10, max_global: 100 });
  const empScope = (await client.query(`SELECT emp_scope FROM private.new_photo_upload_claims WHERE lease_id = $1`, [qRollClaim.lease_id])).rows[0].emp_scope;
  await client.query(`UPDATE private.new_photo_upload_quotas SET window_started_at = now() + interval '2 hours', attempt_count = 2 WHERE scope_key = $1`, [empScope]);
  const qRollRel = await callReleaseQuota(client, qRollClaim.lease_id);
  const countAfterRollRelease = (await client.query(`SELECT attempt_count FROM private.new_photo_upload_quotas WHERE scope_key = $1`, [empScope])).rows[0].attempt_count;
  record("Quota-RolloverImmunity", "Releasing an old-window claim transitions to RELEASED without decrementing new window counter",
    qRollRel.allowed === true && qRollRel.reason === "RELEASED" && countAfterRollRelease === 2,
    `relReason=${qRollRel.reason}, newWindowCount=${countAfterRollRelease}`);

  let dropped = false;
  try {
    await client.query(`SELECT public.release_new_photo_upload_quota('EMP-1'::text, 'src-1'::text)`);
  } catch (err) {
    if (/does not exist|no function matches/i.test(err.message)) dropped = true;
  }
  record("Quota-DroppedOverload", "Ambiguous two-argument release_new_photo_upload_quota(text, text) removed",
    dropped === true, `dropped=${dropped}`);

  const qSrcEx1 = await callClaimQuota(client, { employee_id: "EMP-A-1", source: "shared-ip-office", max_emp: 5, max_src: 2, max_global: 50 });
  const qSrcEx2 = await callClaimQuota(client, { employee_id: "EMP-A-2", source: "shared-ip-office", max_emp: 5, max_src: 2, max_global: 50 });
  const qSrcEx3 = await callClaimQuota(client, { employee_id: "EMP-A-3", source: "shared-ip-office", max_emp: 5, max_src: 2, max_global: 50 });
  record("Quota-PerSource", "Per-Source fingerprint quota strictly enforced across different employees",
    qSrcEx1.allowed === true && qSrcEx2.allowed === true &&
    qSrcEx3.allowed === false && qSrcEx3.reason === "QUOTA_EXCEEDED_SOURCE",
    `reason=${qSrcEx3.reason}`);

  const currentGlobal = (await client.query(`SELECT attempt_count FROM private.new_photo_upload_quotas WHERE scope_key = 'global'`)).rows[0]?.attempt_count || 0;
  const targetCap = currentGlobal + 2;
  const qG1 = await callClaimQuota(client, { employee_id: "EMP-G1", source: "src-g1", max_global: targetCap });
  const qG2 = await callClaimQuota(client, { employee_id: "EMP-G2", source: "src-g2", max_global: targetCap });
  const qG3 = await callClaimQuota(client, { employee_id: "EMP-G3", source: "src-g3", max_global: targetCap });
  record("Quota-GlobalCap", "Global hard cap halts claims system-wide when saturated",
    qG1.allowed === true && qG2.allowed === true &&
    qG3.allowed === false && qG3.reason === "QUOTA_EXCEEDED_GLOBAL",
    `targetCap=${targetCap}, qG1=${qG1.allowed}, qG2=${qG2.allowed}, qG3_reason=${qG3.reason}`);

  const qClaimRel = await callClaimQuota(client, { employee_id: "EMP-REL-TEST", source: "src-rel", max_emp: 1, max_src: 10, max_global: 50 });
  const rel1 = await callReleaseQuota(client, qClaimRel.lease_id);
  const rel2 = await callReleaseQuota(client, qClaimRel.lease_id);
  const qClaimAfterRel = await callClaimQuota(client, { employee_id: "EMP-REL-TEST", source: "src-rel", max_emp: 1, max_src: 10, max_global: 50 });
  record("Quota-AtomicRelease", "Atomic release restores quota and blocks replay attacks",
    rel1.allowed === true && rel1.reason === "RELEASED" &&
    rel2.allowed === false && rel2.reason === "ALREADY_RELEASED" &&
    qClaimAfterRel.allowed === true,
    `rel1=${rel1.reason}, rel2=${rel2.reason}, afterAllowed=${qClaimAfterRel.allowed}`);

  const allClaims = (await client.query(`SELECT * FROM private.new_photo_upload_claims`)).rows;
  const rawLeakage = allClaims.filter(c => c.emp_scope.includes("EMP-") || c.src_scope.includes("fingerprint") || c.src_scope.includes("shared-ip"));
  record("Quota-Privacy", "Only SHA-256 hashed keys stored in private quota ledger; zero raw IP leakage",
    rawLeakage.length === 0, `total_scopes=${allClaims.length}`);

  console.log("\n--- PART 3: HISTORICAL 15-ARG COMPATIBILITY TESTS ---");
  const callLegacy = async (args) => {
    const res = await client.query(`
      SELECT public.register_employee_request(
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15
      ) as r
    `, [
      args.full_name, args.employee_id, args.mobile_number, args.specialty, args.qr_token || null,
      args.job_type, args.department, args.photo_url, args.device_token, args.device_id,
      args.device_type, args.device_name, args.user_agent, args.category, args.affiliated
    ]);
    return res.rows[0].r;
  };

  // 3.1 Historic APPROVED Employee
  const empH1 = "HIST-APP-01";
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('د. أحمد تاريخي', $1, '0795555551', 'جراحة', 'APPROVED', now() - interval '60 days', 'registrations/hist/p1.jpg', 'طبيب', 'جراحة', 'PERMANENT')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empH1]);
  const leg1 = await callLegacy({
    full_name: "د. أحمد تاريخي",
    employee_id: empH1,
    mobile_number: "0795555551",
    specialty: "جراحة",
    qr_token: "invalid-qr",
    job_type: "طبيب",
    department: "جراحة",
    photo_url: "registrations/hist/p1.jpg",
    device_token: "t".repeat(48),
    device_id: "d1", device_type: "iOS", device_name: "iPhone", user_agent: "Safari",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-15Arg", "Historic APPROVED employee passes cutoff fence into manual_employee_check branch",
    leg1 !== null && typeof leg1 === "object", JSON.stringify(leg1));

  // 3.2 Historic PENDING Employee
  const empH2 = "HIST-PND-02";
  const tokenHist = "h".repeat(96);
  const hashHist = crypto.createHash("sha256").update(tokenHist).digest("hex");
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, pending_trusted_device_token_hash, job_type, department, registration_category)
    VALUES ('ممرض تاريخي', $1, '0795555552', 'تمريض', 'PENDING', now() - interval '40 days', 'registrations/hist/p2.jpg', $2, 'ممرض', 'تمريض', 'PERMANENT')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empH2, hashHist]);
  const leg2 = await callLegacy({
    full_name: "ممرض تاريخي",
    employee_id: empH2,
    mobile_number: "0795555552",
    specialty: "تمريض",
    qr_token: null,
    job_type: "ممرض",
    department: "تمريض",
    photo_url: "registrations/hist/p2.jpg",
    device_token: tokenHist,
    device_id: "d2", device_type: "Android", device_name: "Samsung", user_agent: "Chrome",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-15Arg", "Historic PENDING employee passes fence and executes legacy PENDING branch",
    leg2.ok === true && (leg2.result === "PENDING" || leg2.result === "DENIED"), `result=${leg2.result}`);

  // 3.3 Historic REJECTED Employee
  const empH3 = "HIST-REJ-03";
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('مرفوض تاريخي', $1, '0795555553', 'صيدلة', 'REJECTED', now() - interval '30 days', 'registrations/hist/p3.jpg', 'صيدلي', 'صيدلة', 'PERMANENT')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empH3]);
  const leg3 = await callLegacy({
    full_name: "مرفوض تاريخي",
    employee_id: empH3,
    mobile_number: "0795555553",
    specialty: "صيدلة",
    qr_token: null,
    job_type: "صيدلي",
    department: "صيدلة",
    photo_url: "registrations/hist/p3.jpg",
    device_token: "t".repeat(48),
    device_id: "d3", device_type: "Windows", device_name: "PC", user_agent: "Edge",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-15Arg", "Historic REJECTED employee passes fence and returns original rejection message",
    leg3.ok === true && leg3.result === "DENIED" && leg3.message.includes("تم رفض الطلب"), leg3.message);

  // 3.4 Non-Standard ID with Arabic Digits
  const empH4 = "م-١٢٣٤٥";
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('موظف عربي الأرقام', $1, '0795555554', 'طوارئ', 'APPROVED', now() - interval '50 days', 'registrations/hist/p4.jpg', 'طبيب', 'طوارئ', 'PERMANENT')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empH4]);
  const leg4 = await callLegacy({
    full_name: "موظف عربي الأرقام",
    employee_id: empH4,
    mobile_number: "0795555554",
    specialty: "طوارئ",
    qr_token: "invalid-qr",
    job_type: "طبيب",
    department: "طوارئ",
    photo_url: "registrations/hist/p4.jpg",
    device_token: "t".repeat(48),
    device_id: "d4", device_type: "iOS", device_name: "iPhone", user_agent: "Safari",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-15Arg", "Historic non-standard Arabic digit ID handled cleanly without corruption",
    leg4 !== null && typeof leg4 === "object", JSON.stringify(leg4));

  // 3.5 Historic 10-Digit National ID
  const empH5 = "9988776655";
  await client.query(`
    INSERT INTO public.employee_registrations (full_name, employee_id, mobile_number, specialty, status, created_at, employee_photo_url, job_type, department, registration_category)
    VALUES ('رقم وطني عشري', $1, '0795555555', 'إداري', 'APPROVED', now() - interval '45 days', 'registrations/hist/p5.jpg', 'إداري', 'إداري', 'PERMANENT')
    ON CONFLICT (employee_id) DO NOTHING
  `, [empH5]);
  const leg5 = await callLegacy({
    full_name: "رقم وطني عشري",
    employee_id: empH5,
    mobile_number: "0795555555",
    specialty: "إداري",
    qr_token: "invalid-qr",
    job_type: "إداري",
    department: "إداري",
    photo_url: "registrations/hist/p5.jpg",
    device_token: "t".repeat(48),
    device_id: "d5", device_type: "Android", device_name: "Pixel", user_agent: "Chrome",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-15Arg", "Historic 10-digit national ID handled cleanly",
    leg5 !== null && typeof leg5 === "object", JSON.stringify(leg5));

  const lNew = await callLegacy({
    full_name: "جديد غير مسجل",
    employee_id: "NEW-EMP-BLOCKED",
    mobile_number: "0798888888",
    specialty: "طوارئ",
    job_type: "طبيب",
    department: "طوارئ",
    photo_url: "registrations/NEW-EMP-BLOCKED/test.jpg",
    device_token: "t".repeat(48),
    device_id: "d-new", device_type: "iOS", device_name: "iPhone", user_agent: "Safari",
    category: "PERMANENT", affiliated: null
  });
  record("Legacy-Fence", "Non-historic caller denied by cutoff fence on 15-arg function",
    lNew.ok === false && lNew.result === "DENIED" && lNew.message.includes("هذا المسار للموظفين المسجلين سابقاً فقط"),
    lNew.message);

  console.log("\n--- PART 4: ROLLBACK SAFETY & AUDIT ---");
  const rollbackSql = fs.readFileSync(path.join(root, "supabase/review/production_backend_ROLLBACK_LOCKED_20261111.sql"), "utf8");
  const cleanRollback = rollbackSql.replace(/DO\s+\$approval_required\$[\s\S]*?\$approval_required\$;/g, "-- rollback lock removed");

  const histBefore = (await client.query("SELECT count(*) as c FROM public.employee_registrations")).rows[0].c;
  await client.query(cleanRollback);
  const histAfter = (await client.query("SELECT count(*) as c FROM public.employee_registrations")).rows[0].c;
  const storageObjects = (await client.query("SELECT count(*) as c FROM storage.objects WHERE bucket_id = 'employee-photos'")).rows[0].c;
  record("Rollback-ZeroLoss", "Rollback executed cleanly with 0 deleted historic employees or photos",
    Number(histBefore) === Number(histAfter) && Number(storageObjects) > 0,
    `hist_before=${histBefore}, hist_after=${histAfter}, photos=${storageObjects}`);

  let newRpcRevoked = false;
  await asRole(client, 'anon', async () => {
    try {
      await client.query("SELECT public.register_new_employee_request('a','b','c','d',null,'e','f','g','h','i','j','k','l','m','n')");
    } catch (err) {
      if (err.code === "42501" || err.message.includes("permission denied")) newRpcRevoked = true;
    }
  });
  record("Rollback-RPCRevocation", "Rollback successfully revokes new-only registration RPC",
    newRpcRevoked === true, `newRpcRevoked=${newRpcRevoked}`);

  const total = testResults.length;
  const passed = testResults.filter(r => r.passed).length;
  const failed = testResults.filter(r => !r.passed).length;

  console.log("\n================================================================================");
  console.log(`TOTAL REAL POSTGRESQL 17 SERVER TESTS: ${total} | PASSED: ${passed} | FAILED: ${failed}`);
  console.log("================================================================================");

  await client.end();
  if (failed > 0) process.exit(1);
}

module.exports = { setupDatabase, stripLocks, seedPhoto, asRole };

if (require.main === module) {
  main().catch(err => {
    console.error("TEST EXECUTION FAILED:", err);
    process.exit(1);
  });
}
