"use strict";
// ============================================================================
// tests/employee-photo-upload-new.cjs
// Comprehensive unit, security, shared PostgreSQL quota, negative-case,
// concurrency, uncertain-timeout, and recovery-TTL test suite for
// employee-photo-upload-new and register-new.html (PR #61 + PR #62 + PR #63).
// ============================================================================

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

if (!globalThis.crypto?.subtle) {
  globalThis.crypto = crypto.webcrypto;
}

function buildValidJpeg({ width = 64, height = 64, seed = 0x42, extraBytes = 0 } = {}) {
  const header = [
    0xff, 0xd8, // SOI
    0xff, 0xe0, 0x00, 0x10,
    0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48, 0x00, 0x48, 0x00, 0x00,
    0xff, 0xc0, 0x00, 0x11,
    0x08,
    (height >> 8) & 0xff, height & 0xff,
    (width >> 8) & 0xff, width & 0xff,
    0x03,
    0x01, 0x11, 0x00,
    0x02, 0x11, 0x01,
    0x03, 0x11, 0x01,
    0xff, 0xda, 0x00, 0x0c,
    0x03, 0x01, 0x00, 0x02, 0x11, 0x03, 0x11, 0x00, 0x3f, 0x00
  ];
  const scanPayload = new Uint8Array(16 + extraBytes);
  for (let i = 0; i < scanPayload.length; i++) {
    scanPayload[i] = ((seed + i * 17) & 0x7f) + 1;
  }
  const footer = [0xff, 0xd9]; // EOI
  const total = new Uint8Array(header.length + scanPayload.length + footer.length);
  total.set(header, 0);
  total.set(scanPayload, header.length);
  total.set(footer, header.length + scanPayload.length);
  return total;
}

(async () => {
  const root = path.resolve(__dirname, "..");
  const handlerPath = path.join(root, "supabase/functions/employee-photo-upload-new/handler.mjs");
  const indexPath = path.join(root, "supabase/functions/employee-photo-upload-new/index.ts");
  const {
    MAX_PHOTO_BYTES,
    validEmployeeId,
    validateJpegBytes,
    folderFor,
    deriveTrustedSourceKey,
    createUploadState,
    handleNewPhotoUpload,
    verifyCloudflareTurnstile
  } = await import("file://" + handlerPath);

  const origin = "https://albashir-staging.vercel.app";
  const validJpegA = buildValidJpeg({ width: 320, height: 320, seed: 0x11 });
  const validJpegB = buildValidJpeg({ width: 320, height: 320, seed: 0x55 });

  // -------------------------------------------------------------------------
  // 1. Real JPEG Magic Bytes & structural negative tests
  // -------------------------------------------------------------------------
  const okJpeg = validateJpegBytes(validJpegA);
  assert.equal(okJpeg.ok, true);
  assert.equal(okJpeg.width, 320);
  assert.equal(okJpeg.height, 320);

  // Disguised PNG
  const pngBytes = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jK1cAAAAASUVORK5CYII=",
    "base64"
  );
  assert.equal(validateJpegBytes(new Uint8Array(pngBytes)).ok, false, "Disguised PNG must fail");

  // Fake SOI + EOI wrapper around HTML/script without SOF0/SOS
  const fakeWrapper = new Uint8Array([
    0xff, 0xd8, 0xff, 0xe0, 0x00, 0x08, 0x3c, 0x73, 0x63, 0x72, 0x69, 0x70,
    ...new Array(30).fill(0x41),
    0xff, 0xd9
  ]);
  assert.equal(validateJpegBytes(fakeWrapper).ok, false, "Fake SOI/EOI wrapper must fail");

  // Truncated JPEG (missing EOI 0xFFD9)
  assert.equal(
    validateJpegBytes(validJpegA.slice(0, validJpegA.length - 2)).code,
    "TRUNCATED_JPEG"
  );

  // Corrupt segment length overflowing buffer
  const corruptSeg = new Uint8Array(validJpegA);
  corruptSeg[4] = 0xff;
  corruptSeg[5] = 0xff;
  assert.equal(validateJpegBytes(corruptSeg).code, "INVALID_JPEG_SEGMENT");

  // SOS before SOF0
  const sosBeforeSof = new Uint8Array([
    0xff, 0xd8,
    0xff, 0xda, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3f, 0x00,
    ...new Array(24).fill(0x12),
    0xff, 0xd9
  ]);
  assert.equal(validateJpegBytes(sosBeforeSof).code, "SOS_BEFORE_SOF");

  // Zero-dimension frame
  assert.equal(validateJpegBytes(buildValidJpeg({ width: 0, height: 100 })).code, "INVALID_IMAGE_DIMENSIONS");

  // Oversized > 2 MiB
  assert.equal(validateJpegBytes(new Uint8Array(MAX_PHOTO_BYTES + 1)).code, "FILE_TOO_LARGE");

  // -------------------------------------------------------------------------
  // 2. Path Traversal & Shared "-" Folder Isolation negative tests
  // -------------------------------------------------------------------------
  assert.equal(validEmployeeId("-"), false, "Single hyphen '-' must be rejected to protect registrations/-/");
  assert.equal(validEmployeeId("---"), false, "Hyphen-only ID must be rejected");
  assert.equal(validEmployeeId("___"), false, "Underscore-only ID must be rejected");
  assert.equal(validEmployeeId(".."), false, "Dot-dot traversal must be rejected");
  assert.equal(validEmployeeId("../admin"), false, "Relative traversal must be rejected");
  assert.equal(validEmployeeId("123\\456"), false, "Backslash must be rejected");
  assert.equal(validEmployeeId("123%2e%2e"), false, "URL-encoded traversal must be rejected");
  assert.equal(await folderFor("-"), "", "folderFor('-') must return empty string");

  const slashId = "QA/NEW-123";
  const expectedSlashHash = crypto
    .createHash("sha256")
    .update("employee-photo-folder-v1:" + slashId)
    .digest("hex");
  assert.equal(await folderFor(slashId), expectedSlashHash);
  assert.match(expectedSlashHash, /^[0-9a-f]{64}$/);

  const arabicId = "١٢٣٤٥٦";
  const expectedArabicHash = crypto
    .createHash("sha256")
    .update("employee-photo-folder-v1:" + arabicId)
    .digest("hex");
  assert.equal(await folderFor(arabicId), expectedArabicHash);
  assert.notEqual(expectedArabicHash, "-");

  // -------------------------------------------------------------------------
  // 3. Shared PostgreSQL Quota Contract (public.claim_new_photo_upload_quota)
  //    Multi-level: Per-Employee, Per-Trusted-Source, Global Hard Cap,
  //    Untrusted IP rejection, Request-ID bypass immunity, and Fail-Closed
  // -------------------------------------------------------------------------
  const makeRequest = (employeeId, bytes = validJpegA, overrides = {}) => ({
    method: overrides.method || "POST",
    headers: { origin: overrides.origin ?? origin, ...(overrides.headers || {}) },
    trustedSource: overrides.trustedSource ?? null,
    bodyTooLarge: overrides.bodyTooLarge === true,
    form: overrides.form !== undefined ? overrides.form : {
      employee_id: employeeId,
      fileName: overrides.fileName ?? "employee.jpg",
      mimeType: overrides.mimeType ?? "image/jpeg",
      bytes
    }
  });

  // 3a. Request Body Size Limit enforced BEFORE parsing or DB calls
  let quotaCalls = 0;
  const bodyTooLargeRes = await handleNewPhotoUpload(
    makeRequest("EMP-SIZE", validJpegA, { bodyTooLarge: true }),
    {
      allowedOrigins: origin,
      async claimUploadQuota() {
        quotaCalls++;
        return { ok: true, allowed: true };
      }
    },
    createUploadState()
  );
  assert.equal(bodyTooLargeRes.status, 413, "Oversized request body must return 413");
  assert.equal(bodyTooLargeRes.body.code, "REQUEST_TOO_LARGE");
  assert.equal(quotaCalls, 0, "Oversized request body must not touch PostgreSQL quota RPC");

  // 3b. Path traversal filename rejected before DB calls
  const badFilenameRes = await handleNewPhotoUpload(
    makeRequest("EMP-PATH", validJpegA, { fileName: "../../etc/passwd.jpg" }),
    {
      allowedOrigins: origin,
      async claimUploadQuota() {
        quotaCalls++;
        return { ok: true, allowed: true };
      }
    },
    createUploadState()
  );
  assert.equal(badFilenameRes.status, 400);
  assert.equal(badFilenameRes.body.code, "INVALID_FILE_NAME");
  assert.equal(quotaCalls, 0);

  // 3c. Simulated shared PostgreSQL quota table across multiple Edge Function instances
  const sharedPgQuotaDb = {
    perEmployee: new Map(), // empId -> count
    perSource: new Map(), // sourceKey -> count
    globalCount: 0,
    maxPerEmployee: 3,
    maxPerSource: 4,
    maxGlobal: 10
  };

  function createSharedQuotaDeps(overrides = {}) {
    const trace = { quotaArgs: [], uploads: [], pending: [], attested: [], removed: [], confirmed: [], released: [], cleanupOrder: [] };
    const deps = {
      allowedOrigins: origin,
      now: () => 1762900000000,
      randomUUID: () => crypto.randomUUID(),
      async claimUploadQuota({ employeeId, sourceKey }) {
        trace.quotaArgs.push({ employeeId, sourceKey });
        const empCount = (sharedPgQuotaDb.perEmployee.get(employeeId) || 0) + 1;
        sharedPgQuotaDb.perEmployee.set(employeeId, empCount);
        if (empCount > sharedPgQuotaDb.maxPerEmployee) {
          return {
            ok: false,
            allowed: false,
            reason: "QUOTA_EXCEEDED_EMPLOYEE",
            scope: "employee",
            retry_after_seconds: 600
          };
        }
        if (sourceKey) {
          const srcCount = (sharedPgQuotaDb.perSource.get(sourceKey) || 0) + 1;
          sharedPgQuotaDb.perSource.set(sourceKey, srcCount);
          if (srcCount > sharedPgQuotaDb.maxPerSource) {
            return {
              ok: false,
              allowed: false,
              reason: "QUOTA_EXCEEDED_SOURCE",
              scope: "source",
              retry_after_seconds: 300
            };
          }
        }
        sharedPgQuotaDb.globalCount += 1;
        if (sharedPgQuotaDb.globalCount > sharedPgQuotaDb.maxGlobal) {
          return {
            ok: false,
            allowed: false,
            reason: "QUOTA_EXCEEDED_GLOBAL",
            scope: "global",
            retry_after_seconds: 600
          };
        }
        return { allowed: true, lease_id: crypto.randomUUID(), retry_after_seconds: 0 };
      },
      async consumeUploadQuota(leaseId) { return { ok: true, lease_id: leaseId }; },
      async releaseUploadQuota(leaseId) {
        trace.released.push(leaseId);
        return { ok: true, allowed: true, reason: "RELEASED" };
      },
      async checkEligibility(id) {
        if (id === "OLD-EMP-254") return { ok: true, is_new: false };
        return { ok: true, is_new: true };
      },
      async uploadObject(objectPath, bytes, contentType) {
        trace.uploads.push({ path: objectPath, size: bytes.byteLength, contentType });
        return { ok: true };
      },
      async registerPendingUpload(objectPath) {
        trace.pending.push(objectPath);
        return { ok: true };
      },
      async attestNewPhoto(id, objectPath) {
        trace.attested.push({ id, path: objectPath });
        return { ok: true };
      },
      async removeObject(objectPath) {
        trace.removed.push(objectPath);
        trace.cleanupOrder.push("remove:" + objectPath);
        return { ok: true };
      },
      async confirmPendingRemoval(objectPath) {
        trace.confirmed.push(objectPath);
        trace.cleanupOrder.push("confirm:" + objectPath);
        return { ok: true };
      },
      async verifyTurnstile() { return { ok: true }; },
      async assertUploadLease() { return { ok: true }; },
      async finalizeUploadQuota(leaseId) { trace.finalized = (trace.finalized || 0) + 1; return { ok: true, lease_id: leaseId }; },
      ...overrides
    };
    return { deps, trace };
  }

  // Test across TWO separate Edge Function isolate states (isolateA & isolateB)
  // to prove rate limits do NOT rely solely on in-process memory!
  const isolateA = createUploadState();
  const isolateB = createUploadState();
  const { deps: sharedDeps, trace: sharedTrace } = createSharedQuotaDeps();

  // Attempt to bypass quota by changing request_id / headers across isolates for same employee
  for (let i = 1; i <= 3; i++) {
    const img = buildValidJpeg({ width: 64, height: 64, seed: i * 10 });
    const isolate = i % 2 === 1 ? isolateA : isolateB;
    const res = await handleNewPhotoUpload(
      makeRequest("EMP-QUOTA-1", img, {
        headers: { "x-request-id": "req-" + i, "x-forwarded-for": `203.0.113.${i}` }
      }),
      sharedDeps,
      isolate
    );
    assert.equal(res.status, 201, `Upload ${i} across isolates should succeed`);
  }
  // 4th attempt on isolateB with a different request_id and different JPEG bytes must be blocked by shared PostgreSQL Per-Employee quota!
  const fourthEmployeeAttempt = await handleNewPhotoUpload(
    makeRequest("EMP-QUOTA-1", buildValidJpeg({ width: 64, height: 64, seed: 99 }), {
      headers: { "x-request-id": "req-bypass-999", "x-forwarded-for": "198.51.100.77" }
    }),
    sharedDeps,
    isolateB
  );
  assert.equal(fourthEmployeeAttempt.status, 429, "Shared PostgreSQL Per-Employee quota must block across Edge instances");
  assert.equal(fourthEmployeeAttempt.body.code, "UPLOAD_RATE_LIMITED");
  assert.equal(fourthEmployeeAttempt.body.scope, "employee");
  assert.equal(fourthEmployeeAttempt.headers["retry-after"], "600");

  // Untrusted X-Forwarded-For must not determine the fallback source scope.
  assert.match(sharedTrace.quotaArgs[0].sourceKey, /^emp:[0-9a-f]{64}$/);
  assert.equal(sharedTrace.quotaArgs[0].sourceKey, sharedTrace.quotaArgs[1].sourceKey);

  // 3d. Per-Client/Source quota when verified platform source is present
  for (let i = 1; i <= 4; i++) {
    const img = buildValidJpeg({ width: 72, height: 72, seed: 100 + i });
    const res = await handleNewPhotoUpload(
      makeRequest(`EMP-SRC-${i}`, img, { trustedSource: "verified-gateway-client-42" }),
      sharedDeps,
      createUploadState()
    );
    assert.equal(res.status, 201);
  }
  const fifthFromSameSource = await handleNewPhotoUpload(
    makeRequest("EMP-SRC-5", buildValidJpeg({ width: 72, height: 72, seed: 155 }), {
      trustedSource: "verified-gateway-client-42"
    }),
    sharedDeps,
    createUploadState()
  );
  assert.equal(fifthFromSameSource.status, 429, "Per-Trusted-Source quota must block 5th upload from same source");
  assert.equal(fifthFromSameSource.body.scope, "source");
  assert.equal(fifthFromSameSource.headers["retry-after"], "300");

  // 3e. Global Hard Cap across distinct employees and distinct sources
  sharedPgQuotaDb.globalCount = sharedPgQuotaDb.maxGlobal;
  const globalCapRes = await handleNewPhotoUpload(
    makeRequest("EMP-GLOBAL-99", buildValidJpeg({ width: 80, height: 80, seed: 201 })),
    sharedDeps,
    createUploadState()
  );
  assert.equal(globalCapRes.status, 429, "Global Hard Cap must reject when aggregate quota is reached");
  assert.equal(globalCapRes.body.scope, "global");

  // 3f. Quota service outage fails closed (503) WITHOUT deleting any prior photos
  const { deps: outageDeps, trace: outageTrace } = createSharedQuotaDeps({
    async claimUploadQuota() {
      throw new Error("PostgreSQL connection timeout");
    }
  });
  const quotaOutageRes = await handleNewPhotoUpload(
    makeRequest("EMP-OUTAGE-1", validJpegB),
    outageDeps,
    createUploadState()
  );
  assert.equal(quotaOutageRes.status, 503);
  assert.equal(quotaOutageRes.body.code, "QUOTA_SERVICE_UNAVAILABLE");
  assert.equal(outageTrace.uploads.length, 0);
  assert.equal(outageTrace.removed.length, 0, "Quota outage must never delete any photo");

  for (const overrides of [
    { async claimUploadQuota() { return { allowed: true }; } },
    { async consumeUploadQuota() { return { ok: false, reason: "LEASE_NOT_FOUND" }; } },
    { async consumeUploadQuota() { throw new Error("consume timeout"); } }
  ]) {
    sharedPgQuotaDb.globalCount = 0;
    sharedPgQuotaDb.perEmployee.clear();
    sharedPgQuotaDb.perSource.clear();
    const { deps, trace } = createSharedQuotaDeps(overrides);
    const response = await handleNewPhotoUpload(
      makeRequest("EMP-LEASE-FAIL", buildValidJpeg({ width: 96, height: 96, seed: 78 })),
      deps, createUploadState()
    );
    assert.equal(response.status, 503, "Missing or uncertain lease consumption must fail closed");
    assert.equal(trace.uploads.length, 0, "No Storage write is allowed before confirmed consumption");
    if (overrides.consumeUploadQuota && overrides.consumeUploadQuota.toString().includes("LEASE_NOT_FOUND")) {
      assert.equal(trace.released.length, 1, "Deterministic consume failure must reclaim the lease");
    }
  }

  // 3g. Distributed Edge Concurrency: CONCURRENT_UPLOAD_LOCKED returns 409
  const { deps: lockedDeps } = createSharedQuotaDeps({
    async claimUploadQuota() {
      return {
        allowed: false,
        reason: "CONCURRENT_UPLOAD_LOCKED",
        scope: "concurrent",
        retry_after_seconds: 60,
        message: "يوجد رفع صورة جارٍ لهذا الرقم حالياً. انتظر اكتمال الطلب الحالي."
      };
    }
  });
  const lockedRes = await handleNewPhotoUpload(
    makeRequest("EMP-CONCURRENT", buildValidJpeg({ width: 96, height: 96, seed: 79 })),
    lockedDeps,
    createUploadState()
  );
  assert.equal(lockedRes.status, 409, "Distributed concurrency lock must return 409");
  assert.equal(lockedRes.body.code, "UPLOAD_IN_PROGRESS");

  // 3h. Cloudflare Turnstile Server-Side Verification Gate
  let turnstileQuotaCalled = false;
  const { deps: turnstileFailDeps } = createSharedQuotaDeps({
    async verifyTurnstile(token) {
      if (!token) return { ok: false, code: "MISSING_TURNSTILE_TOKEN", message: "رمز التحقق الأمني مطلوب." };
      if (token === "BAD_TOKEN") return { ok: false, code: "INVALID_TURNSTILE_TOKEN", message: "رمز التحقق غير صالح." };
      return { ok: true };
    },
    async claimUploadQuota() {
      turnstileQuotaCalled = true;
      return { allowed: true, lease_id: crypto.randomUUID() };
    }
  });

  // Missing Turnstile Token
  const missingTurnstileRes = await handleNewPhotoUpload(
    makeRequest("EMP-TURNSTILE-1", buildValidJpeg({ width: 96, height: 96, seed: 80 })),
    turnstileFailDeps,
    createUploadState()
  );
  assert.equal(missingTurnstileRes.status, 403, "Missing Turnstile token must return 403");
  assert.equal(missingTurnstileRes.body.code, "MISSING_TURNSTILE_TOKEN");
  assert.equal(turnstileQuotaCalled, false, "Quota must NEVER be claimed if Turnstile fails");

  // Invalid Turnstile Token
  const badReq = makeRequest("EMP-TURNSTILE-2", buildValidJpeg({ width: 96, height: 96, seed: 81 }));
  badReq.form.turnstile_token = "BAD_TOKEN";
  const badTurnstileRes = await handleNewPhotoUpload(
    badReq,
    turnstileFailDeps,
    createUploadState()
  );
  assert.equal(badTurnstileRes.status, 403, "Invalid Turnstile token must return 403");
  assert.equal(badTurnstileRes.body.code, "INVALID_TURNSTILE_TOKEN");
  assert.equal(turnstileQuotaCalled, false, "Quota must NEVER be claimed on invalid Turnstile");

  // Valid Turnstile Token
  const validReq = makeRequest("EMP-TURNSTILE-3", buildValidJpeg({ width: 96, height: 96, seed: 82 }));
  validReq.form.turnstile_token = "VALID_TOKEN";
  const validTurnstileRes = await handleNewPhotoUpload(
    validReq,
    turnstileFailDeps,
    createUploadState()
  );
  assert.equal(validTurnstileRes.status, 201, "Valid Turnstile token must proceed to upload");
  assert.equal(turnstileQuotaCalled, true, "Quota claimed upon valid Turnstile");

  // Turnstile is FAIL-CLOSED BY DEFAULT: with the default (5th argument omitted /
  // false) test tokens and Cloudflare's public test secrets are rejected.
  const prodMissingSecretRes = await verifyCloudflareTurnstile("TEST_TURNSTILE_TOKEN", "", null, globalThis.fetch);
  assert.equal(prodMissingSecretRes.ok, false, "Default mode must fail closed when Turnstile secret is missing");
  assert.equal(prodMissingSecretRes.code, "TURNSTILE_NOT_CONFIGURED");

  const prodCfTestSecretRes = await verifyCloudflareTurnstile("TEST_TURNSTILE_TOKEN", "1x0000000000000000000000000000000AA", null, globalThis.fetch);
  assert.equal(prodCfTestSecretRes.ok, false, "Cloudflare's public test secret must be refused outside explicit local test mode");
  assert.equal(prodCfTestSecretRes.code, "TURNSTILE_NOT_CONFIGURED");

  const prodTestTokenRes = await verifyCloudflareTurnstile("TEST_TURNSTILE_TOKEN", "real-looking-secret-0123456789", null, async () => { throw new Error("must not reach Cloudflare"); });
  assert.equal(prodTestTokenRes.ok, false, "Default mode must reject TEST_TURNSTILE_TOKEN even if a real secret exists");
  assert.equal(prodTestTokenRes.code, "INVALID_TURNSTILE_TOKEN");

  // Only an explicit allowTestTokens === true (local tests) accepts the local token.
  const localTestRes = await verifyCloudflareTurnstile("TEST_TURNSTILE_TOKEN", "", null, globalThis.fetch, true);
  assert.equal(localTestRes.ok, true, "Explicit local test mode accepts only the local test token");
  const localOtherRes = await verifyCloudflareTurnstile("XXXX.DUMMY.TOKEN.XXXX", "", null, globalThis.fetch, true);
  assert.equal(localOtherRes.ok, false);
  assert.equal((await verifyCloudflareTurnstile("TEST_TURNSTILE_TOKEN", "", null, globalThis.fetch, "true")).ok, false, "Truthy non-boolean must NOT enable test mode");

  // A handler wired without any Turnstile verifier must fail closed, never skip the gate.
  const { deps: noTurnstileDeps, trace: noTurnstileTrace } = createSharedQuotaDeps({ verifyTurnstile: undefined });
  const noTurnstileRes = await handleNewPhotoUpload(
    makeRequest("EMP-NO-TURNSTILE-DEP", buildValidJpeg({ width: 96, height: 96, seed: 83 })),
    noTurnstileDeps, createUploadState());
  assert.equal(noTurnstileRes.status, 503);
  assert.equal(noTurnstileRes.body.code, "TURNSTILE_NOT_CONFIGURED");
  assert.equal(noTurnstileTrace.uploads.length, 0);

  // Ambiguous Consume Timeout: must NOT call releaseUploadQuota!
  let releaseCalledOnTimeout = false;
  const { deps: consumeTimeoutDeps } = createSharedQuotaDeps({
    async consumeUploadQuota() {
      return { ok: false, outcomeUnknown: true, reason: "GATEWAY_TIMEOUT" };
    },
    async releaseUploadQuota() {
      releaseCalledOnTimeout = true;
      return { ok: true };
    }
  });
  const consumeTimeoutRes = await handleNewPhotoUpload(
    makeRequest("EMP-CONSUME-TIMEOUT", buildValidJpeg({ width: 96, height: 96, seed: 91 })),
    consumeTimeoutDeps,
    createUploadState()
  );
  assert.equal(consumeTimeoutRes.status, 503);
  assert.equal(consumeTimeoutRes.body.code, "CONSUME_OUTCOME_UNCERTAIN");
  assert.equal(releaseCalledOnTimeout, false, "Must NEVER release lease upon ambiguous consume timeout");

  // Deterministic Consume Failure: MUST call releaseUploadQuota to refund the employee
  let releaseCalledOnDeterministic = false;
  const { deps: consumeDetDeps } = createSharedQuotaDeps({
    async consumeUploadQuota() {
      return { ok: false, outcomeUnknown: false, reason: "LEASE_STATE_CONFLICT" };
    },
    async releaseUploadQuota() {
      releaseCalledOnDeterministic = true;
      return { ok: true };
    }
  });
  const consumeDetRes = await handleNewPhotoUpload(
    makeRequest("EMP-CONSUME-DET", buildValidJpeg({ width: 96, height: 96, seed: 92 })),
    consumeDetDeps,
    createUploadState()
  );
  assert.equal(consumeDetRes.status, 503);
  assert.equal(consumeDetRes.body.code, "QUOTA_SERVICE_UNAVAILABLE");
  assert.equal(releaseCalledOnDeterministic, true, "Must reclaim lease upon deterministic pre-upload refusal");

  // Lease lost BEFORE attestation (Fencing Token): nothing attested, object removed.
  const { deps: fenceLostDeps, trace: fenceLostTrace } = createSharedQuotaDeps({
    async assertUploadLease() { return { ok: false, reason: "LEASE_SUPERSEDED" }; }
  });
  const fenceLostRes = await handleNewPhotoUpload(
    makeRequest("EMP-FENCE-LOST", buildValidJpeg({ width: 96, height: 96, seed: 93 })),
    fenceLostDeps, createUploadState());
  assert.equal(fenceLostRes.status, 409);
  assert.equal(fenceLostRes.body.code, "UPLOAD_SUPERSEDED");
  assert.equal(fenceLostTrace.attested.length, 0, "A superseded lease must never attest a photo");
  assert.equal(fenceLostTrace.removed.length, 1, "Unattested object of a superseded lease is removed");

  // Lease lost AFTER attestation (finalize reports superseded): the attested photo is KEPT.
  const { deps: finalizeSupersededDeps, trace: finalizeTrace } = createSharedQuotaDeps({
    async finalizeUploadQuota() {
      return { ok: false, reason: "LEASE_SUPERSEDED" };
    }
  });
  const finalizeSupersededRes = await handleNewPhotoUpload(
    makeRequest("EMP-FINALIZE-SUPERSEDED", buildValidJpeg({ width: 96, height: 96, seed: 94 })),
    finalizeSupersededDeps,
    createUploadState()
  );
  assert.equal(finalizeSupersededRes.status, 409, "Superseded upload must return 409");
  assert.equal(finalizeSupersededRes.body.code, "UPLOAD_SUPERSEDED");
  assert.equal(finalizeTrace.attested.length, 1);
  assert.equal(finalizeTrace.removed.length, 0, "An already-attested photo must NEVER be deleted");

  // -------------------------------------------------------------------------
  // 4. Uncertain DB Timeout Outcome vs. Deterministic Rejection
  //    CRITICAL RULE: Never delete an uploaded photo when attestation/DB times
  //    out with an uncertain outcome, as it may already be linked!
  // -------------------------------------------------------------------------
  sharedPgQuotaDb.globalCount = 0;
  const { deps: timeoutAttestDeps, trace: timeoutTrace } = createSharedQuotaDeps({
    async attestNewPhoto() {
      throw new Error("PostgREST request timed out after 8000ms");
    }
  });
  const timeoutAttestRes = await handleNewPhotoUpload(
    makeRequest("EMP-TIMEOUT-ATTEST", buildValidJpeg({ width: 96, height: 96, seed: 77 })),
    timeoutAttestDeps,
    createUploadState()
  );
  assert.equal(timeoutAttestRes.status, 503);
  assert.equal(timeoutAttestRes.body.code, "ATTESTATION_OUTCOME_UNKNOWN");
  assert.equal(timeoutTrace.uploads.length, 1);
  assert.equal(
    timeoutTrace.removed.length,
    0,
    "CRITICAL: Must NOT delete uploaded photo when DB attestation outcome is uncertain after timeout"
  );

  // Conversely, a deterministic DB rejection (ok: false, outcomeUnknown: false) MUST clean up the unattested object
  const { deps: deterministicRejectDeps, trace: rejectTrace } = createSharedQuotaDeps({
    async attestNewPhoto() {
      return { ok: false, outcomeUnknown: false };
    }
  });
  const detRejectRes = await handleNewPhotoUpload(
    makeRequest("EMP-DET-REJECT", buildValidJpeg({ width: 96, height: 96, seed: 88 })),
    deterministicRejectDeps,
    createUploadState()
  );
  assert.equal(detRejectRes.status, 403);
  assert.equal(detRejectRes.body.code, "PHOTO_ATTESTATION_FAILED");
  assert.equal(rejectTrace.removed.length, 1, "Deterministic attestation rejection must remove unattested object");
  assert.deepEqual(rejectTrace.confirmed, rejectTrace.removed, "Ledger cleanup follows confirmed Storage deletion");
  assert.deepEqual(rejectTrace.cleanupOrder, [
    "remove:" + rejectTrace.removed[0], "confirm:" + rejectTrace.removed[0]
  ]);
  const { deps: pendingFailDeps, trace: pendingFailTrace } = createSharedQuotaDeps({
    async registerPendingUpload() { return { ok: false, outcomeUnknown: false }; }
  });
  const pendingFailRes = await handleNewPhotoUpload(
    makeRequest("EMP-PENDING-FAIL", buildValidJpeg({ width: 96, height: 96, seed: 90 })),
    pendingFailDeps, createUploadState()
  );
  assert.equal(pendingFailRes.status, 503);
  assert.equal(pendingFailRes.body.code, "PENDING_LEDGER_FAILED");
  assert.equal(pendingFailTrace.removed.length, 1);
  assert.equal(pendingFailTrace.confirmed.length, 0);
  const { deps: failedRemovalDeps, trace: failedRemovalTrace } = createSharedQuotaDeps({
    async attestNewPhoto() { return { ok: false, outcomeUnknown: false }; },
    async removeObject(objectPath) { failedRemovalTrace.removed.push(objectPath); return { ok: false }; }
  });
  const failedRemovalResult = await handleNewPhotoUpload(
    makeRequest("EMP-REMOVE-FAIL", buildValidJpeg({ width: 96, height: 96, seed: 89 })),
    failedRemovalDeps, createUploadState()
  );
  assert.equal(failedRemovalResult.status, 403);
  assert.equal(failedRemovalTrace.removed.length, 1);
  assert.equal(failedRemovalTrace.confirmed.length, 0, "Failed Storage deletion must retain ledger row");

  // -------------------------------------------------------------------------
  // 5. Historical employee rejection, Cross-employee ownership conflict,
  //    Idempotent retry, and Concurrent upload lock
  // -------------------------------------------------------------------------
  sharedPgQuotaDb.globalCount = 0;
  const { deps: flowDeps, trace: flowTrace } = createSharedQuotaDeps();
  const flowState = createUploadState();

  const histRes = await handleNewPhotoUpload(makeRequest("OLD-EMP-254", validJpegA), flowDeps, flowState);
  assert.equal(histRes.status, 403);
  assert.equal(histRes.body.code, "EXISTING_EMPLOYEE");
  assert.equal(flowTrace.uploads.length, 0);

  const okUpload = await handleNewPhotoUpload(makeRequest("NEW-FLOW-1", validJpegA), flowDeps, flowState);
  assert.equal(okUpload.status, 201);
  assert.equal(flowTrace.uploads.length, 1);
  assert.equal(flowTrace.confirmed.length, 0, "Successful attestation must retain its pending ledger row");

  // Same employee retries identical photo -> 200 deduplicated without consuming quota or re-uploading
  const quotaCallsBeforeRetry = flowTrace.quotaArgs.length;
  const retryUpload = await handleNewPhotoUpload(makeRequest("NEW-FLOW-1", validJpegA), flowDeps, flowState);
  assert.equal(retryUpload.status, 200);
  assert.equal(retryUpload.body.deduplicated, true);
  assert.equal(retryUpload.body.path, okUpload.body.path);
  assert.equal(flowTrace.uploads.length, 1);
  assert.equal(flowTrace.quotaArgs.length, quotaCallsBeforeRetry);

  // Another employee attempts to reuse the same photo -> 403 PHOTO_OWNERSHIP_CONFLICT
  const conflictUpload = await handleNewPhotoUpload(makeRequest("NEW-FLOW-2", validJpegA), flowDeps, flowState);
  assert.equal(conflictUpload.status, 403);
  assert.equal(conflictUpload.body.code, "PHOTO_OWNERSHIP_CONFLICT");

  // -------------------------------------------------------------------------
  // 6. Client Recovery After Page Reload & Expiration TTL in register-new.html
  // -------------------------------------------------------------------------
  const regHtml = fs.readFileSync(path.join(root, "register-new.html"), "utf8");
  const fnStart = regHtml.indexOf("  async function uploadEmployeePhoto(employeeId) {");
  const fnEnd = regHtml.indexOf("  const REGISTRATION_RPC_TIMEOUT_MS = 20000;");
  assert(fnStart > 0 && fnEnd > fnStart);
  const extractedCode =
    regHtml.slice(fnStart, fnEnd) +
    "\nthis.photoForRegistrationRetry = photoForRegistrationRetry;" +
    "\nthis.getOrCreatePendingOwnershipProof = getOrCreatePendingOwnershipProof;" +
    "\nthis.purgeExpiredTemporaryRegistrationState = purgeExpiredTemporaryRegistrationState;" +
    "\nthis.clearPendingUploadRecovery = clearPendingUploadRecovery;";

  const sessionMap = new Map();
  const mockSessionStorage = {
    getItem: (k) => (sessionMap.has(k) ? sessionMap.get(k) : null),
    setItem: (k, v) => sessionMap.set(k, String(v)),
    removeItem: (k) => sessionMap.delete(k)
  };

  let simulatedNow = 1762900000000;
  const FakeDate = class extends Date {
    static now() {
      return simulatedNow;
    }
  };

  let selectedFileObj = {
    name: "employee.jpg",
    type: "image/jpeg",
    size: validJpegB.byteLength,
    async arrayBuffer() {
      return validJpegB.buffer.slice(validJpegB.byteOffset, validJpegB.byteOffset + validJpegB.byteLength);
    }
  };

  let clientNetworkUploads = 0;
  function createTabVmContext() {
    const ctx = {
      window: {},
      Date: FakeDate,
      sessionStorage: mockSessionStorage,
      APP_CONFIG: {
        SUPABASE_URL: "https://adwvokwucotohwayorgx.supabase.co",
        SUPABASE_ANON_KEY: "sb_publishable_test"
      },
      $: (id) => (id === "employeePhoto" ? { files: [selectedFileObj] } : null),
      readPendingRegistrationContext: () => null,
      generateTrustedDeviceToken: () => "a".repeat(96),
      prepareEmployeePhoto: async () => ({
        file: selectedFileObj,
        mimeType: "image/jpeg",
        extension: "jpg"
      }),
      FormData: class {
        constructor() {
          this.map = new Map();
        }
        set(k, v, name) {
          this.map.set(k, { v, name });
        }
      },
      AbortController,
      setTimeout,
      clearTimeout,
      TextEncoder,
      Uint8Array,
      Array,
      String,
      Error,
      JSON,
      crypto: globalThis.crypto,
      fetch: async () => {
        clientNetworkUploads++;
        return {
          ok: true,
          status: 201,
          json: async () => ({
            ok: true,
            path: `registrations/${expectedSlashHash}/cc123456-78ab-41cd-91ab-123456789abc.jpg`
          })
        };
      }
    };
    vm.createContext(ctx);
    vm.runInContext(extractedCode, ctx);
    return ctx;
  }

  // Tab instance 1: uploads photo before RPC timeout
  const tab1 = createTabVmContext();
  const proof1 = tab1.getOrCreatePendingOwnershipProof(slashId);
  assert.equal(proof1.length, 96);
  const pathBeforeReload = await tab1.photoForRegistrationRetry(slashId);
  assert.equal(clientNetworkUploads, 1);

  // Simulate page reload (new JS VM context with cachedPendingPhoto = null, sharing sessionStorage)
  simulatedNow += 60 * 1000; // 1 minute later (within 10-min recovery TTL)
  const tabAfterReload = createTabVmContext();
  const proofAfterReload = tabAfterReload.getOrCreatePendingOwnershipProof(slashId);
  assert.equal(proofAfterReload, proof1, "Ownership proof must survive page reload within TTL");
  const pathAfterReload = await tabAfterReload.photoForRegistrationRetry(slashId);
  assert.equal(pathAfterReload, pathBeforeReload, "Page reload within TTL must recover uploaded path");
  assert.equal(clientNetworkUploads, 1, "Page reload retry must NOT re-upload the photo");

  // Advance clock past 31 minutes: both recovery state (10m TTL) and ownership proof (30m TTL) MUST expire!
  simulatedNow += 31 * 60 * 1000;
  const tabAfterExpiry = createTabVmContext();
  tabAfterExpiry.purgeExpiredTemporaryRegistrationState(simulatedNow);
  assert.equal(
    mockSessionStorage.getItem("alb_pending_registration_recovery_v1"),
    null,
    "Expired upload recovery state must be purged from sessionStorage"
  );
  assert.equal(
    mockSessionStorage.getItem("alb_pending_registration_owner_proof_v1"),
    null,
    "Expired temporary ownership proof must be purged from sessionStorage"
  );
  await tabAfterExpiry.photoForRegistrationRetry(slashId);
  assert.equal(clientNetworkUploads, 2, "After recovery TTL expires, a new upload must be performed");

  // -------------------------------------------------------------------------
  // 7. Static security verification of index.ts
  // -------------------------------------------------------------------------
  const indexSource = fs.readFileSync(indexPath, "utf8");
  assert(indexSource.includes('admin.rpc("claim_new_photo_upload_quota"'));
  assert(indexSource.includes("UNTRUSTED_CLIENT_IP_HEADERS"));
  assert(indexSource.includes('"x-forwarded-for"'));
  assert(!indexSource.includes("employee-photo-url"), "Upload service must never call photo resolver");

  console.log(
    "PASS employee-photo-upload-new: shared PostgreSQL quota (per-employee, per-source, global), uncertain DB timeout preservation, JPEG Magic Bytes, path traversal & '-' block, page-reload recovery, and TTL expiration"
  );
})().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
