// ============================================================================
// employee-photo-client.cjs
//
// Behaviour of the shared browser client (employee-photo.js) with a fake DOM,
// a fake fetch and a fake clock. No browser, no network and no Production call.
//
// Focus: a signed URL is a temporary credential, so it must never be written to
// a cache or to persistent storage.
// ============================================================================
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const SOURCE = fs.readFileSync(path.join(__dirname, "../employee-photo.js"), "utf8");

const OWN_PATH = "registrations/80632/1790627850001-7df3b32a22b418.jpeg";
const SIGNED_URL =
  "https://qinsfvlspdticposbvst.supabase.co/storage/v1/object/sign/employee-photos/" +
  OWN_PATH +
  "?token=abc.def";
const CONFIG = {
  SUPABASE_URL: "https://qinsfvlspdticposbvst.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_test"
};
const ACTOR = { type: "employee", employee_id: "80632", mobile_number: "0790000000" };

function makeElement(attributes = {}) {
  const map = new Map(Object.entries(attributes));
  return {
    src: "",
    href: "",
    style: {},
    getAttribute(key) {
      return map.has(key) ? map.get(key) : null;
    },
    setAttribute(key, value) {
      map.set(key, String(value));
    },
    removeAttribute(key) {
      map.delete(key);
      if (key === "src") this.src = "";
      if (key === "href") this.href = "";
    },
    matches(selector) {
      if (selector === "[data-photo-ref]") return map.has("data-photo-ref");
      if (selector === "[data-photo-href]") return map.has("data-photo-href");
      return false;
    },
    attributes: map
  };
}

function makeRoot(elements = [], links = []) {
  return {
    querySelectorAll(selector) {
      if (selector === "[data-photo-ref]") return elements;
      if (selector === "[data-photo-href]") return links;
      return [];
    },
    matches() {
      return false;
    },
    contains(element) {
      return elements.includes(element) || links.includes(element);
    }
  };
}

function load({ resolverResponse, imageFails = false, now, lazy = false } = {}) {
  const calls = { resolver: [], image: [] };
  const created = [];
  const revoked = [];
  const observers = [];
  const clock = { value: now ?? Date.parse("2026-10-06T12:00:00.000Z") };

  const context = {
    console: { warn() {}, log() {}, error() {} },
    setTimeout,
    clearTimeout,
    AbortController,
    crypto: require('node:crypto').webcrypto,
    Promise,
    Map,
    Set,
    JSON,
    Number,
    String,
    Array,
    Object,
    Error,
    Date: { now: () => clock.value }
  };
  context.window = context;
  if (lazy) {
    context.IntersectionObserver = class {
      constructor(callback, options) {
        this.callback = callback;
        this.options = options;
        this.targets = new Set();
        observers.push(this);
      }
      observe(target) { this.targets.add(target); }
      unobserve(target) { this.targets.delete(target); }
      disconnect() { this.targets.clear(); }
      trigger(target) {
        return this.callback([{ target, isIntersecting: true, intersectionRatio: 1 }], this);
      }
    };
  }
  context.URL = {
    createObjectURL(blob) {
      const url = `blob:https://gate.test/${created.length}`;
      created.push({ url, blob });
      return url;
    },
    revokeObjectURL(url) {
      revoked.push(url);
    }
  };
  // Any attempt to persist the credential is a test failure.
  Object.defineProperty(context, "localStorage", {
    get() {
      throw new Error("localStorage must never be used");
    }
  });
  Object.defineProperty(context, "sessionStorage", {
    get() {
      throw new Error("sessionStorage must never be used");
    }
  });
  Object.defineProperty(context, "document", {
    get() {
      throw new Error("document must not be touched when a root element is supplied");
    }
  });

  context.fetch = async (target, options = {}) => {
    const url = String(target);
    if (url.includes("/functions/v1/employee-photo-url")) {
      calls.resolver.push({ url, options, body: JSON.parse(options.body || "{}") });
      const payload =
        typeof resolverResponse === "function" ? resolverResponse(calls.resolver.length) : resolverResponse;
      if (payload === null) throw new Error("resolver unreachable");
      const status = payload.status ?? 200;
      return {
        ok: status < 400,
        status,
        json: async () => payload.body ?? payload
      };
    }
    calls.image.push({ url, options });
    if (imageFails) throw new Error("CORS blocked the no-store fetch");
    return { ok: true, status: 200, blob: async () => ({ size: 2048 }) };
  };

  vm.createContext(context);
  vm.runInContext(SOURCE, context);
  return { client: context.EmployeePhoto, calls, created, revoked, clock, context, observers };
}

const okPayload = (overrides = {}) => ({
  ok: true,
  url: SIGNED_URL,
  expires_in: 60,
  expires_at: "2026-10-06T12:01:00.000Z",
  ...overrides
});

(async () => {
  // ------------------------------------------------------------ resolver call shape
  {
    const { client, calls } = load({ resolverResponse: okPayload() });
    const url = await client.resolve(OWN_PATH, ACTOR, CONFIG);
    assert.equal(url, SIGNED_URL);
    assert.equal(calls.resolver.length, 1);
    assert.equal(calls.resolver[0].options.method, "POST");
    assert.equal(calls.resolver[0].options.headers.apikey, CONFIG.SUPABASE_ANON_KEY);
    assert.deepEqual(calls.resolver[0].body, { action: "resolve", path: OWN_PATH, actor: ACTOR });
    console.log("PASS resolve() calls the resolver once with the actor and path");
  }
  {
    const { client, calls } = load({ resolverResponse: okPayload() });
    const safeIdPath = "registrations/QA-NEW-123/photo.jpg";
    await client.resolve(safeIdPath, ACTOR, CONFIG, { newOnly: true });
    assert(calls.resolver[0].url.endsWith("/employee-photo-url-new"));
    assert.equal(calls.resolver[0].body.employee_id, ACTOR.employee_id);
    await client.resolve(safeIdPath, ACTOR, CONFIG);
    assert.equal(calls.resolver.length, 2, "new and legacy resolvers must not share a cached decision");
    assert(calls.resolver[1].url.endsWith("/employee-photo-url"));
    console.log("PASS explicit new-only route handles safe IDs without reusing legacy resolver cache");
  }

  // ------------------------------------------------------------ no-store blob display
  {
    const { client, calls, created } = load({ resolverResponse: okPayload() });
    const element = makeElement({ "data-photo-ref": OWN_PATH, "data-photo-fallback": "./logo.jpeg" });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);

    assert.equal(element.src, created[0].url, "the element must display the blob URL");
    assert.ok(element.src.startsWith("blob:"), "the signed URL must not become the element src");
    assert.equal(element.getAttribute("data-photo-ref"), null, "the reference is consumed");
    assert.equal(element.getAttribute("data-photo-fallback"), "./logo.jpeg", "the fallback attribute is preserved");

    assert.equal(calls.image.length, 1);
    assert.equal(new URL(calls.image[0].url).searchParams.get('token'), new URL(SIGNED_URL).searchParams.get('token'));
    assert.ok(new URL(calls.image[0].url).searchParams.get('cacheNonce'));
    assert.notEqual(calls.image[0].url, SIGNED_URL);
    assert.equal(calls.image[0].options.cache, "no-store", "the signed URL must bypass the browser cache");
    assert.equal(calls.image[0].options.credentials, "omit");
    assert.equal(calls.image[0].options.referrerPolicy, "no-referrer");
    console.log("PASS signed URLs are fetched with cache:no-store and displayed as a blob URL");
  }
  {
    const { client, calls, created } = load({ resolverResponse: okPayload(), imageFails: true });
    const element = makeElement({ "data-photo-ref": OWN_PATH, "data-photo-fallback": "./logo.jpeg" });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(element.src, "./logo.jpeg", "a blocked no-store fetch must show the placeholder");
    assert.equal(created.length, 0);
    assert.equal(calls.image[0].options.cache, "no-store");
    console.log("PASS a blocked no-store fetch shows the placeholder");
  }
  for (const fallback of ["javascript:alert(1)", "//evil.example/photo.jpg", "http://evil.example/photo.jpg", "data:image/svg+xml,<svg/>"]) {
    const { client } = load({ resolverResponse: okPayload(), imageFails: true });
    const element = makeElement({ "data-photo-ref": OWN_PATH, "data-photo-fallback": fallback });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(element.src, "", `unapproved fallback must be rejected: ${fallback}`);
    assert.equal(element.style.display, "none");
  }
  console.log("PASS unapproved fallback URLs are never assigned to image src");
  {
    const { client, calls, created } = load({ resolverResponse: okPayload() });
    const link = makeElement({ "data-photo-href": OWN_PATH });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    await client.hydrate(makeRoot([element], [link]), ACTOR, CONFIG);
    assert.ok(link.href.startsWith("blob:"), "thumbnail links must use a no-store blob");
    assert.equal(link.getAttribute("data-photo-href"), null);
    assert.equal(created.length, 1, "the image and its thumbnail link share one downloaded blob");
    assert.equal(link.href, element.src, "both elements must share the same in-memory blob URL");
    assert.equal(calls.image.length, 1, "one photo reference must cause one Storage download");
    console.log("PASS thumbnail links and images share one no-store blob URL");
  }

  // ------------------------------------------------------------ denials and fallbacks
  {
    const { client, calls } = load({ resolverResponse: { status: 403, body: { ok: false, error: "DENIED" } } });
    const element = makeElement({ "data-photo-ref": OWN_PATH, "data-photo-fallback": "./logo.jpeg" });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(element.src, "./logo.jpeg", "a denied photo falls back and never reaches storage");
    assert.equal(calls.image.length, 0, "no image request is made for a denied reference");
    console.log("PASS denied photos never trigger a storage request");
  }
  {
    const { client, calls } = load({ resolverResponse: { status: 403, body: { ok: false, error: "DENIED" } } });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(element.src, "", "without a fallback the image stays empty");
    assert.equal(element.style.display, "none", "and it is hidden instead of showing a broken image");
    assert.equal(calls.image.length, 0);
    console.log("PASS a denied photo without fallback is hidden");
  }

  // ------------------------------------------------------------ lifetime and cleanup
  {
    const { client, calls, clock } = load({ resolverResponse: okPayload() });
    const root = makeRoot([makeElement({ "data-photo-ref": OWN_PATH })]);
    await client.hydrate(root, ACTOR, CONFIG);
    await client.hydrate(makeRoot([makeElement({ "data-photo-ref": OWN_PATH })]), ACTOR, CONFIG);
    assert.equal(calls.resolver.length, 1, "a valid signed URL is reused instead of re-minted");
    assert.equal(calls.image.length, 1, "a re-render reuses the already-downloaded blob");

    clock.value += 51 * 1000; // past the 50s usable window (60s TTL - 10s skew)
    await client.hydrate(makeRoot([makeElement({ "data-photo-ref": OWN_PATH })]), ACTOR, CONFIG);
    assert.equal(calls.resolver.length, 2, "an expired URL is never reused");
    assert.equal(calls.image.length, 2, "an expired blob is downloaded only after a fresh signed URL");
    console.log("PASS signed URL and blob caches expire 10s before the 60s signed URL does");
  }
  {
    const { client, created, revoked } = load({ resolverResponse: okPayload() });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    client.clearCache();
    assert.deepEqual(revoked, [created[0].url], "blob URLs are revoked when the cache is cleared");
    console.log("PASS clearCache() revokes the blob URLs it created");
  }
  {
    const { client, created, revoked } = load({ resolverResponse: okPayload() });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    // Re-rendering the same element (for example after a data refresh) must not
    // leak the previous blob URL.
    element.setAttribute("data-photo-ref", OWN_PATH);
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(created.length, 1, "re-displaying reuses the same cached blob");
    assert.deepEqual(revoked, [], "the blob remains available while its short cache window is valid");
    console.log("PASS re-displaying an element reuses its cached blob URL");
  }

  {
    const { client, calls, observers } = load({ resolverResponse: okPayload(), lazy: true });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    await client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    assert.equal(calls.resolver.length, 0, "off-screen photos must not request signed URLs before intersection");
    assert.equal(calls.image.length, 0, "off-screen photos must not download image bytes");
    assert.equal(observers.length, 1);
    assert.equal(observers[0].options.rootMargin, "250px 0px");
    await observers[0].trigger(element);
    assert.equal(calls.resolver.length, 1);
    assert.equal(calls.image.length, 1);
    assert.ok(element.src.startsWith("blob:"));
    console.log("PASS off-screen photos defer resolver and Storage downloads until near the viewport");
  }
  {
    const { client, calls, created, revoked } = load({ resolverResponse: okPayload() });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    const link = makeElement({ "data-photo-href": OWN_PATH });
    const root = makeRoot([element], [link]);
    await client.hydrate(root, ACTOR, CONFIG);
    client.release(root);
    assert.equal(element.src, "");
    assert.equal(link.href, "");
    assert.equal(created.length, 1);
    assert.deepEqual(revoked, []);
    await client.hydrate(makeRoot([makeElement({ "data-photo-ref": OWN_PATH })]), ACTOR, CONFIG);
    assert.equal(calls.resolver.length, 1);
    assert.equal(calls.image.length, 1);
    console.log("PASS releasing a replaced subtree drops element references but retains the short-lived blob cache");
  }
  {
    const { client, calls } = load({ resolverResponse: okPayload() });
    await client.resolve(OWN_PATH, ACTOR, CONFIG);
    await client.resolve(OWN_PATH, { ...ACTOR, mobile_number: "invalid" }, CONFIG);
    assert.equal(calls.resolver.length, 2, "changed credentials require a new authorization request");
    console.log("PASS credential changes cannot reuse prior authorization cache");
  }
  {
    const { client, context } = load({ resolverResponse: okPayload() });
    let release;
    context.fetch = () => new Promise(resolve => { release = resolve; });
    const pending = client.resolve(OWN_PATH, ACTOR, CONFIG);
    client.clearCache();
    release({ ok: true, json: async () => okPayload() });
    assert.equal(await pending, "");
    assert.equal(client.peek(OWN_PATH, ACTOR), "");
    console.log("PASS logout invalidates pending resolver results");
  }
  {
    const { client, context, revoked } = load({ resolverResponse: okPayload() });
    const originalFetch = context.fetch;
    let release;
    context.fetch = (url, options) => String(url).includes("/functions/")
      ? originalFetch(url, options)
      : new Promise(resolve => { release = resolve; });
    const element = makeElement({ "data-photo-ref": OWN_PATH });
    const pending = client.hydrate(makeRoot([element]), ACTOR, CONFIG);
    while (!release) await Promise.resolve();
    client.clearCache();
    release({ ok: true, blob: async () => ({ size: 100 }) });
    await pending;
    assert.equal(element.src, "");
    assert.equal(revoked.length, 0, "a stale pending fetch must not create or leak a blob URL");
    console.log("PASS logout during image fetch prevents stale display and avoids creating a blob");
  }
  {
    const { client, calls } = load({ resolverResponse: okPayload() });
    await client.resolve(OWN_PATH, {type:"employee_device",device_token:"TOKEN",device_id:"device-A"}, CONFIG);
    await client.resolve(OWN_PATH, {type:"employee_device",device_token:"TOKEN",device_id:"device-B"}, CONFIG);
    assert.equal(calls.resolver.length, 2, "a copied token with another device ID cannot reuse authorized cache");
    assert.equal(await client.resolve(OWN_PATH, {type:"employee_device",device_token:"TOKEN"}, CONFIG), "");
    console.log("PASS device identity participates in photo authorization cache; missing identity denied locally");
  }
  console.log("\nAll employee-photo client cache tests passed.");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
