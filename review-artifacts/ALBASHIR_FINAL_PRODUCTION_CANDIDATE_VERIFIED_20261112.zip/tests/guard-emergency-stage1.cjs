const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { PGlite } = require('@electric-sql/pglite');
const { pgcrypto } = require('@electric-sql/pglite/contrib/pgcrypto');

const root = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8').replace(/\r\n/g, '\n');

(async () => {
  // 1. Verify Staging and Canonical SQL unification parity
  const stagingSql = read('supabase/staging_alignment_reviewed.sql');
  const canonicalSql = read('supabase/canonical/guard_emergency_stage1_unification.sql');
  for (const fnName of [
    'private.guard_qr_generation_failure_status',
    'public.guard_manual_employee_entry(',
    'public.guard_manual_employee_entry_v2(',
    'public.guard_session_status(',
    'public.guard_set_emergency('
  ]) {
    assert(stagingSql.includes(fnName), `staging_alignment_reviewed.sql missing ${fnName}`);
    assert(canonicalSql.includes(fnName), `guard_emergency_stage1_unification.sql missing ${fnName}`);
  }

  // 2. Database-level verification of all 8 Stage 1 Acceptance Criteria
  const db = new PGlite({ extensions: { pgcrypto } });
  try {
    const source = read('tests/fresh-install-readiness.cjs');
    const start = source.lastIndexOf('await db.exec(`', source.indexOf('create role anon')) + 15;
    const end = source.indexOf('`);', start);
    await db.exec(Function('return `' + source.slice(start, end) + '`;')());
    await db.exec(read('schema_consolidated_fresh_install.sql'));
    await db.exec(`
      CREATE TABLE private.guard_accounts (
        id uuid primary key default gen_random_uuid(),
        full_name text not null,
        national_id text not null unique,
        phone_hash text not null,
        phone_hint text not null,
        is_active boolean not null default true,
        is_shared boolean not null default false,
        created_at timestamptz not null default now()
      );
      CREATE TABLE private.guard_sessions (
        token_hash text primary key,
        guard_id uuid not null references private.guard_accounts(id) on delete cascade,
        expires_at timestamptz not null default now() + interval '24 hours'
      );
      CREATE TABLE private.guard_emergency_settings (
        singleton boolean primary key default true check(singleton),
        enabled boolean not null default false
      );
      INSERT INTO private.guard_emergency_settings(singleton, enabled) VALUES (true, false);
      CREATE TABLE private.guard_manual_entries (
        guard_id uuid not null references private.guard_accounts(id),
        request_id uuid not null,
        employee_id text not null,
        response jsonb not null,
        created_at timestamptz not null default now(),
        primary key(guard_id, request_id)
      );
      CREATE TABLE private.guard_qr_generation_errors (
        minute_at timestamptz not null,
        error_code text not null,
        error_count integer not null default 1,
        primary key(minute_at, error_code)
      );
      CREATE OR REPLACE FUNCTION private.guard_qr_log_failure(p_code text) RETURNS void
      LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog', 'private' AS $f$
      begin
        insert into private.guard_qr_generation_errors(minute_at,error_code,error_count)
        values(date_trunc('minute',clock_timestamp()),left(coalesce(p_code,'UNKNOWN'),36),1)
        on conflict(minute_at,error_code)
        do update set error_count=private.guard_qr_generation_errors.error_count+1;
      end;
      $f$;
      CREATE OR REPLACE FUNCTION private.guard_session_id(p_token text) RETURNS uuid
      LANGUAGE sql STABLE SET search_path TO 'pg_catalog', 'private', 'extensions' AS $f$
        select g.id from private.guard_sessions s join private.guard_accounts g on g.id=s.guard_id
        where p_token ~ '^[0-9a-f]{64}$' and s.token_hash=encode(extensions.digest(p_token,'sha256'),'hex')
          and s.expires_at>now() and g.is_active;
      $f$;
      REVOKE ALL ON private.guard_accounts, private.guard_sessions, private.guard_emergency_settings,
        private.guard_manual_entries, private.guard_qr_generation_errors FROM public, anon, authenticated;
      REVOKE ALL ON FUNCTION private.guard_session_id(text), private.guard_qr_log_failure(text) FROM public, anon, authenticated;
    `);
    await db.exec(canonicalSql);

    const call = async (sql, args = []) => (await db.query(sql, args)).rows[0].r;

    // Provision active guard session and test employees (permanent + daily-limited temporary)
    const token = 'a'.repeat(64);
    await db.exec(`
      INSERT INTO private.guard_accounts(id, full_name, national_id, phone_hash, phone_hint, is_active)
      VALUES ('11111111-1111-4111-8111-111111111111', 'حارس البوابة', '999999991', 'hash', '9901', true);
      INSERT INTO private.guard_sessions(token_hash, guard_id, expires_at)
      VALUES (encode(extensions.digest('${token}','sha256'),'hex'), '11111111-1111-4111-8111-111111111111', now() + interval '24 hours');
    `);

    await db.exec(`
      INSERT INTO public.employee_registrations(full_name,employee_id,mobile_number,specialty,status,job_type,employee_photo_url)
      VALUES
        ('موظف دائم','EMP-ALLOW','0790000001','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','APPROVED','طبيب','registrations/EMP-ALLOW/a.jpg'),
        ('موظف مؤقت','EMP-LIMIT','0790000002','اختصاص مؤقت محدود','APPROVED','فني',null);
      INSERT INTO public.specialty_daily_limits(specialty_name,daily_limit,is_active)
      VALUES ('اختصاص مؤقت محدود',1,true)
      ON CONFLICT (specialty_name) DO UPDATE SET daily_limit=1, is_active=true;
    `);

    // Add controllable QR generator state to simulate healthy, failed, and unverified (RATE_LIMITED) states
    await db.exec(`
      CREATE TABLE public.test_qr_mode(mode text);
      INSERT INTO public.test_qr_mode VALUES ('HEALTHY');
      GRANT SELECT ON public.test_qr_mode TO anon, authenticated;
    `);
    const origQrDef = (await db.query("SELECT pg_get_functiondef('public.create_public_guard_qr()'::regprocedure) d")).rows[0].d;
    await db.exec(`
      CREATE OR REPLACE FUNCTION public.create_public_guard_qr()
      RETURNS jsonb
      LANGUAGE plpgsql
      SECURITY DEFINER
      SET search_path TO 'pg_catalog', 'public', 'private', 'extensions'
      AS $fn$
      declare
        m text := (select mode from public.test_qr_mode limit 1);
        q public.qr_sessions%rowtype;
        rk text;
      begin
        if m = 'FAILED' then
          perform private.guard_qr_log_failure('DB_SIMULATED');
          return jsonb_build_object('ok',false,'error','QR_GENERATION_FAILED','retry_after_seconds',2,'message','تعذر توليد QR مؤقتًا');
        elsif m = 'RATE_LIMITED' then
          perform private.guard_qr_log_failure('RATE_LIMITED');
          return jsonb_build_object('ok',false,'error','RATE_LIMITED','retry_after_seconds',2,'message','ازدحام مؤقت');
        end if;
        rk := encode(extensions.gen_random_bytes(32),'hex');
        insert into public.qr_sessions(expires_at) values(now()+interval '30 seconds') returning * into q;
        insert into private.public_guard_sessions(qr_session_id,read_key_hash,expires_at)
        values(q.id,encode(extensions.digest(rk,'sha256'),'hex'),now()+interval '6 minutes');
        return jsonb_build_object('ok',true,'token',q.token::text,'expires_at',q.expires_at,'server_now',now(),'expires_in_seconds',30,'read_key',rk);
      end;
      $fn$;
    `);

    await db.exec("SET ROLE anon;");

    // Criterion 5: الحارس غير مسجل -> رفض الدخول
    assert.equal((await call("SELECT guard_manual_employee_entry_v2('invalid_token','EMP-ALLOW',gen_random_uuid(),null) r")).error, 'AUTH_REQUIRED');
    assert.equal((await call("SELECT guard_session_status('invalid_token') r")).error, 'AUTH_REQUIRED');
    assert.equal((await call("SELECT guard_set_emergency('invalid_token',true) r")).error, 'AUTH_REQUIRED');

    // Criterion 1: QR يعمل -> منع الدخول اليدوي
    const liveQr = await call("SELECT create_public_guard_qr() r");
    assert.equal(liveQr.ok, true);
    // Unexpired screen QR is rejected with SCREEN_NOT_EXPIRED
    assert.equal((await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',gen_random_uuid(),$2) r", [token, liveQr.read_key])).error, 'SCREEN_NOT_EXPIRED');
    // Without screen readKey while QR works is rejected with SCREEN_REQUIRED
    assert.equal((await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',gen_random_uuid(),'') r", [token])).error, 'SCREEN_REQUIRED');
    // Even if screen QR expired, if server QR generation is healthy, manual entry is rejected with QR_AVAILABLE
    await db.exec("RESET ROLE; UPDATE public.qr_sessions SET expires_at = now() - interval '2 seconds'; SET ROLE anon;");
    assert.equal((await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',gen_random_uuid(),$2) r", [token, liveQr.read_key])).error, 'QR_AVAILABLE');

    // Criterion 8: تعذر إثبات تعطل QR -> رفض تفعيل الطوارئ
    // Healthy QR cannot enable emergency
    assert.equal((await call("SELECT guard_set_emergency($1,true) r", [token])).error, 'QR_NOT_FAILED');
    // RATE_LIMITED (not a generator failure) also refuses emergency activation and manual entry
    await db.exec("RESET ROLE; UPDATE public.test_qr_mode SET mode='RATE_LIMITED'; SET ROLE anon;");
    assert.equal((await call("SELECT guard_set_emergency($1,true) r", [token])).error, 'QR_NOT_FAILED');
    assert.equal((await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',gen_random_uuid(),$2) r", [token, liveQr.read_key])).error, 'QR_AVAILABLE');

    // Criterion 2: QR تعطل منذ أول فتح الشاشة (لا يوجد readKey) -> السماح بالطوارئ بعد تحقق الخادم
    await db.exec("RESET ROLE; UPDATE public.test_qr_mode SET mode='FAILED'; UPDATE private.guard_emergency_settings SET enabled=false; SET ROLE anon;");
    const coldReqId = '11111111-2222-4333-8444-555555555555';
    const coldEntry = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',$2,'') r", [token, coldReqId]);
    assert.equal(coldEntry.ok, true);
    assert.equal(coldEntry.result, 'ALLOWED');
    assert.equal(coldEntry.counted, true);

    // Criterion 6: تكرار طلب الدخول -> عدم احتساب زيارة ثانية
    const coldReplay = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',$2,'') r", [token, coldReqId]);
    assert.deepEqual(coldReplay, coldEntry);
    await db.exec("RESET ROLE;");
    assert.equal(Number((await db.query("SELECT count(*) n FROM public.gate_access_logs WHERE employee_id='EMP-ALLOW'")).rows[0].n), 1);

    // Criterion 3: QR تعطل بعد انتهاء الرمز -> تفعيل الطوارئ
    await db.exec("UPDATE private.guard_emergency_settings SET enabled=false; SET ROLE anon;");
    const statusWhenFailed = await call("SELECT guard_session_status($1) r", [token]);
    assert.equal(statusWhenFailed.ok, true);
    assert.equal(statusWhenFailed.emergency_enabled, true);
    const expiredKeyReqId = '22222222-3333-4444-8555-666666666666';
    const expiredKeyEntry = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',$2,$3) r", [token, expiredKeyReqId, liveQr.read_key]);
    assert.equal(expiredKeyEntry.ok, true);
    assert.equal(expiredKeyEntry.result, 'ALLOWED');

    // Criterion 7: تجاوز الحد اليومي -> تطبيق المنع
    const limitFirst = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-LIMIT',gen_random_uuid(),$2) r", [token, liveQr.read_key]);
    assert.equal(limitFirst.ok, true);
    assert.equal(limitFirst.result, 'LIMITED');
    assert.equal(limitFirst.counted, true);
    const limitSecond = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-LIMIT',gen_random_uuid(),$2) r", [token, liveQr.read_key]);
    assert.equal(limitSecond.ok, true);
    assert.equal(limitSecond.result, 'DENIED');
    assert.equal(limitSecond.counted, false);

    // Criterion 4: QR عاد للعمل -> إيقاف الطوارئ
    await db.exec("RESET ROLE; UPDATE public.test_qr_mode SET mode='HEALTHY'; SET ROLE anon;");
    const statusAfterRecovery = await call("SELECT guard_session_status($1) r", [token]);
    assert.equal(statusAfterRecovery.ok, true);
    assert.equal(statusAfterRecovery.emergency_enabled, false);
    const deniedAfterRecovery = await call("SELECT guard_manual_employee_entry_v2($1,'EMP-ALLOW',gen_random_uuid(),$2) r", [token, liveQr.read_key]);
    assert.equal(deniedAfterRecovery.ok, false);
    assert.equal(deniedAfterRecovery.error, 'QR_AVAILABLE');
    await db.exec("RESET ROLE;");
    assert.equal((await db.query("SELECT enabled FROM private.guard_emergency_settings")).rows[0].enabled, false);

    // Restore original create_public_guard_qr definition check
    assert(origQrDef.includes('create_public_guard_qr'));
    console.log('PASS Stage 1 DB: all 8 acceptance criteria verified against PostgreSQL');
  } finally {
    await db.close();
  }

  // 3. Frontend runtime verification (guard.html + guard-manual.js + guard-manual.css)
  const guardHtml = read('guard.html');
  const guardCss = read('guard-manual.css');
  const guardManualJs = read('guard-manual.js');

  assert(guardHtml.includes('id="guardManualInstructions"'), 'guard.html must contain elderly-friendly instruction block');
  assert(guardHtml.includes('تعليمات واضحة للحارس'), 'guard.html must contain clear Arabic instructions for the guard');
  assert(guardCss.includes('.guard-elder-guide'), 'guard-manual.css must style elderly-friendly guide');

  // Execute guard-manual.js in an isolated DOM context to verify UI state transitions across scenarios
  const elements = {};
  const makeEl = id => ({
    id,
    hidden: ['guardManualPanel', 'guardEntryForm', 'guardSessionHeader', 'guardAvatar', 'result', 'photo'].includes(id),
    disabled: false,
    value: '',
    textContent: '',
    className: '',
    inert: false,
    onclick: null,
    onsubmit: null,
    addEventListener: () => {},
    removeAttribute: () => {},
    focus: () => {},
    querySelectorAll: () => [],
    getClientRects: () => [1]
  });
  for (const id of [
    'qr', 'qrPanel', 'guardManualPanel', 'guardManualInstructions', 'guardLoginForm', 'guardEntryForm',
    'guardIdentity', 'guardPhone', 'guardLoginButton', 'guardSharedLogin', 'guardWelcome',
    'guardEmergencyToggle', 'manualEmployeeId', 'guardEntryButton', 'guardLogoutButton',
    'guardManualMessage', 'manualOpen', 'manualClose', 'guardSessionHeader', 'guardSessionName',
    'guardSessionTime', 'guardAvatar', 'result', 'decision', 'name', 'job', 'specialty', 'photo'
  ]) {
    elements[id] = makeEl(id);
  }

  const windowListeners = {};
  const rpcCalls = [];
  let simulatedServerQrFailed = true;
  let simulatedTransportFailOnce = false;

  const ctx = {
    console,
    Date,
    Error,
    Boolean,
    URL: { revokeObjectURL: () => {} },
    crypto: { randomUUID: () => crypto.randomUUID() },
    performance: { now: () => 1000 },
    current: null, // Cold start: no QR generated yet (no readKey)
    photoGeneration: 0,
    photoBlob: null,
    startResultPrivacy: () => {},
    loadPhoto: () => {},
    localStorage: {
      store: { alb_guard_session_v1: 'a'.repeat(64) },
      getItem(k) { return this.store[k] || null; },
      setItem(k, v) { this.store[k] = v; },
      removeItem(k) { delete this.store[k]; }
    },
    document: {
      getElementById: id => elements[id] || (elements[id] = makeEl(id)),
      body: { classList: { toggle: () => {} } },
      querySelector: () => ({ children: [elements.qrPanel, elements.guardManualPanel, elements.result] }),
      activeElement: null
    },
    window: {
      addEventListener: (type, fn) => { windowListeners[type] = fn; }
    },
    guardRpc: async (name, payload) => {
      rpcCalls.push({ name, payload: { ...payload } });
      if (name === 'guard_session_profile') {
        return { data: { ok: true, full_name: 'حارس البوابة', logged_in_at: new Date().toISOString() }, error: null };
      }
      if (name === 'guard_session_status') {
        return {
          data: {
            ok: true,
            full_name: 'حارس البوابة',
            emergency_enabled: simulatedServerQrFailed,
            emergency_available: simulatedServerQrFailed,
            qr_generation_failed: simulatedServerQrFailed
          },
          error: null
        };
      }
      if (name === 'guard_manual_employee_entry_v2') {
        if (simulatedTransportFailOnce) {
          simulatedTransportFailOnce = false;
          return { data: null, error: new Error('timeout') };
        }
        return {
          data: {
            ok: true,
            result: 'ALLOWED',
            employee: { full_name: 'موظف اختبار', job_type: 'طبيب', specialty: 'طوارئ', has_photo: false }
          },
          error: null
        };
      }
      return { data: { ok: true }, error: null };
    }
  };

  vm.createContext(ctx);
  vm.runInContext(guardManualJs, ctx);

  // Open manual panel during cold-start QR failure (current === null, no readKey)
  await elements.manualOpen.onclick();
  assert.equal(elements.guardEntryForm.hidden, false);
  assert.equal(elements.guardEntryButton.disabled, false, 'Emergency entry button must be enabled on cold-start server QR failure');

  // Submit employee ID with transport failure on first try, then retry with same employee ID
  elements.manualEmployeeId.value = 'EMP-100';
  simulatedTransportFailOnce = true;
  await elements.guardEntryForm.onsubmit({ preventDefault: () => {} });
  // Retry same employee ID -> must send identical p_request_id and empty p_screen_read_key ('')
  await elements.guardEntryForm.onsubmit({ preventDefault: () => {} });
  const v2Calls = rpcCalls.filter(c => c.name === 'guard_manual_employee_entry_v2');
  assert.equal(v2Calls.length, 2);
  assert.equal(v2Calls[0].payload.p_screen_read_key, '');
  assert.equal(v2Calls[0].payload.p_request_id, v2Calls[1].payload.p_request_id, 'Retry after transport error must reuse same request_id');
  assert.equal(elements.decision.textContent, 'مسموح بالدخول');

  // Simulate QR recovery on screen -> emergency mode must immediately stop and block manual entry
  simulatedServerQrFailed = false;
  ctx.current = { expiresAt: Date.now() + 25000, deadline: 26000, readDeadline: 360000, readKey: 'b'.repeat(64) };
  elements.qr.hidden = false;
  await windowListeners['guard-qr-health-change']();
  assert.equal(elements.guardEntryButton.disabled, true, 'Manual entry button must be disabled as soon as QR recovers');
  assert(elements.guardManualMessage.textContent.includes('عاد رمز المربع (QR) للعمل'), 'Recovery message must be shown to guard');

  console.log('PASS Stage 1 Frontend: cold-start without readKey, idempotent retry, and automatic stop on QR recovery');
})().catch(err => {
  console.error(err);
  process.exitCode = 1;
});
