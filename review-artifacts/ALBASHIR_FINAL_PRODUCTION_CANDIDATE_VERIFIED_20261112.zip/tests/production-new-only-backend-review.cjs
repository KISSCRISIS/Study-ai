"use strict";
// Static offline safety contract, no DB calls.
const assert=require("node:assert/strict");
const fs=require("node:fs"),path=require("node:path");
const root=path.join(__dirname,"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
const original=read("supabase/review/production_15arg_original_20261111.sql").trimEnd();
const sql=read("supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql");
const rollback=read("supabase/review/production_backend_ROLLBACK_LOCKED_20261111.sql");
const staging=read("supabase/review/STAGING_ROLLBACK_PRODUCTION_PARITY_20261111.sql");
function has(source,needle){assert(source.includes(needle),"Missing required safety text: "+needle);}
const originalName="CREATE OR REPLACE FUNCTION public.register_employee_request(";
const start=sql.indexOf(originalName),stop=sql.indexOf("$function$;",start);
assert(start>=0&&stop>start,"Production compatibility function missing");
const legacy=sql.slice(start,stop+"$function$;".length);
const marker="  -- New security applies to first-time employees only.";
const guard=legacy.indexOf(marker),oldBranch=legacy.indexOf("  if reg.id is null then",guard);
assert(guard>=0&&oldBranch>guard,"Original first-time-only guard missing");
const restored=(legacy.slice(0,guard)+legacy.slice(oldBranch)).trimEnd().replace(/;$/,"").trimEnd();
assert.equal(restored,original,"Registered employee logic differs from the captured live Production original");
has(sql,"reg.created_at <= c.freeze_at");
has(sql,"if reg.id is not null then");
has(sql,"CREATE OR REPLACE FUNCTION private.register_employee_request_new_core(");
has(sql,"RETURN private.register_employee_request_new_core(");
has(sql,"p_full_name,p_employee_id,p_mobile_number,p_specialty,NULL,");
has(sql,"clean_photo !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'");
has(sql,"private.new_employee_photo_attestations");
has(sql,"RAISE EXCEPTION 'REVIEW ONLY: do not apply to Production");
has(rollback,"RAISE EXCEPTION 'REVIEW ONLY: rollback requires explicit Production approval");
assert.equal(sql.split("CREATE OR REPLACE FUNCTION public.register_new_employee_request(").length-1,1);
assert.equal(sql.split("RETURN private.register_employee_request_new_core(").length-1,1);
for(const destructive of ["DELETE FROM public.employee_registrations","TRUNCATE public.employee_registrations",
 "DROP TABLE public.employee_registrations","DELETE FROM storage.objects","DROP TABLE private.new_employee_photo_attestations"]){
 assert(!sql.includes(destructive),"Forbidden operation in reviewed migration: "+destructive);
}
has(staging,"QA-PR58!STAGING");
has(staging,"BEGIN;");
has(staging,"ROLLBACK;");
has(staging,"new_pending");
has(staging,"duplicate_core_denied");
has(staging,"new_id_legacy_denied");
assert(!staging.includes("qinsfvlspdticposbvst"),"Staging-only test refers to Production");
console.log("PASS locked Production-derived backend parity, Stage rollback QA contract, and historical zero-touch");
