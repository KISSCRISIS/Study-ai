"use strict";
// tests/test_pg17_fencing_integration.cjs
// REAL end-to-end proof on a standalone PostgreSQL 17 server over independent TCP connections:
// the production handler (handler.mjs) is wired to the REAL SQL functions (claim / consume /
// assert_new_photo_upload_lease / attest / finalize) and a Storage stand-in that writes the
// real storage.objects table. Nothing is mocked in the quota/fencing/attestation logic.
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const path = require("node:path");
const { Pool, Client } = require("pg");
const { setupDatabase } = require("./test_backend_pg17_server.cjs");

if (!globalThis.crypto?.subtle) globalThis.crypto = crypto.webcrypto;
const dsn = process.env.ALBASHIR_LOCAL_PG_DSN || "postgresql://postgres@127.0.0.1:5432/albashir_qa";
const ORIGIN = "https://albashir-staging.vercel.app";

function jpeg(seed) {
  const header = [0xff,0xd8,0xff,0xe0,0x00,0x10,0x4a,0x46,0x49,0x46,0x00,0x01,0x01,0x01,0x00,0x48,0x00,0x48,0x00,0x00,
    0xff,0xc0,0x00,0x11,0x08,0x00,0x40,0x00,0x40,0x03,0x01,0x11,0x00,0x02,0x11,0x01,0x03,0x11,0x01,
    0xff,0xda,0x00,0x0c,0x03,0x01,0x00,0x02,0x11,0x03,0x11,0x00,0x3f,0x00];
  const payload = new Uint8Array(48).map((_, i) => ((seed * 29 + i * 13) & 0x7f) + 1);
  const out = new Uint8Array(header.length + payload.length + 2);
  out.set(header, 0); out.set(payload, header.length);
  out[out.length - 2] = 0xff; out[out.length - 1] = 0xd9;
  return out;
}
let seed = 1;
const req = (employeeId) => ({
  method: "POST", headers: { origin: ORIGIN }, trustedSource: null,
  form: { employee_id: employeeId, fileName: "employee.jpg", mimeType: "image/jpeg", bytes: jpeg(seed++), "cf-turnstile-response": "ok" }
});

let pool, owner, handlerMod;
const log = [];
function record(name, ok, detail = "") { log.push({ name, ok }); console.log(`  ${ok ? "PASS" : "FAIL"}: ${name}${detail ? " (" + detail + ")" : ""}`); }

async function rpc(fn, args, { allowError = false } = {}) {
  const c = await pool.connect();
  try {
    await c.query("SELECT set_config('request.jwt.claim.role','service_role',false)");
    await c.query("SET ROLE service_role");
    try {
      const params = args.map((_, i) => "$" + (i + 1)).join(",");
      const r = await c.query(`SELECT public.${fn}(${params}) AS r`, args);
      return r.rows[0].r;
    } finally {
      await c.query("RESET ROLE");
      await c.query("SELECT set_config('request.jwt.claim.role','',false)");
    }
  } finally { c.release(); }
}

function makeDeps(hooks = {}) {
  const trace = { removed: [], uploaded: [], events: [] };
  const deps = {
    allowedOrigins: ORIGIN,
    randomUUID: () => crypto.randomUUID(),
    async verifyTurnstile() { return { ok: true }; },
    async claimUploadQuota({ employeeId, sourceKey }) { return rpc("claim_new_photo_upload_quota", [employeeId, sourceKey]); },
    async consumeUploadQuota(leaseId) { const r = await rpc("consume_new_photo_upload_quota", [leaseId]); return { ...r, lease_id: r.lease_id || leaseId }; },
    async releaseUploadQuota(leaseId) { const r = await rpc("release_new_photo_upload_quota", [leaseId]); return { ok: r.allowed === true, reason: r.reason }; },
    async assertUploadLease(leaseId) { trace.events.push("assert"); if (hooks.beforeAssert) await hooks.beforeAssert(); return rpc("assert_new_photo_upload_lease", [leaseId]); },
    async finalizeUploadQuota(leaseId) { trace.events.push("finalize"); if (hooks.finalize) return hooks.finalize(leaseId, () => rpc("finalize_new_photo_upload_quota", [leaseId])); return rpc("finalize_new_photo_upload_quota", [leaseId]); },
    async checkEligibility(id) { const r = await rpc("employee_photo_new_registration_eligible", [id]); return { ok: r?.ok === true, is_new: r?.is_new === true }; },
    async uploadObject(p, bytes) {
      if (hooks.beforeUpload) await hooks.beforeUpload();
      await owner.query(`INSERT INTO storage.objects(bucket_id,name,metadata) VALUES('employee-photos',$1,$2::jsonb)`,
        [p, JSON.stringify({ size: bytes.byteLength, mimetype: "image/jpeg" })]);
      trace.uploaded.push(p); trace.events.push("upload");
      return { ok: true };
    },
    async registerPendingUpload(p) { const r = await rpc("register_pending_employee_upload", [p]); return { ok: r?.ok === true }; },
    async attestNewPhoto(id, p, leaseId) {
      if (hooks.beforeAttest) await hooks.beforeAttest(id, p, leaseId);
      const r = await rpc("attest_new_employee_photo", leaseId ? [id, p, leaseId] : [id, p]);
      trace.events.push("attest");
      if (hooks.afterAttest) await hooks.afterAttest();
      return { ok: r?.ok === true, reason: r?.reason, code: r?.code };
    },
    async removeObject(p) { await owner.query(`DELETE FROM storage.objects WHERE bucket_id='employee-photos' AND name=$1`, [p]); trace.removed.push(p); return { ok: true }; },
    async confirmPendingRemoval(p) { await rpc("employee_photo_confirm_removal", [[p]]); return { ok: true }; }
  };
  return { deps, trace };
}

const run = (r, deps) => handlerMod.handleNewPhotoUpload(r, deps, handlerMod.createUploadState());
const claimsOf = async (emp) => (await owner.query(
  `SELECT lease_id,status,finalized_at IS NOT NULL AS fin FROM private.new_photo_upload_claims ORDER BY created_at`)).rows;
const attestedFor = async (emp) => (await owner.query(`SELECT object_path FROM private.new_employee_photo_attestations WHERE employee_id=$1`, [emp])).rows.map(r => r.object_path);
const objectsFor = async (emp) => (await owner.query(`SELECT name FROM storage.objects WHERE bucket_id='employee-photos' AND name LIKE $1`, [`registrations/${emp}/%`])).rows.map(r => r.name);
const age = (lease, sec = 61) => owner.query(`UPDATE private.new_photo_upload_claims SET created_at = created_at - make_interval(secs => $2) WHERE lease_id=$1`, [lease, sec]);
const claimFor = async (emp) => (await owner.query(`SELECT lease_id,status FROM private.new_photo_upload_claims c ORDER BY created_at DESC`)).rows;
const leaseOfLatest = async () => (await owner.query(`SELECT lease_id FROM private.new_photo_upload_claims ORDER BY created_at DESC LIMIT 1`)).rows[0].lease_id;

(async () => {
  owner = new Client({ connectionString: dsn });
  await owner.connect();
  console.log("Connected:", (await owner.query("select version()")).rows[0].version);
  await setupDatabase(owner);
  await owner.query("TRUNCATE storage.objects");   // storage schema survives setupDatabase(); start clean
  pool = new Pool({ connectionString: dsn, max: 12 });
  handlerMod = await import("file://" + path.resolve(__dirname, "../supabase/functions/employee-photo-upload-new/handler.mjs").replace(/\\/g, "/"));

  console.log("\n[S1] Happy path with REAL SQL: 201 only after attest + FINALIZED");
  {
    const emp = "FNC-HAPPY"; const { deps, trace } = makeDeps();
    const r = await run(req(emp), deps);
    const st = (await claimsOf(emp)).map(c => c.status);
    record("S1 handler returns 201", r.status === 201, `status=${r.status} ${r.body?.code || ""}`);
    record("S1 claim ends FINALIZED", st.includes("FINALIZED"), st.join(","));
    record("S1 photo attested + stored", (await attestedFor(emp)).length === 1 && (await objectsFor(emp)).length === 1);
    record("S1 order assert -> attest -> finalize", JSON.stringify(trace.events.filter(e => ["assert","attest","finalize"].includes(e))) === '["assert","attest","finalize"]');
  }

  console.log("\n[S2] 8 concurrent uploads, same employee, 8 independent isolates/TCP connections");
  {
    const emp = "FNC-RACE";
    // Each upload is held 400 ms inside the in-flight window so a broken lock would let several overlap.
    const slow = () => makeDeps({ beforeUpload: () => new Promise(r => setTimeout(r, 400)) }).deps;
    const results = await Promise.all(Array.from({ length: 8 }, () => run(req(emp), slow())));
    const ok = results.filter(r => r.status === 201).length; const locked = results.filter(r => r.status === 409).length;
    record("S2 exactly one 201 while the others are locked out (409)", ok === 1 && locked === 7, `201=${ok}, 409=${locked}, other=${results.length - ok - locked}`);
    record("S2 exactly one attested photo and one stored object", (await attestedFor(emp)).length === 1 && (await objectsFor(emp)).length === 1);
  }

  console.log("\n[S3] Lease expires/superseded BEFORE attest: stale upload cannot attest and its object is removed");
  {
    const emp = "FNC-STALE"; let release; const gate = new Promise(r => (release = r));
    let aLease = null;
    const A = makeDeps({ async beforeUpload() { aLease = await leaseOfLatest(); await gate; } });
    const pA = run(req(emp), A.deps);
    // wait until A holds a lease and is paused in upload
    for (let i = 0; i < 100 && !aLease; i++) await new Promise(r => setTimeout(r, 20));
    await age(aLease);                                         // A is now past the 60s in-flight window
    const B = makeDeps();
    const rB = await run(req(emp), B.deps);                    // B legitimately takes over
    release();
    const rA = await pA;
    const claims = await owner.query(`SELECT lease_id,status FROM private.new_photo_upload_claims WHERE lease_id=$1`, [aLease]);
    record("S3 newer upload B succeeds (201)", rB.status === 201, `status=${rB.status}`);
    record("S3 stale upload A is rejected 409 (never 201)", rA.status === 409 && rA.body.code === "UPLOAD_SUPERSEDED", `status=${rA.status}`);
    record("S3 A did not attest (only B attested)", (await attestedFor(emp)).length === 1 && !(await attestedFor(emp)).some(p => A.trace.uploaded.includes(p)));
    record("S3 A's unattested object deleted, B's object intact", A.trace.removed.length === 1 && (await objectsFor(emp)).length === 1 && (await objectsFor(emp))[0] === B.trace.uploaded[0]);
    record("S3 A's claim is SUPERSEDED; A's finalize never ran", claims.rows[0].status === "SUPERSEDED" && !A.trace.events.includes("finalize"));
  }

  console.log("\n[S3b] CONCURRENCY RACE FIX: Lease superseded BETWEEN assert and attest (atomic DB verification closes race window)");
  {
    const emp = "FNC-RACE-BETWEEN";
    let releaseOld; const gateOld = new Promise(r => (releaseOld = r));
    let aLease = null;
    let oldAssertRan = false;

    // Request A runs assertUploadLease successfully, then pauses right before attestNewPhoto
    const A = makeDeps({
      async beforeAssert() {
        aLease = await leaseOfLatest();
      },
      async beforeAttest() {
        oldAssertRan = true;
        await gateOld;
      }
    });

    const pA = run(req(emp), A.deps);

    // Wait until Request A has completed assert and is paused between assert and attest
    for (let i = 0; i < 100 && !oldAssertRan; i++) await new Promise(r => setTimeout(r, 20));
    assert.equal(oldAssertRan, true, "Request A must have executed assertUploadLease");

    // While Request A is paused between assert and attest, Request A's lease expires
    await age(aLease);

    // Request B (the newer request) arrives for the same employee
    const B = makeDeps();
    const rB = await run(req(emp), B.deps); // Request B claims, uploads, attests, and finalizes

    record("S3b newer request B succeeds (201)", rB.status === 201, `status=${rB.status}`);

    // Now release Request A to attempt atomic attestation with superseded lease
    releaseOld();
    const rA = await pA;

    record("S3b old request A is rejected with 409 (UPLOAD_SUPERSEDED)", rA.status === 409 && rA.body.code === "UPLOAD_SUPERSEDED", `status=${rA.status} code=${rA.body?.code}`);

    const attested = await attestedFor(emp);
    const bPhoto = B.trace.uploaded[0];
    const aPhoto = A.trace.uploaded[0];

    record("S3b old request A did NOT attest photo (only B's photo in private.new_employee_photo_attestations)",
      attested.length === 1 && attested[0] === bPhoto && !attested.includes(aPhoto),
      `attested count=${attested.length}`);

    const storedObjects = await objectsFor(emp);
    record("S3b old request A did NOT delete new request B's photo (B's photo intact in Storage)",
      storedObjects.includes(bPhoto),
      `stored count=${storedObjects.length}`);

    record("S3b old request A cleaned up its own rejected unattested photo",
      !storedObjects.includes(aPhoto) && A.trace.removed.includes(aPhoto));

    const aClaim = (await owner.query(`SELECT status FROM private.new_photo_upload_claims WHERE lease_id=$1`, [aLease])).rows[0];
    record("S3b old lease A status in DB is SUPERSEDED", aClaim.status === "SUPERSEDED");
  }

  console.log("\n[S4] Lease superseded AFTER attest (race inside the last window): attested photo is KEPT, answer is 409");
  {
    const emp = "FNC-LATE"; let release; const gate = new Promise(r => (release = r)); let reached; const reachedP = new Promise(r => (reached = r));
    let aLease = null;
    const A = makeDeps({ async afterAttest() { aLease = await leaseOfLatest(); reached(); await gate; } });
    const pA = run(req(emp), A.deps);
    await reachedP;
    await age(aLease);
    const B = makeDeps();
    const rB = await run(req(emp), B.deps);
    release();
    const rA = await pA;
    record("S4 B succeeds (201)", rB.status === 201, `status=${rB.status}`);
    record("S4 A returns 409 (not 201)", rA.status === 409, `status=${rA.status}`);
    record("S4 A's attested photo is NOT deleted", A.trace.removed.length === 0 && (await objectsFor(emp)).includes(A.trace.uploaded[0]));
    record("S4 B's photo untouched", (await objectsFor(emp)).includes(B.trace.uploaded[0]) && (await attestedFor(emp)).includes(B.trace.uploaded[0]));
  }

  console.log("\n[S5] Old ticket cannot release/finalize a newer lock");
  {
    const emp = "FNC-OLDREL"; const a = await rpc("claim_new_photo_upload_quota", [emp, "src:x1"]);
    await age(a.lease_id);
    const b = await rpc("claim_new_photo_upload_quota", [emp, "src:x1"]);
    const rel = await rpc("release_new_photo_upload_quota", [a.lease_id]);
    const fin = await rpc("finalize_new_photo_upload_quota", [a.lease_id]);
    const asr = await rpc("assert_new_photo_upload_lease", [a.lease_id]);
    const bRow = (await owner.query(`SELECT status FROM private.new_photo_upload_claims WHERE lease_id=$1`, [b.lease_id])).rows[0];
    record("S5 newer claim granted after the old one aged out", a.allowed === true && b.allowed === true);
    record("S5 old lease: release/finalize/assert all refused", rel.allowed !== true && fin.ok === false && asr.ok === false, `${rel.reason}/${fin.reason}/${asr.reason}`);
    record("S5 newer lease still CLAIMED (not released/finalized by old ticket)", bRow.status === "CLAIMED");
  }

  console.log("\n[S6] Finalize failure/timeout never produces 201 (real DB state checked)");
  {
    const emp1 = "FNC-FINFAIL"; const A = makeDeps({ finalize: async () => { throw new Error("PostgREST request timed out after 8000ms"); } });
    const rA = await run(req(emp1), A.deps);
    const st = (await owner.query(`SELECT status FROM private.new_photo_upload_claims ORDER BY created_at DESC LIMIT 1`)).rows[0].status;
    record("S6a finalize timeout -> 503, never 201", rA.status === 503 && rA.body.ok === false, `status=${rA.status} ${rA.body.code}`);
    record("S6a attested photo kept; claim not FINALIZED", A.trace.removed.length === 0 && st !== "FINALIZED" && (await objectsFor(emp1)).length === 1, `claim=${st}`);
    const emp2 = "FNC-FINLATE";   // DB commits but the response is lost -> retry sees already_finalized -> ok
    let n = 0; const B = makeDeps({ finalize: async (l, real) => { const r = await real(); if (++n === 1) throw new Error("socket hang up after commit"); return r; } });
    const rB = await run(req(emp2), B.deps);
    record("S6b commit-then-lost-response is recovered by the idempotent retry -> 201", rB.status === 201 && n === 2, `status=${rB.status}, finalizeCalls=${n}`);
    const emp3 = "FNC-FINBAD"; const C = makeDeps({ finalize: async () => ({ ok: false, reason: "LEASE_NOT_FOUND" }) });
    const rC = await run(req(emp3), C.deps);
    record("S6c finalize ok:false -> 503, never 201", rC.status === 503, `status=${rC.status}`);
  }

  console.log("\n[S7] Strict Bypass Closure: Legacy 2-argument attest without lease is rejected");
  {
    const emp = "FNC-BYPASS-TEST";
    const photoPath = `registrations/${emp}/11111111-2222-4333-8444-555555555555.jpg`;
    // Attempting to call legacy 2-argument attest_new_employee_photo without lease_id
    const r = await rpc("attest_new_employee_photo", [emp, photoPath]);
    record("S7 legacy 2-arg attest rejected with LEASE_REQUIRED", r?.ok === false && r?.reason === "LEASE_REQUIRED", `reason=${r?.reason}`);
    const attested = await attestedFor(emp);
    record("S7 no attestation created without lease in DB", attested.length === 0, `attested count=${attested.length}`);
  }

  const failed = log.filter(l => !l.ok).length;
  console.log(`\nPG17 FENCING INTEGRATION: ${log.length - failed}/${log.length} PASS`);
  await pool.end(); await owner.end();
  if (failed) process.exit(1);
})().catch(async (err) => { console.error("TEST EXECUTION FAILED:", err); try { await pool?.end(); await owner?.end(); } catch {} process.exit(1); });
