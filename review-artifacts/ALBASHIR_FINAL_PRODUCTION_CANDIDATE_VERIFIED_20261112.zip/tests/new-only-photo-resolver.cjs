"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path");
(async()=>{
  const root=path.resolve(__dirname,"..");
  const {handleNewPhotoRequest,folderFor}=await import("file://"+path.join(root,"supabase/functions/employee-photo-url-new/handler.mjs"));
  const origin="https://albashir-staging.vercel.app";
  const id="1234567",jpg="registrations/1234567/aabbccdd-1234-4234-a234-123456789abc.jpg";
  const input=(type,actor,path=jpg,employeeId=id,site=origin)=>({
    method:"POST",headers:{origin:site},body:{action:"resolve",path,employee_id:employeeId,actor:{type,...actor}}
  });
  let hits={quota:0,global:0,credentials:0,admin:0,device:0,guard:0,guardSession:0,binding:0,sign:0};
  const deps={allowedOrigins:origin,
    async admitRequest(){hits.quota++;return true;},
    async admitAuthenticatedRequest(){hits.global++;return true;},
    async verifyEmployeeCredentials(e,m){hits.credentials++;return {ok:e===id&&m==="0000000000",employeeId:e,photoPath:jpg};},
    async verifyTrustedDevice(t,d){hits.device++;return {ok:t==="valid-token"&&d==="device-id",employeeId:id};},
    async verifyAdmin(t){hits.admin++;return {ok:t==="valid-admin-jwt",role:"SUPER_ADMIN"};},
    async verifyGateDevice(code,t){hits.guard++;return {ok:code==="approved-gate"&&t==="guard-token"};},
    async verifyAllowedGuardSession(key,e,p){hits.guardSession++;return key==="a".repeat(64)&&e===id&&p===jpg;},
    async verifyNewPhotoBinding(e,p){hits.binding++;return e===id&&p===jpg;},
    async createSignedUrl(){hits.sign++;return {ok:true,url:"https://staging.example/storage/v1/object/sign/employee-photos/qa.jpg?token=synthetic"};}
  };
  const okCases=[
    input("employee",{employee_id:id,mobile_number:"0000000000"}),
    input("employee_device",{device_id:"device-id",device_token:"valid-token"}),
    input("admin",{access_token:"valid-admin-jwt"}),
    input("guard_device",{device_code:"approved-gate",device_token:"guard-token",read_key:"a".repeat(64)}),
    input("public_guard_session",{read_key:"a".repeat(64)})
  ];
  for(const c of okCases){
    const result=await handleNewPhotoRequest(c,deps);
    assert.equal(result.status,200,"Expected authorized new-only "+c.body.actor.type);
    assert.equal(result.body.expires_in,60);
  }
  assert.equal(hits.sign,5);
  assert.equal(hits.global,5,"Only verified callers should consume signed-URL global quota");
  // Mock a DENIED QR decision: even a genuine guard token MUST NOT
  // sign a photo without an explicitly ALLOWED QR/read-key binding.
  const deniedQr=await handleNewPhotoRequest(
    input("public_guard_session",{read_key:"b".repeat(64)}),
    {...deps,async verifyAllowedGuardSession(){return false;}});
  assert.equal(deniedQr.status,403);
  const deniedGuard=await handleNewPhotoRequest(
    input("guard_device",{device_code:"approved-gate",device_token:"guard-token",read_key:"b".repeat(64)}),
    {...deps,async verifyAllowedGuardSession(){return false;}});
  assert.equal(deniedGuard.status,403);
  const noReadKey=await handleNewPhotoRequest(
    input("guard_device",{device_code:"approved-gate",device_token:"guard-token"}),deps);
  assert.equal(noReadKey.status,403);
  const wrongAdminRole=await handleNewPhotoRequest(
    input("admin",{access_token:"valid-admin-jwt"}),
    {...deps,async verifyAdmin(){return {ok:true,role:"EMPLOYEE"};}});
  assert.equal(wrongAdminRole.status,403);
  assert.equal(hits.global,5,"Denied QR/guard/non-admin requests cannot use global signed URL budget");

  // Malformed actor claims must not consume quota or reach any verifier.
  const quotaBeforeMalformed=hits.quota,signBeforeMalformed=hits.sign;
  assert.equal((await handleNewPhotoRequest(input("unknown",{employee_id:id}),deps)).status,403);
  assert.equal((await handleNewPhotoRequest(input("public_guard_session",{read_key:"bad"}),deps)).status,403);
  assert.equal((await handleNewPhotoRequest(input("admin",{}),deps)).status,403);
  assert.equal(hits.quota,quotaBeforeMalformed);
  assert.equal(hits.sign,signBeforeMalformed);
  const deniedCases=[
    input("employee",{employee_id:id,mobile_number:"wrong"}),
    input("employee_device",{device_id:"device-id",device_token:"invalid"}),
    input("admin",{access_token:"fake"}),
    input("guard_device",{device_code:"approved-gate",device_token:"wrong",read_key:"a".repeat(64)}),
    input("public_guard_session",{read_key:"b".repeat(64)}),
    input("public_guard_session",{read_key:"malformed"}),
    input("admin",{access_token:"valid-admin-jwt"},"registrations/1234567/other.jpg"),
    input("guard_device",{device_code:"approved-gate",device_token:"guard-token",read_key:"a".repeat(64)},jpg,"WRONG-ID"),
    input("employee",{employee_id:id,mobile_number:"0000000000"},jpg,id,"https://albashir-stone-karag.vercel.app"),
    input("unknown",{employee_id:id})
  ];
  for(const c of deniedCases){
    const result=await handleNewPhotoRequest(c,deps);
    assert.equal(result.status,403,"Must deny "+c.body.actor.type+" / "+c.body.path);
    assert.equal(result.body.url,undefined);
  }
  assert.equal(hits.global,5,"Invalid credentials must never exhaust the global quota");
  const signCount=hits.sign;
  const noBinding=await handleNewPhotoRequest(okCases[3],{...deps,async verifyNewPhotoBinding(){return false;}});
  assert.equal(noBinding.status,403);assert.equal(hits.sign,signCount);
  // No quota means fail-closed BEFORE login/auth/URL signing.
  let touched=0;
  const deniedQuota=await handleNewPhotoRequest(okCases[2],{...deps,
    async admitRequest(){return false;},
    async verifyAdmin(){touched++;return {ok:true,role:"SUPER_ADMIN"};},
    async verifyNewPhotoBinding(){touched++;return true;},
    async createSignedUrl(){touched++;return {ok:true,url:"https://fake.invalid"};}
  });
  assert.equal(deniedQuota.status,429);assert.equal(touched,0);
  // A signed-URL quota rejection occurs after valid auth + SQL binding but
  // before private Storage signing. Failed credentials never hit this gate.
  let postAuthVerify=0,postAuthSigned=0;
  const globalDenied=await handleNewPhotoRequest(okCases[2],{...deps,
    async verifyAdmin(){postAuthVerify++;return {ok:true,role:"SUPER_ADMIN"};},
    async admitAuthenticatedRequest(){return false;},
    async createSignedUrl(){postAuthSigned++;return {ok:true,url:"https://invalid.example/"};}
  });
  assert.equal(globalDenied.status,429);
  assert.equal(postAuthVerify,1);assert.equal(postAuthSigned,0);
  const globalUnavailable=await handleNewPhotoRequest(okCases[2],{...deps,
    async admitAuthenticatedRequest(){throw Error("DB unavailable");}
  });
  assert.equal(globalUnavailable.status,503,"Global quota outage must fail closed");
  const failQuota=await handleNewPhotoRequest(okCases[1],{...deps,async admitRequest(){throw new Error("database down");}});
  assert.equal(failQuota.status,503);
  const oddId="QA/NEW-123",hash=await folderFor(oddId);
  assert.match(hash,/^[0-9a-f]{64}$/);
  const oddPath="registrations/"+hash+"/aabbccdd-1234-4234-a234-123456789abc.jpg";
  const oddInput=input("employee",{employee_id:oddId,mobile_number:"0000000000"},oddPath,oddId);
  const odd=await handleNewPhotoRequest(oddInput,{...deps,
    async verifyEmployeeCredentials(){return {ok:true,employeeId:oddId,photoPath:oddPath};},
    async verifyNewPhotoBinding(){return true;}
  });
  assert.equal(odd.status,200,"New nonstandard ID hash folder failed");
  // A valid admin/guard must not be allowed to use the old image pathway
  // through the new endpoint. Only the SQL new-registration attestation permits.
  const legacy=await handleNewPhotoRequest(okCases[2],{...deps,async verifyNewPhotoBinding(){return false;}});
  assert.equal(legacy.status,403);
  // CRITICAL: legacy employee_profile_login logs auth attempts and
  // enforces its own 5-attempt limit. A malicious caller must not use
  // the new-only photo resolver to exhaust historical login budgets.
  // The isolated new-only attestation must reject old/missing users
  // BEFORE *any* legacy credential, admin, guard or QR verification.
  for(const legacyActor of okCases){
    const unsafe=[];
    const legacyIsolated={
      ...deps,
      async verifyNewPhotoBinding(e,p){
        assert.equal(e,id); assert.equal(p,jpg);
        return false; // DB sees old employee or missing post-freeze attestation
      },
      async verifyEmployeeCredentials(){unsafe.push("old_employee_profile_login");throw Error("LEGACY AUTH TOUCH");},
      async verifyTrustedDevice(){unsafe.push("old_device_login");throw Error("LEGACY DEVICE TOUCH");},
      async verifyAdmin(){unsafe.push("admin_auth");throw Error("LEGACY ADMIN TOUCH");},
      async verifyGateDevice(){unsafe.push("old_gate_device");throw Error("LEGACY GUARD TOUCH");},
      async verifyAllowedGuardSession(){unsafe.push("guard_qr");throw Error("QR READ");},
      async admitAuthenticatedRequest(){unsafe.push("global_signed_quota");throw Error("RATE TOUCH");},
      async createSignedUrl(){unsafe.push("private_storage");throw Error("STORAGE TOUCH");}
    };
    const result=await handleNewPhotoRequest(legacyActor,legacyIsolated);
    assert.equal(result.status,403,
      "Old/missing employee must be denied before verifying "+legacyActor.body.actor.type);
    assert.deepEqual(unsafe,[],
      "Old/missing employee touched a shared verifier: "+legacyActor.body.actor.type);
  }
  // An unavailable new-only binding must fail closed, never fall back
  // to legacy authentication or leak a private signed URL.
  let legacyAuthTouch=0;
  const bindingOffline=await handleNewPhotoRequest(okCases[0],{
    ...deps,
    async verifyNewPhotoBinding(){throw Error("new-only SQL missing");},
    async verifyEmployeeCredentials(){legacyAuthTouch++;return {ok:true};}
  });
  assert.equal(bindingOffline.status,503);
  assert.equal(legacyAuthTouch,0);
  
  // Admin JWT in Authorization header must be accepted without duplicating
  // the token into JSON; the preflight and auth parser must agree.
  const headerAdmin={...input("admin",{}),
    headers:{origin,authorization:"Bearer valid-admin-jwt"}};
  assert.equal((await handleNewPhotoRequest(headerAdmin,deps)).status,200,
    "Header-only admin token rejected by preflight");
  const invalidHeader={...headerAdmin,
    headers:{origin,authorization:"Bearer invalid-admin-jwt"}};
  assert.equal((await handleNewPhotoRequest(invalidHeader,deps)).status,403);
  assert.equal((await handleNewPhotoRequest({method:"OPTIONS",headers:{origin}},deps)).status,204);
  const sql=fs.readFileSync(path.join(root,"supabase/review/NEW_ONLY_PHOTO_BINDING_REVIEW_LOCKED.sql"),"utf8");
  assert(sql.includes("RAISE EXCEPTION 'REVIEW ONLY: new employee photo binding is disabled'"));
  assert(sql.includes("r.created_at>c.freeze_at"));
  assert(sql.includes("a.object_path=r.employee_photo_url"));
  const staging=fs.readFileSync(path.join(root,"supabase/review/STAGING_QA_NEW_ONLY_PHOTO_ROLLBACK.sql"),"utf8");
  assert(staging.includes("ROLLBACK;")&&staging.includes("QA-PR58!STAGING"));
  const rateSql=fs.readFileSync(path.join(root,"supabase/review/NEW_ONLY_PHOTO_RATE_LIMIT_REVIEW_LOCKED.sql"),"utf8");
  assert(rateSql.includes("RAISE EXCEPTION 'REVIEW ONLY: never deploy new-photo rate limiter"));
  assert(rateSql.includes("new_employee_photo_signed_url_admit"));
  assert(rateSql.includes("('global',v_now,1,v_now)"));
  const preauthFn=rateSql.split("CREATE OR REPLACE FUNCTION public.new_employee_photo_view_admit(")[1].split("CREATE OR REPLACE FUNCTION public.new_employee_photo_signed_url_admit(")[0];
  assert(!preauthFn.includes("'global'"),"Pre-auth function must not consume global signed-URL quota");
  const rateTest=fs.readFileSync(path.join(root,"supabase/review/STAGING_QA_NEW_PHOTO_RATE_LIMIT_ROLLBACK.sql"),"utf8");
  assert(rateTest.includes("aggregate_limit_denied")&&rateTest.includes("ROLLBACK;"));
  const irregular=fs.readFileSync(path.join(root,"supabase/review/STAGING_QA_NEW_NONSTANDARD_PHOTO_ROLLBACK.sql"),"utf8");
  assert(irregular.includes("new_nonstandard_id_authorized")&&irregular.includes("ROLLBACK;"));
  assert(!/sweepAction|removeObjects|deleteObject/i.test(fs.readFileSync(path.join(root,"supabase/functions/employee-photo-url-new/handler.mjs"),"utf8")));
  const src=fs.readFileSync(path.join(root,"supabase/functions/employee-photo-url-new/index.ts"),"utf8");
  assert(src.includes('get_my_admin_profile')&&src.includes("verify_gate_device_credentials"));
  assert(src.includes("resolve_new_allowed_guard_photo")&&src.includes("verify_trusted_device_credentials"));
  assert(!src.includes('admin.rpc("resolve_public_guard_photo"'),"New-only must not reuse legacy status-agnostic QR resolver");
  assert(src.includes("SUPABASE_ANON_KEY")&&src.includes('admin.rpc("resolve_attested_new_employee_photo"'));
  console.log("PASS 5 new-only photo actors authorized with real credential verifier contracts, ownership+rate gate; old users never routed; all offline");
})().catch(e=>{console.error(e);process.exitCode=1});
