"""
PostgreSQL AST Syntax Verification Suite using pglast (libpg_query).
Validates that all SQL statements parse cleanly with the real PostgreSQL query engine parser.
"""
import pglast
import os
import sys

def verify_file(filepath):
    print(f"Parsing {filepath} with PostgreSQL libpg_query parser...")
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    try:
        tree = pglast.parse_sql(content)
        print(f"  [PASS] Parsed cleanly! Total statements: {len(tree)}")
        return True
    except pglast.parser.ParseError as e:
        print(f"  [FAIL] PostgreSQL ParseError: {e}")
        return False

def main():
    files = [
        'supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql',
        'supabase/review/STAGING_ROLLBACK_PRODUCTION_PARITY_20261111.sql',
        'supabase/review/NEW_ONLY_PHOTO_UPLOAD_QUOTA_REVIEW_LOCKED.sql'
    ]
    all_ok = True
    for f in files:
        if not verify_file(f):
            all_ok = False
            
    if all_ok:
        print("\n=======================================================")
        print("ALL REVIEW SQL FILES VERIFIED BY POSTGRESQL C-PARSER!")
        print("=======================================================")
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()

