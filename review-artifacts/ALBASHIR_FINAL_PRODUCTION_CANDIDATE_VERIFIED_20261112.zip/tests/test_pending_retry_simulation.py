"""
Independent verification test suite for ALBASHIR PENDING Retry & Idempotency fix.
Simulates exact PostgreSQL PL/pgSQL semantics of:
  - public.register_new_employee_request
  - private.register_employee_request_new_core
  - private.legacy_registration_cutoff
  - private.new_employee_photo_attestations
  - public.employee_registrations
"""
import hashlib
import json
import re
import threading
import time
from datetime import datetime, timezone

def hash_trusted_device_token(token: str) -> str:
    """Mirrors public.hash_trusted_device_token(clean_device_token)"""
    return hashlib.sha256(token.encode('utf-8')).hexdigest()

def get_expected_folder(emp_id: str) -> str:
    """Mirrors expected_folder logic in register_new_employee_request"""
    if re.match(r'^[A-Za-z0-9_-]{1,32}$', emp_id):
        return emp_id
    digest = hashlib.sha256(f"employee-photo-folder-v1:{emp_id}".encode('utf-8')).hexdigest()
    return digest

class MockPostgresDatabase:
    def __init__(self):
        self.lock = threading.RLock()
        self.freeze_at = datetime.fromisoformat("2026-10-01T00:00:00+00:00")
        self.legacy_registration_cutoff = {"freeze_at": self.freeze_at}
        
        # Tables
        self.employee_registrations = {} # id -> dict
        self.employee_id_index = {}      # employee_id -> id
        self.next_reg_id = 1
        
        self.pending_employee_uploads = {} # object_path -> {status, employee_id}
        self.new_employee_photo_attestations = {} # object_path -> employee_id
        self.storage_objects = {} # object_path -> {bucket_id, name, metadata}
        self.specialty_daily_limits = {"طبيب": True, "ممرض": True, "طوارئ": True}
        self.gate_access_logs = []

    def seed_historic_employee(self, emp_id, name, phone, status="APPROVED"):
        reg_id = self.next_reg_id
        self.next_reg_id += 1
        row = {
            "id": reg_id,
            "employee_id": emp_id,
            "full_name": name,
            "mobile_number": phone,
            "specialty": "طبيب",
            "job_type": "طبيب",
            "department": "الإسعاف والطوارئ",
            "employee_photo_url": f"registrations/{emp_id}/historic.jpg",
            "registration_category": "PERMANENT",
            "status": status,
            "created_at": datetime.fromisoformat("2026-09-15T00:00:00+00:00"),
            "pending_trusted_device_token_hash": hash_trusted_device_token("historic-token-" + emp_id)
        }
        self.employee_registrations[reg_id] = row
        self.employee_id_index[emp_id] = reg_id
        return row

    def attest_photo(self, emp_id, photo_path):
        self.storage_objects[photo_path] = {"bucket_id": "employee-photos", "name": photo_path, "metadata": {"size": 1024, "mimetype": "image/jpeg"}}
        self.pending_employee_uploads[photo_path] = {"object_path": photo_path, "employee_id": None, "registration_id": None, "status": "PENDING"}
        self.new_employee_photo_attestations[photo_path] = emp_id

    def register_new_employee_request(self, full_name, employee_id, mobile_number, specialty, qr_token,
                                      job_type, department, photo_url, device_token, device_id,
                                      device_type, device_name, user_agent, registration_category, affiliated_entity):
        clean_emp = str(employee_id or '').strip()
        clean_photo = str(photo_url or '').strip()
        
        # Validation checks from public.register_new_employee_request
        if not clean_emp or len(clean_emp) > 32 or re.search(r'[\x00-\x1f\x7f]', clean_emp):
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        if not re.match(r'^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$', clean_photo):
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        
        folder = clean_photo.split('/')[1]
        expected_folder = get_expected_folder(clean_emp)
        if folder != expected_folder:
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        
        # Storage and pending upload checks
        up = self.pending_employee_uploads.get(clean_photo)
        if up is None or clean_photo not in self.storage_objects:
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        with self.lock:
            rows = list(self.employee_registrations.values())
        if up["status"] == "PENDING":
            ok = not any(x["employee_photo_url"] == clean_photo and x["employee_id"] != clean_emp for x in rows)
        elif up["status"] == "LINKED":
            ok = up.get("employee_id") == clean_emp and any(r["id"] == up.get("registration_id") and r["employee_id"] == clean_emp and r["employee_photo_url"] == clean_photo and r["status"] == "PENDING" for r in rows)
        else:
            ok = False
        if not ok:
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        
        # Attestation check
        if clean_photo not in self.new_employee_photo_attestations or self.new_employee_photo_attestations[clean_photo] != clean_emp:
            return {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        
        # Call core with atomic row lock
        return self.register_employee_request_new_core(
            full_name, employee_id, mobile_number, specialty, None,
            job_type, department, photo_url, device_token, device_id,
            device_type, device_name, user_agent, registration_category, affiliated_entity
        )

    def register_employee_request_new_core(self, full_name, employee_id, mobile_number, specialty, qr_token,
                                           job_type, department, photo_url, device_token, device_id,
                                           device_type, device_name, user_agent, registration_category, affiliated_entity):
        with self.lock:
            clean_name = str(full_name or '').strip()
            clean_emp = str(employee_id or '').strip()
            clean_mobile = str(mobile_number or '').strip()
            clean_specialty_in = str(specialty or '').strip()
            clean_job_in = str(job_type or '').strip() or None
            clean_dept_in = str(department or '').strip() or None
            clean_photo = str(photo_url or '').strip()
            clean_device_token = str(device_token or '').strip()
            clean_category = str(registration_category or '').strip().upper()
            clean_affiliated = str(affiliated_entity or '').strip() or None

            if len(clean_name) > 120 or len(clean_emp) > 32 or len(clean_mobile) > 20:
                return {"ok": False, "result": "DENIED", "message": "تجاوزت البيانات الحد المسموح لطول الحقول"}
            if clean_category not in ('PERMANENT', 'TEMPORARY'):
                return {"ok": False, "result": "DENIED", "message": "نوع التسجيل غير صالح. اختر موظف دائم أو موظف مؤقت / خارجي"}
            if not clean_name or not clean_emp or not clean_mobile:
                return {"ok": False, "result": "DENIED", "message": "الرجاء تعبئة الاسم ورقم الموظف/الوطني ورقم الهاتف"}
            if not clean_photo or not clean_photo.startswith('registrations/'):
                return {"ok": False, "result": "DENIED", "message": "الصورة الشخصية مطلوبة"}

            if clean_category == 'PERMANENT':
                if not clean_job_in or not clean_dept_in:
                    return {"ok": False, "result": "DENIED", "message": "الوظيفة والقسم مطلوبان للموظف الدائم"}
                effective_specialty = clean_dept_in
                store_job_type = clean_job_in
                store_department = clean_dept_in
                store_affiliated = None
            else:
                if not clean_specialty_in or not clean_affiliated:
                    return {"ok": False, "result": "DENIED", "message": "الاختصاص والجهة التابعة مطلوبان للموظف المؤقت / الخارجي"}
                effective_specialty = clean_specialty_in
                store_job_type = clean_job_in
                store_department = None
                store_affiliated = clean_affiliated

            pass  # (lock released below; the algorithm re-acquires per statement like Postgres)

        return self._core_body(clean_name, clean_emp, clean_mobile, clean_photo, clean_device_token, clean_category,
                               effective_specialty, store_job_type, store_department, store_affiliated,
                               device_id, device_type, device_name, user_agent)

    def _read_row(self, emp):
        with self.lock:
            rid = self.employee_id_index.get(emp)
            return self.employee_registrations.get(rid) if rid else None

    def _insert_on_conflict_do_nothing(self, row):
        with self.lock:  # models the UNIQUE(employee_id) index
            if row["employee_id"] in self.employee_id_index:
                return None
            row["id"] = self.next_reg_id
            self.next_reg_id += 1
            self.employee_registrations[row["id"]] = row
            self.employee_id_index[row["employee_id"]] = row["id"]
            up = self.pending_employee_uploads.get(row["employee_photo_url"])
            if up is not None:   # models trg_link_pending_employee_upload
                up.update(status="LINKED", employee_id=row["employee_id"], registration_id=row["id"])
            return row

    def _core_body(self, clean_name, clean_emp, clean_mobile, clean_photo, clean_device_token, clean_category,
                   effective_specialty, store_job_type, store_department, store_affiliated,
                   device_id, device_type, device_name, user_agent):
        DENY = {"ok": False, "result": "DENIED", "message": "تعذر إكمال طلب التسجيل الجديد."}
        if len(clean_device_token) < 40:
            return {"ok": False, "result": "DENIED", "message": "تعذر التحقق من إثبات ملكية الطلب. أعد المحاولة من الجهاز نفسه"}
        reg = self._read_row(clean_emp)           # SELECT ... FOR UPDATE (cannot lock a missing row)
        if reg is None:
            time.sleep(0.02)                      # widen the check-then-insert race window
            token_hash = hash_trusted_device_token(clean_device_token) if len(clean_device_token) >= 40 else None
            now = datetime.now(timezone.utc)
            new_row = {
                "full_name": clean_name, "employee_id": clean_emp, "mobile_number": clean_mobile,
                "specialty": effective_specialty, "job_type": store_job_type, "department": store_department,
                "employee_photo_url": clean_photo, "registration_category": clean_category,
                "affiliated_entity": store_affiliated, "status": "PENDING", "first_entry_used": False,
                "first_entry_at": None, "pending_trusted_device_token_hash": token_hash,
                "pending_trusted_device_id": device_id or None, "pending_trusted_device_type": device_type or None,
                "pending_trusted_device_name": device_name or None, "pending_trusted_device_user_agent": user_agent or None,
                "pending_trusted_device_created_at": now if token_hash else None, "created_at": now,
            }
            if self._insert_on_conflict_do_nothing(new_row) is not None:
                return {"ok": True, "result": "PENDING", "message": "تم إرسال طلبك، الرجاء انتظار موافقة الإدارة"}
            reg = self._read_row(clean_emp)       # lost the race: re-read committed winner
            if reg is None:
                return DENY
        with self.lock:
            if reg["created_at"] <= self.freeze_at:
                return {"ok": False, "result": "DENIED", "message": "هذا المسار للموظفين الجدد فقط. الموظفون المسجلون سابقاً يمكنهم تسجيل الدخول مباشرة."}
            if reg["status"] == "APPROVED":
                return {"ok": False, "result": "DENIED", "message": "تم اعتماد هذا الحساب مسبقاً. يُرجى تسجيل الدخول مباشرة."}
            if reg["status"] == "REJECTED":
                self.gate_access_logs.append({"employee_id": clean_emp, "result": "DENIED", "reason": "REJECTED_EMPLOYEE"})
                return {"ok": True, "result": "DENIED", "message": "تم رفض الطلب، يرجى مراجعة الإدارة"}
            if reg["status"] == "PENDING":
                token_hash = hash_trusted_device_token(clean_device_token) if len(clean_device_token) >= 40 else None
                if token_hash is None or reg.get("pending_trusted_device_token_hash") is None or reg["pending_trusted_device_token_hash"] != token_hash:
                    return {"ok": False, "result": "DENIED", "message": "تعذر التحقق من ملكية الطلب المعلق. استخدم الجهاز الذي أرسل الطلب أو راجع الإدارة"}
                if reg["employee_photo_url"] != clean_photo:
                    return {"ok": False, "result": "DENIED", "message": "تعذر تغيير صورة الطلب المعلق. راجع الإدارة."}
                if (reg["mobile_number"] == clean_mobile and (reg.get("full_name") or '') == clean_name and
                    (reg.get("specialty") or '') == effective_specialty and
                    (reg.get("registration_category") or '') == clean_category and
                    (reg.get("department") or '') == (store_department or '') and
                    (reg.get("job_type") or '') == (store_job_type or '') and
                    (reg.get("affiliated_entity") or '') == (store_affiliated or '')):
                    return {"ok": True, "result": "PENDING", "message": "تم إرسال طلبك مسبقاً، والطلب قيد مراجعة الإدارة."}
                reg.update(full_name=clean_name, mobile_number=clean_mobile, specialty=effective_specialty,
                           job_type=store_job_type, department=store_department,
                           registration_category=clean_category, affiliated_entity=store_affiliated)
                return {"ok": True, "result": "PENDING", "message": "تم تحديث طلبك بنجاح، والطلب قيد مراجعة الإدارة."}
            return DENY

def run_tests():
    db = MockPostgresDatabase()
    token_a = "a" * 96
    token_b = "b" * 96
    
    # Setup historic employees
    db.seed_historic_employee("HIST-001", "د. أحمد القديم", "0790000001", status="APPROVED")
    db.seed_historic_employee("HIST-002", "ممرض قديم", "0790000002", status="PENDING")
    
    # 1. Test First-Time Registration
    emp_id = "QA-NEW-101"
    photo_path = f"registrations/{emp_id}/aa123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(emp_id, photo_path)
    
    r1 = db.register_new_employee_request(
        "موظف جديد أول مرة", emp_id, "0791111111", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_a, "device-1",
        "iOS", "iPhone 14", "Safari", "PERMANENT", None
    )
    assert r1["ok"] is True, f"First registration failed: {r1}"
    assert r1["result"] == "PENDING"
    assert len(db.employee_registrations) == 3 # 2 historic + 1 new
    print("[PASS] Test 1: First-Time Registration creates 1 PENDING row")

    # 2. Test Timeout / Network Drop Retry with identical payload & token
    r2 = db.register_new_employee_request(
        "موظف جديد أول مرة", emp_id, "0791111111", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_a, "device-1",
        "iOS", "iPhone 14", "Safari", "PERMANENT", None
    )
    assert r2["ok"] is True, f"Idempotent retry failed: {r2}"
    assert r2["result"] == "PENDING"
    assert "تم إرسال طلبك مسبقاً" in r2["message"]
    assert len(db.employee_registrations) == 3, "Duplicate row created on retry!"
    print("[PASS] Test 2: Idempotent Retry succeeded with 0 duplicate rows")

    # 3. Test Device Token Hijacking Attempt (Different token)
    r3 = db.register_new_employee_request(
        "مهاجم ينتحل الهوية", emp_id, "0799999999", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_b, "device-attacker",
        "Android", "Pixel", "Chrome", "PERMANENT", None
    )
    assert r3["ok"] is False, f"Hijacking was not denied: {r3}"
    assert r3["result"] == "DENIED"
    assert "تعذر التحقق من ملكية الطلب المعلق" in r3["message"]
    # Check original row was NOT modified
    reg = db.employee_registrations[db.employee_id_index[emp_id]]
    assert reg["full_name"] == "موظف جديد أول مرة"
    assert reg["mobile_number"] == "0791111111"
    print("[PASS] Test 3: Hijacking with wrong device token denied, data preserved")

    # 4. Test Hijacking Attempt with empty / short token
    r4 = db.register_new_employee_request(
        "مهاجم بدون توكن", emp_id, "0798888888", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, "", "",
        "", "", "", "PERMANENT", None
    )
    assert r4["ok"] is False
    assert r4["result"] == "DENIED"
    print("[PASS] Test 4: Hijacking with empty device token denied")

    # 5. Test Legitimate Update with authentic token
    r5 = db.register_new_employee_request(
        "موظف جديد تم تحديث اسمه", emp_id, "0792222222", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_a, "device-1",
        "iOS", "iPhone 14", "Safari", "PERMANENT", None
    )
    assert r5["ok"] is True
    assert r5["result"] == "PENDING"
    assert "تم تحديث طلبك بنجاح" in r5["message"]
    reg = db.employee_registrations[db.employee_id_index[emp_id]]
    assert reg["full_name"] == "موظف جديد تم تحديث اسمه"
    assert reg["mobile_number"] == "0792222222"
    assert len(db.employee_registrations) == 3
    print("[PASS] Test 5: Legitimate PENDING update succeeded with authentic token")

    # 6. Test APPROVED employee trying to re-register
    reg["status"] = "APPROVED"
    r6 = db.register_new_employee_request(
        "موظف معتمد يحاول التسجيل ثانية", emp_id, "0792222222", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_a, "device-1",
        "iOS", "iPhone 14", "Safari", "PERMANENT", None
    )
    assert r6["ok"] is False
    assert r6["result"] == "DENIED"
    # public layer now denies opaquely: LINKED photo only accepted for a PENDING request
    assert reg["status"] == "APPROVED", "Approved status was compromised!"
    print("[PASS] Test 6: Re-registration by APPROVED employee denied, status preserved")

    # 7. Test REJECTED employee trying to re-register
    reg["status"] = "REJECTED"
    r7 = db.register_new_employee_request(
        "موظف مرفوض يحاول التسجيل", emp_id, "0792222222", None, None,
        "طبيب", "الإسعاف والطوارئ", photo_path, token_a, "device-1",
        "iOS", "iPhone 14", "Safari", "PERMANENT", None
    )
    assert r7["result"] == "DENIED"
    assert r7["ok"] is False or "تم رفض الطلب" in r7["message"]
    print("[PASS] Test 7: Re-registration by REJECTED employee denied with proper log")

    # 8. Test Historic Employee trying new registration route
    hist_photo = "registrations/HIST-001/aa123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo("HIST-001", hist_photo)
    r8 = db.register_new_employee_request(
        "د. أحمد القديم", "HIST-001", "0790000001", None, None,
        "طبيب", "الإسعاف والطوارئ", hist_photo, token_a, "device-1",
        "iOS", "iPhone", "Safari", "PERMANENT", None
    )
    assert r8["ok"] is False
    assert r8["result"] == "DENIED"
    print("[PASS] Test 8: Historic employee denied on new route, legacy untouched")

    # 9. Test Non-Standard Employee ID (10-digit National ID & Alphanumeric with special chars)
    nat_id = "9982012345" # 10 digits
    nat_folder = get_expected_folder(nat_id)
    assert nat_folder == nat_id
    nat_photo = f"registrations/{nat_folder}/bb123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(nat_id, nat_photo)
    r9 = db.register_new_employee_request(
        "موظف برقم وطني 10 خانات", nat_id, "0793333333", "طبيب", None,
        None, None, nat_photo, token_a, "device-nat",
        "Android", "Samsung", "Chrome", "TEMPORARY", "مستشفى الجراحة والجراحات التخصصية"
    )
    assert r9["ok"] is True
    assert r9["result"] == "PENDING"
    print("[PASS] Test 9: Non-standard 10-digit national ID accepted in TEMPORARY category")

    # 10. Test Non-alphanumeric ID (requiring SHA-256 folder derivation)
    odd_id = "EMP#2026/01" # has # and /
    odd_folder = get_expected_folder(odd_id)
    assert re.match(r'^[0-9a-f]{64}$', odd_folder)
    odd_photo = f"registrations/{odd_folder}/cc123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(odd_id, odd_photo)
    r10 = db.register_new_employee_request(
        "موظف برقم غير تقليدي", odd_id, "0794444444", None, None,
        "طبيب", "الإسعاف والطوارئ", odd_photo, token_a, "device-odd",
        "Windows", "PC", "Edge", "PERMANENT", None
    )
    assert r10["ok"] is True
    assert r10["result"] == "PENDING"
    print("[PASS] Test 10: Non-alphanumeric ID with SHA-256 folder derivation accepted")

    # 11. Concurrency Simulation (Parallel simultaneous submissions)
    conc_id = "QA-CONC-999"
    conc_photo = f"registrations/{conc_id}/dd123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(conc_id, conc_photo)
    results = []
    def worker(t):
        res = db.register_new_employee_request(
            "موظف متزامن", conc_id, "0795555555", None, None,
            "طبيب", "الإسعاف والطوارئ", conc_photo, t, "device-conc",
            "iOS", "iPhone", "Safari", "PERMANENT", None
        )
        results.append(res)
    
    threads = [
        threading.Thread(target=worker, args=(token_a,)),
        threading.Thread(target=worker, args=(token_a,)),
        threading.Thread(target=worker, args=(token_b,)) # attacker running in parallel
    ]
    for th in threads: th.start()
    for th in threads: th.join()
    
    # Exactly one employee row was inserted
    conc_rows = [r for r in db.employee_registrations.values() if r["employee_id"] == conc_id]
    assert len(conc_rows) == 1, f"Expected 1 row for conc_id, found {len(conc_rows)}"
    # At least one token_a succeeded, token_b was denied
    ok_count = sum(1 for r in results if r.get("ok") is True and r.get("result") == "PENDING")
    denied_count = sum(1 for r in results if r.get("result") == "DENIED")
    assert ok_count >= 1
    assert denied_count >= 1 # attacker token_b must be denied
    print(f"[PASS] Test 11: Concurrency simulation succeeded (1 row created, attacker denied)")

    # ---- Additional scenarios (public-RPC path, LINKED photo, ownership, races) ----
    def reg_new(emp, photo, token, name="موظف", mobile="0796666666"):
        return db.register_new_employee_request(
            name, emp, mobile, None, None, "طبيب", "الإسعاف والطوارئ", photo, token, "dev",
            "iOS", "iPhone", "Safari", "PERMANENT", None)
    token_c = "c" * 96

    # 12. Retry AFTER photo flips PENDING -> LINKED must succeed via the PUBLIC RPC
    lk = "QA-LINK-1"
    lk_photo = f"registrations/{lk}/ee123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(lk, lk_photo)
    assert reg_new(lk, lk_photo, token_a)["ok"] is True
    led = db.pending_employee_uploads[lk_photo]                     # set by simulated trigger, not by the test
    assert led["status"] == "LINKED" and led["employee_id"] == lk and led["registration_id"] == db.employee_id_index[lk]
    snap = dict(db.employee_registrations[db.employee_id_index[lk]])
    n_rows = len(db.employee_registrations)
    r12 = reg_new(lk, lk_photo, token_a)
    assert r12["ok"] is True and r12["result"] == "PENDING", r12
    assert len(db.employee_registrations) == n_rows
    cur = db.employee_registrations[db.employee_id_index[lk]]
    assert cur == snap, "LINKED retry mutated the row"
    print("[PASS] Test 12: pending_retry_success via public RPC with LINKED photo, no mutation, no new row")

    # 13. LINKED photo + foreign / missing proof => DENIED, row untouched
    for tok in (token_b, ""):
        r = reg_new(lk, lk_photo, tok, name="مهاجم")
        assert r["ok"] is False and r["result"] == "DENIED", r
    assert db.employee_registrations[db.employee_id_index[lk]] == snap
    print("[PASS] Test 13: LINKED retry with different/missing device proof denied")

    # 14. Using another employee's photo path is denied
    r14 = reg_new("QA-OTHER-1", lk_photo, token_b)
    assert r14["ok"] is False and "QA-OTHER-1" not in db.employee_id_index
    print("[PASS] Test 14: another employee's photo denied, no row created")

    # 15. PENDING edit: owner OK (stays PENDING, same id/photo/device), foreign DENIED
    rid = db.employee_id_index[lk]
    r15 = reg_new(lk, lk_photo, token_a, name="اسم مصحح", mobile="0797777777")
    assert r15["ok"] is True and "تم تحديث طلبك" in r15["message"], r15
    cur = db.employee_registrations[rid]
    assert cur["status"] == "PENDING" and cur["id"] == snap["id"]
    assert cur["employee_photo_url"] == snap["employee_photo_url"]
    assert cur["pending_trusted_device_token_hash"] == snap["pending_trusted_device_token_hash"]
    assert cur["pending_trusted_device_id"] == snap["pending_trusted_device_id"]
    r15b = reg_new(lk, lk_photo, token_c, name="سارق")
    assert r15b["ok"] is False and db.employee_registrations[rid]["full_name"] == "اسم مصحح"
    print("[PASS] Test 15: owner edit keeps PENDING/id/photo/device; foreign edit denied")

    # 16. Photo change on a PENDING request is refused (needs Argon protocol), nothing replaced
    other_photo = f"registrations/{lk}/ff123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(lk, other_photo)
    r16 = reg_new(lk, other_photo, token_a)
    assert r16["ok"] is False
    assert db.employee_registrations[rid]["employee_photo_url"] == lk_photo
    print("[PASS] Test 16: photo replacement on PENDING request denied, stored photo intact")

    # 17. After approval: retry with owner token and with a new device both DENIED, nothing changes
    db.employee_registrations[rid]["status"] = "APPROVED"
    before = dict(db.employee_registrations[rid])
    for tok in (token_a, token_b):
        r = reg_new(lk, lk_photo, tok)
        assert r["ok"] is False and r["result"] == "DENIED", r
    assert db.employee_registrations[rid] == before
    print("[PASS] Test 17: APPROVED employee cannot re-register or replace trusted device")

    # 18. Stronger race: 6 threads (4 same-proof, 2 foreign-proof), repeated rounds
    for rnd in range(5):
        cid = f"QA-RACE-{rnd}"
        cph = f"registrations/{cid}/ab123456-78ab-41cd-91ab-123456789abc.jpg"
        db.attest_photo(cid, cph)
        res = []
        def w(tok):
            res.append((tok, reg_new(cid, cph, tok)))
        ths = [threading.Thread(target=w, args=(t,)) for t in
               (token_a, token_a, token_a, token_a, token_b, token_c)]
        for th in ths: th.start()
        for th in ths: th.join()
        rows = [r for r in db.employee_registrations.values() if r["employee_id"] == cid]
        assert len(rows) == 1, f"duplicate rows in race round {rnd}"
        winner_hash = rows[0]["pending_trusted_device_token_hash"]
        assert winner_hash in (hash_trusted_device_token(token_a), hash_trusted_device_token(token_b), hash_trusted_device_token(token_c))
        created = [r for t, r in res if r.get("ok") and "الرجاء انتظار موافقة" in r.get("message", "")]
        assert len(created) == 1, "conflict reported as false creation success"
        for t, r in res:   # only the proof that won may succeed; all others DENIED
            if hash_trusted_device_token(t) != winner_hash:
                assert r["ok"] is False and r["result"] == "DENIED", r
            else:
                assert r["ok"] is True and r["result"] == "PENDING", r
    print("[PASS] Test 18: 5 race rounds x 6 threads: 1 row, 1 creation, losers denied/idempotent")

    # 19. LINKED ledger bound to ANOTHER registration => DENIED (registration_id tightening)
    c1, c2 = "QA-BIND-1", "QA-BIND-2"
    p1 = f"registrations/{c1}/a1123456-78ab-41cd-91ab-123456789abc.jpg"
    p2 = f"registrations/{c2}/a2123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(c1, p1); db.attest_photo(c2, p2)
    assert reg_new(c1, p1, token_a)["ok"] and reg_new(c2, p2, token_b)["ok"]
    assert reg_new(c1, p1, token_a)["ok"] is True
    good = db.pending_employee_uploads[p1]["registration_id"]
    db.pending_employee_uploads[p1]["registration_id"] = db.employee_id_index[c2]   # forced mismatch
    r19 = reg_new(c1, p1, token_a)
    assert r19["ok"] is False and r19["result"] == "DENIED", r19
    db.pending_employee_uploads[p1]["registration_id"] = good
    print("[PASS] Test 19: LINKED photo bound to another registration denied")

    # 20. Creation without valid ownership proof is denied and creates no row
    nid = "QA-NOPROOF-1"
    npth = f"registrations/{nid}/a3123456-78ab-41cd-91ab-123456789abc.jpg"
    db.attest_photo(nid, npth)
    for tok in ("", "short"):
        r20 = reg_new(nid, npth, tok)
        assert r20["ok"] is False and nid not in db.employee_id_index, r20
    assert db.pending_employee_uploads[npth]["status"] == "PENDING"
    assert reg_new(nid, npth, token_a)["ok"] is True      # with proof it works, and is retryable
    assert reg_new(nid, npth, token_a)["ok"] is True
    print("[PASS] Test 20: proof-less creation denied; created request is always retryable")

    print("\n=======================================================")
    print("ALL 20 SIMULATION & REGRESSION TESTS PASSED PERFECTLY!")
    print("=======================================================")

if __name__ == "__main__":
    run_tests()

