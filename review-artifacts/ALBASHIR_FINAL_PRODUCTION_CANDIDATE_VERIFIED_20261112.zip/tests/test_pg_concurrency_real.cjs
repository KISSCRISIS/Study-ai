/**
 * test_pg_concurrency_real.cjs
 * Real PostgreSQL (PGlite 18.3) Multi-Session Concurrency & Race Stress Test
 * 
 * Verifies:
 *  - 20 rounds x 8 concurrent sessions executing public.register_new_employee_request simultaneously
 *  - EXACTLY 1 row created per employee
 *  - Photo upload ledger atomically flipped to LINKED
 *  - Creation winner gets creation response
 *  - Concurrent sessions sharing the winning token succeed idempotently (ok: true, result: 'PENDING')
 *  - Concurrent sessions with foreign tokens are strictly rejected (ok: false, result: 'DENIED')
 *  - Zero unhandled SQL exceptions or orphaned locks
 *  - Concurrent photo quota claim stress: 10 concurrent requests with max=3 yields exactly 3 allowed, 7 rejected
 */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { PGlite } = require("@electric-sql/pglite");
const { pgcrypto } = require("@electric-sql/pglite/contrib/pgcrypto");

const root = path.resolve(__dirname, "..");
const baselineSql = fs.readFileSync(path.join(root, "schema_consolidated_fresh_install.sql"), "utf8");
const photoMigrationSql = fs.readFileSync(path.join(root, "supabase/migrations/20261006190000_private_employee_photos.sql"), "utf8");
const backendReviewSql = fs.readFileSync(path.join(root, "supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql"), "utf8");
const quotaReviewSql = fs.readFileSync(path.join(root, "supabase/review/NEW_ONLY_PHOTO_UPLOAD_QUOTA_REVIEW_LOCKED.sql"), "utf8");

function stripLocks(sql) {
  return sql.replace(/DO\s+\$[^$]+\$[\s\S]*?\$[^$]+\$;/g, "-- lock removed for test execution");
}

async function setupDatabase() {
  const db = new PGlite({ extensions: { pgcrypto } });

  await db.exec(`
    CREATE ROLE anon;
    CREATE ROLE authenticated;
    CREATE ROLE service_role BYPASSRLS;

    CREATE SCHEMA extensions;
    CREATE EXTENSION pgcrypto WITH SCHEMA extensions;

    CREATE SCHEMA auth;
    CREATE TABLE auth.users (id uuid PRIMARY KEY, email text);
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
      SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
    $$;

    CREATE SCHEMA storage;
    CREATE TABLE storage.buckets (
      id text PRIMARY KEY,
      name text NOT NULL,
      public boolean DEFAULT false,
      file_size_limit bigint DEFAULT null,
      allowed_mime_types text[] DEFAULT null,
      created_at timestamptz DEFAULT now()
    );
    CREATE TABLE storage.objects (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      bucket_id text NOT NULL,
      name text NOT NULL,
      metadata jsonb,
      created_at timestamptz DEFAULT now(),
      UNIQUE (bucket_id, name)
    );
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
    CREATE FUNCTION storage.foldername(name text) RETURNS text[] LANGUAGE sql IMMUTABLE AS $$
      SELECT (string_to_array(name, '/'))[1:greatest(array_length(string_to_array(name, '/'), 1) - 1, 0)]
    $$;
    CREATE FUNCTION storage.extension(name text) RETURNS text LANGUAGE sql IMMUTABLE AS $$
      SELECT lower(substring(name FROM '\\.([^.]+)$'))
    $$;

    GRANT USAGE ON SCHEMA public, auth, storage, extensions TO anon, authenticated, service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA storage TO anon, authenticated, service_role;
    CREATE PUBLICATION supabase_realtime;
  `);

  await db.exec(baselineSql);
  await db.exec(photoMigrationSql);
  await db.exec(stripLocks(backendReviewSql));
  await db.exec(stripLocks(quotaReviewSql));

  return db;
}

async function seedPhoto(db, employeeId, path) {
  await db.query(`
    INSERT INTO storage.objects (bucket_id, name, metadata)
    VALUES ('employee-photos', $1, '{"size": 1024, "mimetype": "image/jpeg"}'::jsonb)
    ON CONFLICT (bucket_id, name) DO NOTHING
  `, [path]);

  await db.query(`
    INSERT INTO private.pending_employee_uploads (object_path, status)
    VALUES ($1, 'PENDING')
    ON CONFLICT (object_path) DO NOTHING
  `, [path]);

  await db.query(`
    INSERT INTO private.new_employee_photo_attestations (object_path, employee_id)
    VALUES ($1, $2)
    ON CONFLICT (object_path) DO NOTHING
  `, [path, employeeId]);
}

const ROUNDS = 20;
const THREADS = 8;
const TOKENS = {
  a: "a".repeat(96),
  b: "b".repeat(96),
  c: "c".repeat(96)
};
const TOKEN_KEYS = ["a", "a", "a", "a", "b", "b", "c", "c"];

(async () => {
  console.log("================================================================================");
  console.log(`STARTING MULTI-SESSION CONCURRENCY RACE TEST (${ROUNDS} ROUNDS x ${THREADS} SESSIONS)`);
  console.log("================================================================================\n");

  const startTime = Date.now();
  const db = await setupDatabase();
  const failures = [];

  for (let rnd = 0; rnd < ROUNDS; rnd++) {
    const emp = `QA-RACE-${crypto.randomBytes(6).toString("hex")}`;
    const photo = `registrations/${emp}/aa123456-78ab-41cd-91ab-123456789abc.jpg`;
    await seedPhoto(db, emp, photo);

    // Launch all 8 sessions simultaneously
    const sessionPromises = TOKEN_KEYS.map((key, idx) => {
      const tokenVal = TOKENS[key];
      return db.query(`
        SELECT public.register_new_employee_request(
          $1, $2, '0791234567', 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)', null,
          'طبيب', 'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)', $3, $4,
          $5, 'iOS', 'iPhone', 'Safari', 'PERMANENT', null
        ) as result
      `, [
        `QA Runner ${idx}`,
        emp,
        photo,
        tokenVal,
        `dev-${idx}`
      ]).then(res => ({ key, result: res.rows[0].result }))
        .catch(err => ({ key, error: err.message }));
    });

    const outcomes = await Promise.all(sessionPromises);

    // Inspect database state
    const regQuery = await db.query(
      `SELECT count(*)::int as count, min(pending_trusted_device_token_hash) as hash FROM public.employee_registrations WHERE employee_id = $1`,
      [emp]
    );
    const rowCount = regQuery.rows[0].count;
    const committedHash = regQuery.rows[0].hash;

    const ledgerQuery = await db.query(
      `SELECT status FROM private.pending_employee_uploads WHERE object_path = $1`,
      [photo]
    );
    const ledgerStatus = ledgerQuery.rows[0]?.status;

    // Evaluate assertions
    if (rowCount !== 1) {
      failures.push({ round: rnd, error: `Row count was ${rowCount}, expected 1` });
    }
    if (ledgerStatus !== "LINKED") {
      failures.push({ round: rnd, error: `Ledger status was ${ledgerStatus}, expected LINKED` });
    }

    const creations = outcomes.filter(o => o.result?.ok === true && (o.result?.message || "").includes("الرجاء انتظار موافقة"));
    if (creations.length !== 1) {
      failures.push({ round: rnd, error: `Creation responses count was ${creations.length}, expected 1` });
    }

    const errors = outcomes.filter(o => o.error);
    if (errors.length > 0) {
      failures.push({ round: rnd, error: `Unhandled SQL exceptions: ${JSON.stringify(errors)}` });
    }

    // Determine winning key
    const winnerKey = Object.keys(TOKENS).find(k => {
      const h = crypto.createHash("sha256").update(TOKENS[k]).digest("hex");
      return h === committedHash;
    });

    if (!winnerKey) {
      failures.push({ round: rnd, error: `Committed hash ${committedHash} did not match any test token` });
    } else {
      for (const o of outcomes) {
        if (o.key === winnerKey) {
          // Winner's token: either created the row or got valid idempotent PENDING retry
          if (!(o.result?.ok === true && o.result?.result === "PENDING")) {
            failures.push({ round: rnd, error: `Winner token '${o.key}' got unexpected response: ${JSON.stringify(o.result)}` });
          }
        } else {
          // Foreign token: must be DENIED
          if (o.result?.ok === true || o.result?.result !== "DENIED") {
            failures.push({ round: rnd, error: `Foreign token '${o.key}' was not denied: ${JSON.stringify(o.result)}` });
          }
        }
      }
    }

    const dot = failures.length === 0 ? "✓" : "✗";
    process.stdout.write(`Round ${(rnd + 1).toString().padStart(2, "0")}/${ROUNDS} [${dot}] `);
    if ((rnd + 1) % 5 === 0) console.log();
  }

  console.log("\n--- CONCURRENT PHOTO UPLOAD QUOTA TEST ---");
  await db.exec(`SET ROLE service_role;`);

  // Test A: 10 concurrent requests for the SAME employee: exactly 1 allowed, 9 locked with CONCURRENT_UPLOAD_LOCKED
  const quotaEmp = "EMP-CONCURRENT-QUOTA";
  const sameEmpPromises = Array.from({ length: 10 }).map((_, i) => {
    return db.query(`
      SELECT public.claim_new_photo_upload_quota($1, $2, 5, 10, 100, 3600) as result
    `, [quotaEmp, `src-concurrent-${i}`])
      .then(r => r.rows[0].result)
      .catch(e => ({ error: e.message }));
  });
  const sameEmpOutcomes = await Promise.all(sameEmpPromises);
  const sameEmpAllowed = sameEmpOutcomes.filter(r => r.allowed === true);
  const sameEmpLocked = sameEmpOutcomes.filter(r => r.allowed === false && r.reason === "CONCURRENT_UPLOAD_LOCKED");
  console.log(`Concurrent Same-Employee Claims: 10 attempted | Allowed: ${sameEmpAllowed.length} | In-Flight Locked: ${sameEmpLocked.length}`);
  if (sameEmpAllowed.length !== 1 || sameEmpLocked.length !== 9) {
    failures.push({
      round: "Quota-InFlight-Stress",
      error: `Expected exactly 1 allowed and 9 CONCURRENT_UPLOAD_LOCKED, got allowed=${sameEmpAllowed.length}, locked=${sameEmpLocked.length}`
    });
  }

  // Test B: 10 concurrent requests from the SAME source across distinct employees: exactly 3 allowed, 7 rejected with QUOTA_EXCEEDED_SOURCE
  const sharedSrc = "src-shared-concurrent";
  const multiEmpPromises = Array.from({ length: 10 }).map((_, i) => {
    return db.query(`
      SELECT public.claim_new_photo_upload_quota($1, $2, 5, 3, 100, 3600) as result
    `, [`EMP-DISTINCT-${i}`, sharedSrc])
      .then(r => r.rows[0].result)
      .catch(e => ({ error: e.message }));
  });
  const multiEmpOutcomes = await Promise.all(multiEmpPromises);
  const srcAllowed = multiEmpOutcomes.filter(r => r.allowed === true);
  const srcDenied = multiEmpOutcomes.filter(r => r.allowed === false && r.reason === "QUOTA_EXCEEDED_SOURCE");
  console.log(`Concurrent Shared-Source Claims: 10 attempted | Allowed: ${srcAllowed.length} | Source-Denied: ${srcDenied.length}`);
  if (srcAllowed.length !== 3 || srcDenied.length !== 7) {
    failures.push({
      round: "Quota-Source-Stress",
      error: `Expected exactly 3 allowed and 7 QUOTA_EXCEEDED_SOURCE, got allowed=${srcAllowed.length}, denied=${srcDenied.length}`
    });
  }

  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  console.log("\n================================================================================");
  console.log(`CONCURRENCY RACE TEST FINISHED IN ${duration}s`);
  console.log(`TOTAL ROUNDS: ${ROUNDS} x ${THREADS} sessions = ${ROUNDS * THREADS} registration attempts`);
  console.log(`FAILURES: ${failures.length}`);
  console.log("================================================================================");

  if (failures.length > 0) {
    console.error("FAILURES DETECTED:");
    failures.forEach(f => console.error(JSON.stringify(f)));
    process.exit(1);
  } else {
    console.log("🎉 CONCURRENCY & RACE TEST PASSED WITH ZERO FAILURES AND ZERO DEADLOCKS!");
    process.exit(0);
  }
})();

