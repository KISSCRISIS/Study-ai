"""
REAL multi-session PostgreSQL race test for public.register_new_employee_request.
STATUS IN THIS DELIVERY: NOT RUN (no PostgreSQL / psycopg2 in the authoring environment).

Requires a DISPOSABLE LOCAL database that already contains the project schema plus the
reviewed new-only backend SQL (with its RAISE EXCEPTION lock removed in a scratch copy).
It REFUSES to run against any host containing 'supabase' or any non-local host unless
ALBASHIR_ALLOW_NONLOCAL_DISPOSABLE=1 is set deliberately by the owner.

  set ALBASHIR_LOCAL_PG_DSN=postgresql://postgres:postgres@localhost:5432/albashir_qa
  python tests/pg_multisession_race.py

Each worker uses its OWN connection/transaction. Seed/cleanup run in committed transactions
and touch only QA-RACE-* rows.
"""
import os, sys, threading, uuid, hashlib

dsn = os.environ.get("ALBASHIR_LOCAL_PG_DSN", "")
if not dsn:
    print("NOT RUN: ALBASHIR_LOCAL_PG_DSN not set"); sys.exit(3)
try:
    import psycopg2
except ImportError:
    print("NOT RUN: psycopg2 not installed"); sys.exit(3)
host_ok = any(h in dsn for h in ("localhost", "127.0.0.1", "::1"))
if "supabase" in dsn.lower() or (not host_ok and os.environ.get("ALBASHIR_ALLOW_NONLOCAL_DISPOSABLE") != "1"):
    print("REFUSED: DSN must be a disposable local database"); sys.exit(4)

ROUNDS, THREADS = 20, 8
TOK = {"a": "a" * 96, "b": "b" * 96, "c": "c" * 96}
CALL = """select public.register_new_employee_request(%s,%s,'0791234567',null,null,'طبيب',
  'الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',%s,%s,'dev-1','iOS','iPhone','Safari','PERMANENT',null)"""

def conn():
    c = psycopg2.connect(dsn); c.autocommit = True; return c

def seed(emp, path):
    with conn() as c, c.cursor() as cur:
        cur.execute("insert into storage.objects(bucket_id,name,metadata) values('employee-photos',%s,'{\"size\":613,\"mimetype\":\"image/jpeg\"}')", (path,))
        cur.execute("insert into private.pending_employee_uploads(object_path,status) values(%s,'PENDING')", (path,))
        cur.execute("insert into private.new_employee_photo_attestations(object_path,employee_id) values(%s,%s)", (path, emp))

def cleanup(emp, path):
    with conn() as c, c.cursor() as cur:
        cur.execute("delete from public.employee_registrations where employee_id=%s", (emp,))
        cur.execute("delete from private.pending_employee_uploads where object_path=%s", (path,))
        cur.execute("delete from private.new_employee_photo_attestations where object_path=%s", (path,))
        cur.execute("delete from storage.objects where bucket_id='employee-photos' and name=%s", (path,))

failures = []
for rnd in range(ROUNDS):
    emp = f"QA-RACE-{uuid.uuid4().hex[:10]}"
    path = f"registrations/{emp}/aa123456-78ab-41cd-91ab-123456789abc.jpg"
    seed(emp, path)
    barrier = threading.Barrier(THREADS)
    out = []
    toks = ["a", "a", "a", "a", "b", "b", "c", "c"]
    def worker(k):
        c = conn()
        try:
            barrier.wait()
            with c.cursor() as cur:
                cur.execute(CALL, ("QA RACE", emp, path, TOK[k]))
                out.append((k, cur.fetchone()[0]))
        except Exception as e:           # a raised unique_violation etc. is a FAILURE
            out.append((k, {"exception": str(e)}))
        finally:
            c.close()
    ts = [threading.Thread(target=worker, args=(k,)) for k in toks]
    [t.start() for t in ts]; [t.join() for t in ts]
    with conn() as c, c.cursor() as cur:
        cur.execute("select count(*), min(pending_trusted_device_token_hash) from public.employee_registrations where employee_id=%s", (emp,))
        n, h = cur.fetchone()
        cur.execute("select status from private.pending_employee_uploads where object_path=%s", (path,))
        st = cur.fetchone()[0]
    created = [r for k, r in out if r.get("ok") and "الرجاء انتظار موافقة" in r.get("message", "")]
    if n != 1: failures.append((rnd, f"rows={n}"))
    if st != "LINKED": failures.append((rnd, f"ledger status={st}"))
    if len(created) != 1: failures.append((rnd, f"creation successes={len(created)}"))
    if any("exception" in r for k, r in out): failures.append((rnd, f"exception: {out}"))
    # Identify the winning token key from the committed database row hash:
    winner_key = next((k for k, tok_val in TOK.items() if hashlib.sha256(tok_val.encode('utf-8')).hexdigest() == h), None)
    if winner_key is None:
        failures.append((rnd, f"committed hash {h} did not match any test token"))
    else:
        for k, r in out:
            if k == winner_key:
                # Same proof: either creation success or idempotent PENDING retry
                if not (r.get("ok") is True and r.get("result") == "PENDING"):
                    failures.append((rnd, f"same-proof token '{k}' failed idempotent response: {r}"))
            else:
                # Foreign / different proof: must be strictly rejected
                if r.get("ok") is True or r.get("result") != "DENIED":
                    failures.append((rnd, f"foreign token '{k}' was not denied: {r}"))
    cleanup(emp, path)

print("FAILURES:" if failures else f"PASS: {ROUNDS} rounds x {THREADS} real sessions")
for f in failures: print(f)
sys.exit(1 if failures else 0)
