/**
 * playwright-production-guard.cjs
 * Mandatory security guard for all Playwright browser test contexts.
 * 
 * Enforces Zero-Touch Production:
 *  - Intercepts every network request
 *  - Blocks any attempt to reach Supabase Production (qinsfvlspdticposbvst.supabase.co)
 *    or Vercel Production (albashir-stone-karag.vercel.app)
 *  - Immediately fails the test with a descriptive AssertionError and logs the URL
 *  - Blocks Service Workers to prevent bypasses
 */
const assert = require("node:assert/strict");

const PROD_HOSTS = [
  "qinsfvlspdticposbvst.supabase.co",
  "albashir-stone-karag.vercel.app"
];

function isProductionUrl(urlString) {
  try {
    const u = new URL(urlString);
    return PROD_HOSTS.some(ph => u.hostname === ph || u.hostname.endsWith("." + ph));
  } catch {
    return false;
  }
}

function installProductionGuard(context, options = {}) {
  const allowedOrigin = options.allowedOrigin || null;
  const customHandler = options.onRoute || null;
  const violationLog = [];

  context.route("**/*", async (route) => {
    const req = route.request();
    const urlStr = req.url();
    
    if (isProductionUrl(urlStr)) {
      violationLog.push({ url: urlStr, method: req.method(), time: new Date().toISOString() });
      console.error(`🚨 [CRITICAL_TEST_FAILURE] Prohibited call to Production intercepted: ${req.method()} ${urlStr}`);
      await route.abort("blockedbyclient");
      assert.fail(`TEST FAILED: Playwright test attempted connection to Production: ${req.method()} ${urlStr}`);
      return;
    }

    if (customHandler) {
      const handled = await customHandler(route, req);
      if (handled) return;
    }

    if (urlStr.startsWith("about:") || urlStr.startsWith("data:") || (allowedOrigin && urlStr.startsWith(allowedOrigin))) {
      return route.continue();
    }

    return route.abort();
  });

  return {
    getViolations: () => [...violationLog]
  };
}

module.exports = {
  PROD_HOSTS,
  isProductionUrl,
  installProductionGuard
};

