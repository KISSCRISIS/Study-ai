const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const {installProductionGuard}=require('./playwright-production-guard.cjs');
const html=fs.readFileSync(path.join(__dirname,'../register.html'),'utf8');
const source=html.slice(html.indexOf('  const MAX_PHOTO_BYTES'),html.indexOf('  async function uploadEmployeePhoto'));
(async()=>{
  const browser=await chromium.launch();
  try{
    const context=await browser.newContext({serviceWorkers:'block'});
    installProductionGuard(context);
    const page=await context.newPage();
    await page.addScriptTag({content:source});
    const result=await page.evaluate(async()=>{
      const canvas=document.createElement('canvas');canvas.width=2400;canvas.height=2400;
      const context=canvas.getContext('2d'),pixels=context.createImageData(2400,2400);
      let seed=123;for(let i=0;i<pixels.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;pixels.data[i]=seed&255;pixels.data[i+1]=(seed>>>8)&255;pixels.data[i+2]=(seed>>>16)&255;pixels.data[i+3]=255;}
      context.putImageData(pixels,0,0);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
      const input=new File([blob],'large.png',{type:'image/png'});
      const prepared=await prepareEmployeePhoto(input);
      const bitmap=await createImageBitmap(prepared.file);
      const dimensions=[bitmap.width,bitmap.height];bitmap.close();

      const smallCanvas=document.createElement('canvas');smallCanvas.width=180;smallCanvas.height=240;
      smallCanvas.getContext('2d').fillRect(0,0,180,240);
      const smallPng=await new Promise(resolve=>smallCanvas.toBlob(resolve,'image/png'));
      const smallInput=new File([smallPng],'small.png',{type:'image/png'});
      const smallPrepared=await prepareEmployeePhoto(smallInput);
      const smallBitmap=await createImageBitmap(smallPrepared.file);
      const smallDimensions=[smallBitmap.width,smallBitmap.height];smallBitmap.close();

      const emptyMimeFile=new File([prepared.file],'empty-mime.jpg',{type:''});
      const kept=await prepareEmployeePhoto(emptyMimeFile);
      let mismatch=false,unsupported=false;
      try{await prepareEmployeePhoto(new File([blob],'bad.png',{type:'image/jpeg'}));}catch{mismatch=true;}
      try{await prepareEmployeePhoto(new File(['invalid'],'photo.heic',{type:'image/heic'}));}catch(e){unsupported=e.message.includes('HEIC/HEIF');}
      return {inputBytes:input.size,outputBytes:prepared.file.size,type:prepared.file.type,extension:prepared.extension,dimensions,smallInputBytes:smallInput.size,smallOutputBytes:smallPrepared.file.size,smallOutputType:smallPrepared.file.type,smallExtension:smallPrepared.extension,smallDimensions,emptyMimeAccepted:kept.mimeType==='image/jpeg',mismatch,unsupported};
    });
    assert(result.inputBytes>2097152);assert(result.outputBytes<=2097152);assert.equal(result.type,'image/jpeg');assert.equal(result.extension,'jpg');assert(Math.max(...result.dimensions)<=960);
    assert(result.smallInputBytes<2097152);assert.equal(result.smallOutputType,'image/jpeg');assert.equal(result.smallExtension,'jpg');assert(Math.max(...result.smallDimensions)<=960);
    assert(result.emptyMimeAccepted&&result.mismatch&&result.unsupported);
    console.log('PASS large and small employee photos are normalized to JPEG at <=960px; size, empty MIME, mismatch and unsupported HEIC checks passed');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
