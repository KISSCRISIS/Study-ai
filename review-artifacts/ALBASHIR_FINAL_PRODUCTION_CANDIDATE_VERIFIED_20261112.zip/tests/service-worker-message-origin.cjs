"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "../service-worker.js"), "utf8");
async function attempt(client, messageSource, data) {
  const listeners = {};
  let activated = 0, task;
  const self = {
    location: { origin: "https://app.example", href: "https://app.example/service-worker.js" },
    addEventListener(name, handler) { listeners[name] = handler; },
    clients: { async get(id) { return id === client?.id ? client : undefined; } },
    async skipWaiting() { activated++; }
  };
  vm.runInNewContext(source, { self, URL, Promise, AbortController, setTimeout, clearTimeout });
  listeners.message({ data, source: messageSource, waitUntil(p) { task = p; } });
  if (task) await task;
  return activated;
}

(async () => {
  const same = { id: "client-1", url: "https://app.example/register.html" };
  const message = { type: "ACTIVATE_SAFE_UPDATE", confirmed: true };
  assert.equal(await attempt(same, same, message), 1);
  assert.equal(await attempt(same, null, message), 0);
  assert.equal(await attempt(null, { id: "client-1" }, message), 0);
  assert.equal(await attempt({ id: "client-1", url: "https://evil.example/" }, { id: "client-1" }, message), 0);
  assert.equal(await attempt({ id: "client-1", url: "invalid-url" }, { id: "client-1" }, message), 0);
  assert.equal(await attempt(same, same, { ...message, confirmed: false }), 0);
  console.log("PASS service worker update requires an existing same-origin client");
})().catch(error => { console.error(error); process.exitCode = 1; });
