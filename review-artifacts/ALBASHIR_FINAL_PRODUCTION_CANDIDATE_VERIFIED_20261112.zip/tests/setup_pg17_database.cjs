/**
 * setup_pg17_database.cjs
 * Bootstraps the real PostgreSQL 17 server with the complete Albashir schema.
 */
const { Client } = require("pg");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const dsn = process.env.ALBASHIR_LOCAL_PG_DSN || "postgresql://postgres@127.0.0.1:5432/albashir_qa";

function stripLocks(sql) {
  return sql.replace(/DO\s+\$[^$]+\$[\s\S]*?\$[^$]+\$;/g, "-- lock removed for test execution");
}

async function run() {
  console.log("Connecting to PostgreSQL 17 at:", dsn);
  const client = new Client({ connectionString: dsn });
  await client.connect();

  console.log("1. Setting up roles, extensions, and storage...");
  await client.query(`
    DROP SCHEMA IF EXISTS public CASCADE;
    CREATE SCHEMA public;
    DROP SCHEMA IF EXISTS private CASCADE;
    CREATE SCHEMA private;

    DO $$ BEGIN
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN CREATE ROLE anon; END IF;
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN CREATE ROLE authenticated; END IF;
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'service_role') THEN CREATE ROLE service_role BYPASSRLS; END IF;
    END $$;

    CREATE SCHEMA IF NOT EXISTS extensions;
    CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY, email text);
    CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
      SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
    $$;

    CREATE SCHEMA IF NOT EXISTS storage;
    CREATE TABLE IF NOT EXISTS storage.buckets (
      id text PRIMARY KEY,
      name text NOT NULL,
      public boolean DEFAULT false,
      file_size_limit bigint DEFAULT null,
      allowed_mime_types text[] DEFAULT null,
      created_at timestamptz DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS storage.objects (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      bucket_id text NOT NULL,
      name text NOT NULL,
      metadata jsonb,
      created_at timestamptz DEFAULT now(),
      UNIQUE (bucket_id, name)
    );
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

    CREATE OR REPLACE FUNCTION storage.foldername(name text) RETURNS text[] LANGUAGE sql IMMUTABLE AS $$
      SELECT (string_to_array(name, '/'))[1:greatest(array_length(string_to_array(name, '/'), 1) - 1, 0)]
    $$;
    CREATE OR REPLACE FUNCTION storage.extension(name text) RETURNS text LANGUAGE sql IMMUTABLE AS $$
      SELECT lower(substring(name FROM '\\.([^.]+)$'))
    $$;

    GRANT USAGE ON SCHEMA public, auth, storage, extensions TO anon, authenticated, service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA storage TO anon, authenticated, service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA storage TO anon, authenticated, service_role;

    DO $$ BEGIN
      IF NOT EXISTS (SELECT FROM pg_catalog.pg_publication WHERE pubname = 'supabase_realtime') THEN
        CREATE PUBLICATION supabase_realtime;
      END IF;
    END $$;
  `);

  console.log("2. Applying baseline consolidated fresh install...");
  const baselineSql = fs.readFileSync(path.join(root, "schema_consolidated_fresh_install.sql"), "utf8");
  await client.query(baselineSql);

  console.log("3. Applying photo storage migration...");
  const photoMigrationSql = fs.readFileSync(path.join(root, "supabase/migrations/20261006190000_private_employee_photos.sql"), "utf8");
  await client.query(photoMigrationSql);

  console.log("4. Applying reviewed backend new-only SQL...");
  const backendReviewSql = fs.readFileSync(path.join(root, "supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql"), "utf8");
  await client.query(stripLocks(backendReviewSql));

  console.log("5. Applying reviewed photo upload quota SQL...");
  const quotaReviewSql = fs.readFileSync(path.join(root, "supabase/review/NEW_ONLY_PHOTO_UPLOAD_QUOTA_REVIEW_LOCKED.sql"), "utf8");
  await client.query(stripLocks(quotaReviewSql));

  console.log("Database albashir_qa successfully initialized on PostgreSQL 17!");
  await client.end();
}

run().catch(err => {
  console.error("BOOTSTRAP FAILED:", err);
  process.exit(1);
});
