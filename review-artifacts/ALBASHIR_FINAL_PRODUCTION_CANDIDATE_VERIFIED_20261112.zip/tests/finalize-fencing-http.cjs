"use strict";
// tests/finalize-fencing-http.cjs
// Proves, at the HTTP-status level of handleNewPhotoUpload, that:
//  * finalizeUploadQuota failure / timeout / malformed answer / missing dependency NEVER yields 201;
//  * a lost fencing lease can never attest a photo and never deletes an attested photo;
//  * the order is always assert(lease) -> attest -> finalize.
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const path = require("node:path");

if (!globalThis.crypto?.subtle) globalThis.crypto = crypto.webcrypto;

function buildValidJpeg(seed = 1) {
  const header = [0xff,0xd8,0xff,0xe0,0x00,0x10,0x4a,0x46,0x49,0x46,0x00,0x01,0x01,0x01,0x00,0x48,0x00,0x48,0x00,0x00,
    0xff,0xc0,0x00,0x11,0x08,0x00,0x40,0x00,0x40,0x03,0x01,0x11,0x00,0x02,0x11,0x01,0x03,0x11,0x01,
    0xff,0xda,0x00,0x0c,0x03,0x01,0x00,0x02,0x11,0x03,0x11,0x00,0x3f,0x00];
  const payload = new Uint8Array(32).map((_, i) => ((seed * 31 + i * 17) & 0x7f) + 1);
  const out = new Uint8Array(header.length + payload.length + 2);
  out.set(header, 0); out.set(payload, header.length);
  out[out.length - 2] = 0xff; out[out.length - 1] = 0xd9;
  return out;
}

const ORIGIN = "https://albashir-staging.vercel.app";
let seedCounter = 100;
function request(employeeId) {
  return {
    method: "POST",
    headers: { origin: ORIGIN },
    trustedSource: null,
    form: { employee_id: employeeId, fileName: "employee.jpg", mimeType: "image/jpeg",
            bytes: buildValidJpeg(seedCounter++), "cf-turnstile-response": "valid-token" }
  };
}

function makeDeps(overrides = {}) {
  const trace = { events: [], uploaded: [], attested: [], removed: [], released: [], finalizeCalls: 0, assertCalls: 0 };
  const deps = {
    allowedOrigins: ORIGIN,
    now: () => 1762900000000,
    randomUUID: () => crypto.randomUUID(),
    async verifyTurnstile() { return { ok: true }; },
    async claimUploadQuota() { return { allowed: true, lease_id: crypto.randomUUID() }; },
    async consumeUploadQuota(leaseId) { return { ok: true, lease_id: leaseId }; },
    async releaseUploadQuota(leaseId) { trace.released.push(leaseId); return { ok: true }; },
    async checkEligibility() { return { ok: true, is_new: true }; },
    async uploadObject(p) { trace.events.push("upload"); trace.uploaded.push(p); return { ok: true }; },
    async registerPendingUpload() { trace.events.push("ledger"); return { ok: true }; },
    async assertUploadLease() { trace.assertCalls++; trace.events.push("assert"); return { ok: true }; },
    async attestNewPhoto(id, p) { trace.events.push("attest"); trace.attested.push(p); return { ok: true }; },
    async finalizeUploadQuota(leaseId) { trace.finalizeCalls++; trace.events.push("finalize"); return { ok: true, lease_id: leaseId }; },
    async removeObject(p) { trace.events.push("remove"); trace.removed.push(p); return { ok: true }; },
    async confirmPendingRemoval() { return { ok: true }; },
    ...overrides
  };
  return { deps, trace };
}

const results = [];
function check(name, fn) { results.push([name, fn]); }

(async () => {
  const handlerPath = path.resolve(__dirname, "../supabase/functions/employee-photo-upload-new/handler.mjs");
  const { handleNewPhotoUpload, createUploadState } = await import("file://" + handlerPath.replace(/\\/g, "/"));
  const run = (req, deps, state = createUploadState()) => handleNewPhotoUpload(req, deps, state);

  check("finalize ok:true -> 201 and order assert->attest->finalize", async () => {
    const { deps, trace } = makeDeps();
    const r = await run(request("F-OK"), deps);
    assert.equal(r.status, 201); assert.equal(r.body.ok, true);
    assert.deepEqual(trace.events.filter(e => ["assert","attest","finalize"].includes(e)), ["assert","attest","finalize"]);
  });

  check("finalize returns ok:false (generic) -> NOT 201, photo kept, nothing cached", async () => {
    const state = createUploadState();
    const { deps, trace } = makeDeps({ async finalizeUploadQuota() { trace.finalizeCalls++; return { ok: false, reason: "LEASE_STATE_CONFLICT" }; } });
    const req = request("F-FAIL");
    const r = await run(req, deps, state);
    assert.equal(r.status, 503); assert.equal(r.body.ok, false); assert.equal(r.body.code, "FINALIZE_FAILED");
    assert.equal(trace.removed.length, 0, "attested photo must not be deleted");
    assert.equal(trace.finalizeCalls, 1, "deterministic failure is not retried");
    assert.equal(state.attestedByDigest.size, 0, "failed finalize must not be remembered as success");
    // an identical retry must NOT be answered with a cached success
    const again = await run(req, deps, state);
    assert.notEqual(again.status, 201); assert.notEqual(again.status, 200);
  });

  check("finalize throws timeout -> NOT 201, outcomeUnknown, retried once, photo kept", async () => {
    const { deps, trace } = makeDeps({ async finalizeUploadQuota() { trace.finalizeCalls++; throw new Error("PostgREST request timed out after 8000ms"); } });
    const r = await run(request("F-TIMEOUT"), deps);
    assert.equal(r.status, 503); assert.equal(r.body.code, "FINALIZE_OUTCOME_UNCERTAIN"); assert.equal(r.body.outcomeUnknown, true);
    assert.equal(trace.finalizeCalls, 2); assert.equal(trace.removed.length, 0); assert.equal(trace.released.length, 0, "never refund an uncertain lease");
  });

  check("finalize outcomeUnknown then success on retry -> 201", async () => {
    let n = 0;
    const { deps, trace } = makeDeps({ async finalizeUploadQuota(l) { trace.finalizeCalls++; return ++n === 1 ? { ok: false, outcomeUnknown: true, reason: "FINALIZE_EXCEPTION" } : { ok: true, lease_id: l }; } });
    const r = await run(request("F-RETRY"), deps);
    assert.equal(r.status, 201); assert.equal(trace.finalizeCalls, 2);
  });

  for (const [label, value] of [["undefined", undefined], ["null", null], ["empty object", {}], ["string 'true'", { ok: "true" }], ["ok:1", { ok: 1 }]]) {
    check(`finalize malformed answer (${label}) -> NOT 201`, async () => {
      const { deps, trace } = makeDeps({ async finalizeUploadQuota() { trace.finalizeCalls++; return value; } });
      const r = await run(request("F-MAL-" + label.replace(/\W/g, "")), deps);
      assert.equal(r.status, 503); assert.equal(r.body.ok, false); assert.equal(trace.removed.length, 0);
    });
  }

  check("finalize dependency missing -> 503 FINALIZE_UNAVAILABLE (never 201)", async () => {
    const { deps, trace } = makeDeps({ finalizeUploadQuota: undefined });
    const r = await run(request("F-NODEP"), deps);
    assert.equal(r.status, 503); assert.equal(r.body.code, "FINALIZE_UNAVAILABLE"); assert.equal(trace.removed.length, 0);
  });

  check("finalize LEASE_SUPERSEDED after attest -> 409 and attested photo KEPT", async () => {
    const { deps, trace } = makeDeps({ async finalizeUploadQuota() { trace.finalizeCalls++; return { ok: false, reason: "LEASE_SUPERSEDED" }; } });
    const r = await run(request("F-SUPER"), deps);
    assert.equal(r.status, 409); assert.equal(r.body.code, "UPLOAD_SUPERSEDED");
    assert.equal(trace.attested.length, 1); assert.equal(trace.removed.length, 0);
  });

  check("fence lost (superseded) before attest -> 409, NO attestation, unattested object removed", async () => {
    const { deps, trace } = makeDeps({ async assertUploadLease() { trace.assertCalls++; trace.events.push("assert"); return { ok: false, reason: "LEASE_SUPERSEDED" }; } });
    const r = await run(request("A-SUPER"), deps);
    assert.equal(r.status, 409); assert.equal(trace.attested.length, 0); assert.equal(trace.finalizeCalls, 0);
    assert.equal(trace.removed.length, 1);
  });

  check("atomic attest detects lease superseded between assert and attest -> 409, photo NOT attested, unattested object removed", async () => {
    let leasePassed = null;
    const { deps, trace } = makeDeps({
      async assertUploadLease(l) {
        trace.assertCalls++;
        trace.events.push("assert");
        return { ok: true, lease_id: l };
      },
      async attestNewPhoto(id, p, l) {
        leasePassed = l;
        trace.events.push("attest_check");
        return { ok: false, reason: "LEASE_SUPERSEDED", code: "UPLOAD_SUPERSEDED" };
      }
    });
    const r = await run(request("A-RACE-BETWEEN"), deps);
    assert.equal(r.status, 409);
    assert.equal(r.body.code, "UPLOAD_SUPERSEDED");
    assert.ok(leasePassed, "leaseId must be passed to attestNewPhoto");
    assert.equal(trace.attested.length, 0, "must not attest photo");
    assert.equal(trace.finalizeCalls, 0, "finalize must never run");
    assert.equal(trace.removed.length, 1, "unattested photo must be cleaned up");
  });

  check("fence lost (expired) before attest -> 409, NO attestation", async () => {
    const { deps, trace } = makeDeps({ async assertUploadLease() { return { ok: false, reason: "LEASE_EXPIRED" }; } });
    const r = await run(request("A-EXP"), deps);
    assert.equal(r.status, 409); assert.equal(trace.attested.length, 0);
  });

  check("fence check throws (uncertain) -> 503, NO attestation, object NOT deleted", async () => {
    const { deps, trace } = makeDeps({ async assertUploadLease() { throw new Error("fetch failed: socket hang up"); } });
    const r = await run(request("A-THROW"), deps);
    assert.equal(r.status, 503); assert.equal(r.body.code, "FENCING_OUTCOME_UNKNOWN");
    assert.equal(trace.attested.length, 0); assert.equal(trace.removed.length, 0); assert.equal(trace.released.length, 0);
  });

  check("fence dependency missing -> 503, NO attestation", async () => {
    const { deps, trace } = makeDeps({ assertUploadLease: undefined });
    const r = await run(request("A-NODEP"), deps);
    assert.equal(r.status, 503); assert.equal(r.body.code, "FENCING_UNAVAILABLE"); assert.equal(trace.attested.length, 0);
  });

  check("attest outcome unknown after a good fence -> 503, object NOT deleted, no finalize", async () => {
    const { deps, trace } = makeDeps({ async attestNewPhoto() { throw new Error("timeout"); } });
    const r = await run(request("T-ATT"), deps);
    assert.equal(r.status, 503); assert.equal(trace.removed.length, 0); assert.equal(trace.finalizeCalls, 0);
  });

  let failed = 0;
  for (const [name, fn] of results) {
    try { await fn(); console.log("  PASS", name); }
    catch (err) { failed++; console.log("  FAIL", name, "\n     ", err.message); }
  }
  console.log(`finalize/fencing HTTP matrix: ${results.length - failed}/${results.length} PASS`);
  if (failed) process.exit(1);
})().catch(err => { console.error(err); process.exit(1); });

