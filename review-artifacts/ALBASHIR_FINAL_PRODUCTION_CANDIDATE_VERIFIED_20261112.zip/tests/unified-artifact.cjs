const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),builder=path.join(root,'scripts/build-public-runtime.cjs');
const run=env=>spawnSync(process.execPath,[builder,...(env?['--staging']:[])],{env:{...process.env,ALBASHIR_ENVIRONMENT:env?'staging':'production',...env},encoding:'utf8'});
assert.equal(run().status,0);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'config/runtime-baseline.json')));
function list(dir,p=''){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?list(path.join(dir,e.name),p+e.name+'/'):[p+e.name]);}
assert.deepEqual(list(path.join(root,'public-runtime')).sort(),manifest.map(x=>x.file).sort());
for(const x of manifest)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'public-runtime',x.file))).digest('hex'),x.sha256,x.file+' must match owner-approved release');
const url='https://adwvokwucotohwayorgx.supabase.co',key='sb_publishable_synthetic_staging';
assert.notEqual(run({ALBASHIR_SUPABASE_URL:'https://qinsfvlspdticposbvst.supabase.co',ALBASHIR_SUPABASE_PUBLISHABLE_KEY:key}).status,0);
assert.notEqual(run({ALBASHIR_SUPABASE_URL:url,ALBASHIR_SUPABASE_PUBLISHABLE_KEY:'sb_secret_test'}).status,0);
const jwt='eyJ'+'.'+Buffer.from(JSON.stringify({role:'service_role'})).toString('base64url')+'.test';
assert.notEqual(run({ALBASHIR_SUPABASE_URL:url,ALBASHIR_SUPABASE_PUBLISHABLE_KEY:jwt}).status,0);
assert.equal(run({ALBASHIR_SUPABASE_URL:url,ALBASHIR_SUPABASE_PUBLISHABLE_KEY:key}).status,0);
assert.notEqual(spawnSync(process.execPath,[builder],{env:{...process.env,ALBASHIR_ENVIRONMENT:'unknown'},encoding:'utf8'}).status,0);
assert.notEqual(spawnSync(process.execPath,[builder],{env:{...process.env,ALBASHIR_ENVIRONMENT:'staging',ALBASHIR_SUPABASE_URL:'',ALBASHIR_SUPABASE_PUBLISHABLE_KEY:''},encoding:'utf8'}).status,0);
assert.equal(spawnSync(process.execPath,[builder],{env:{...process.env,ALBASHIR_ENVIRONMENT:'staging',ALBASHIR_SUPABASE_URL:url,ALBASHIR_SUPABASE_PUBLISHABLE_KEY:key},encoding:'utf8'}).status,0);
for(const file of manifest.filter(x=>/\.(html|js|json)$/.test(x.file))){const text=fs.readFileSync(path.join(root,'public-runtime',file.file),'utf8');assert(!text.includes('https://qinsfvlspdticposbvst.supabase.co'),file.file);}
for(const name of ['guard.html','verify.html']){const html=fs.readFileSync(path.join(root,'public-runtime',name),'utf8');for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){if(/\bsrc\s*=/i.test(m[1]))continue;assert(html.includes("'sha256-"+crypto.createHash('sha256').update(m[2].replace(/\r\n?/g,'\n')).digest('base64')+"'"),name+' inline CSP must match staging source');}}
assert.equal(run().status,0);
console.log('PASS exact '+manifest.length+'-file release, no extra public files, environment isolation, secret-key rejection, CSP compatibility');
