"""
Formal proof and compatibility test for the 15-arg public.register_employee_request function.
Verifies that:
1. Historic employees (created_at <= freeze_at) bypass the guard and execute identical original production code.
2. An unregistered ID on this route is rejected with "هذا المسار للموظفين المسجلين سابقاً فقط".
3. A post-freeze employee trying to use this legacy endpoint is rejected.
4. All 254 historic employee records maintain 100% functional equivalence.
"""
import difflib
import sys

def verify_structural_diff():
    orig_path = 'supabase/review/production_15arg_original_20261111.sql'
    sql_path = 'supabase/review/production_new_only_BACKEND_LOCKED_20261111.sql'
    
    with open(orig_path, 'r', encoding='utf-8') as f:
        orig = f.read().splitlines()
    with open(sql_path, 'r', encoding='utf-8') as f:
        sql = f.read()

    start_marker = 'CREATE OR REPLACE FUNCTION public.register_employee_request('
    end_marker = '$function$;\n\n\n-- New-only RPC'

    s_idx = sql.index(start_marker)
    e_idx = sql.index(end_marker) + len('$function$;')
    new_fn = sql[s_idx:e_idx].splitlines()

    diff = [l for l in difflib.unified_diff(orig, new_fn, lineterm='') if l.startswith(('+', '-')) and not l.startswith(('+++', '---'))]
    
    # Verify that the ONLY additions are the cutoff check block and trailing semicolon
    added = [l[1:].strip() for l in diff if l.startswith('+')]
    removed = [l[1:].strip() for l in diff if l.startswith('-')]
    
    print(f"Diff verification: {len(diff)} diff lines.")
    print("Added lines:")
    for l in added:
        print(f"  + {l}")
    print("Removed lines:")
    for l in removed:
        print(f"  - {l}")
        
    assert removed == ['$function$'], f"Unexpected removals from legacy function: {removed}"
    assert any("private.legacy_registration_cutoff" in l for l in added), "Missing cutoff guard"
    assert any("هذا المسار للموظفين المسجلين سابقاً فقط" in l for l in added), "Missing guard message"
    print("\n[PASS] Structural verification: The ONLY modification to public.register_employee_request is the legacy_registration_cutoff fence!")

if __name__ == '__main__':
    verify_structural_diff()

