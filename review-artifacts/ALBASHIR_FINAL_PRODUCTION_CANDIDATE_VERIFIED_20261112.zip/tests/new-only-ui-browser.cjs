"use strict";
const fs=require("node:fs"),path=require("node:path"),http=require("node:http");
const assert=require("node:assert/strict"),{chromium}=require("playwright");
const root=path.resolve(__dirname,"..");
const png=Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jK1cAAAAASUVORK5CYII=","base64");
const stageHost="adwvokwucotohwayorgx.supabase.co";
const productionHost="qinsfvlspdticposbvst.supabase.co";
const server=http.createServer((req,res)=>{
  let pathname;
  try { pathname=decodeURIComponent(new URL(req.url,"http://localhost").pathname).replace(/^\//,""); }
  catch { res.writeHead(400).end(); return; }
  const full=path.resolve(root,pathname);
  if(!full.startsWith(root+path.sep)) {res.writeHead(403).end();return;}
  try {
    const mime=pathname.endsWith(".html")?"text/html; charset=utf-8":pathname.endsWith(".js")?"text/javascript":pathname.endsWith(".css")?"text/css":"application/octet-stream";
    res.writeHead(200,{"content-type":mime,"cache-control":"no-store"});
    res.end(fs.readFileSync(full));
  }catch{res.writeHead(404).end();}
});
const turnstileMock = (route, u) => {
  if (u.hostname === "challenges.cloudflare.com") {
    route.fulfill({
      status: 200,
      contentType: "text/javascript",
      body: `window.turnstile = { render: () => "w1", reset: () => {}, getResponse: () => "XXXX.TEST.TOKEN" };`
    });
    return true;
  }
  return false;
};

(async()=>{
 let browser;
 try{
  await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
  const origin="http://127.0.0.1:"+server.address().port;
  browser=await chromium.launch();
  const context=await browser.newContext({serviceWorkers:"block",viewport:{width:390,height:844}});
  const traces={upload:[],newRpc:[],unexpected:[]};
  await context.route("**/*",async route=>{
    const req=route.request(),u=new URL(req.url());
    if(u.origin===origin)return route.continue();
    if(turnstileMock(route,u))return;
    if(u.hostname===productionHost || u.hostname==="albashir-stone-karag.vercel.app"){
      traces.unexpected.push("PRODUCTION_SUPABASE");
      await route.abort();
      assert.fail("TEST FAILED: Playwright test attempted connection to Production: " + req.url());
      return;
    }
    if(u.hostname!==stageHost){traces.unexpected.push("unexpected:"+u.hostname);return route.abort();}
    const cors={"access-control-allow-origin":"*","access-control-allow-headers":"*","access-control-allow-methods":"GET,POST,OPTIONS"};
    if(req.method()==="OPTIONS")return route.fulfill({status:204,headers:cors});
    if(u.pathname==="/functions/v1/employee-photo-upload-new" && req.method()==="POST"){
      traces.upload.push({url:req.url(),body:req.postData()||""});
      return route.fulfill({status:201,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,path:"registrations/QA-NEW-123/aa123456-78ab-41cd-91ab-123456789abc.jpg"})});
    }
    if(u.pathname==="/rest/v1/rpc/register_new_employee_request" && req.method()==="POST"){
      const payload=JSON.parse(req.postData()||"{}"); traces.newRpc.push(payload);
      return route.fulfill({status:200,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,result:"PENDING",message:"تم استلام طلب QA تجريبي"})});
    }
    traces.unexpected.push(req.method()+" "+u.pathname);
    return route.abort();
  });
  const p=await context.newPage();
  const errors=[];p.on("pageerror",e=>errors.push(e.message));
  await p.goto(origin+"/register-new.html");
  assert.equal(new URL(p.url()).pathname,"/register-new.html","Direct entry redirected incorrectly");
  await p.waitForFunction(()=>document.querySelector("#connectionBadge")?.textContent?.includes("Supabase جاهز"));
  assert.equal(await p.evaluate(()=>APP_CONFIG.SUPABASE_URL),"https://"+stageHost);
  assert.equal(await p.evaluate(()=>sessionStorage.getItem("alb_portal_session_v1")),null,"New-only page must not create a portal session");
  assert.equal(await p.locator("#registerButton").isEnabled(),true);
  assert.equal(await p.locator("#existingRegistrationRoute a").getAttribute("href"),"./register-existing.html");
  await p.locator("#registrationCategory").selectOption("PERMANENT");
  await p.locator("#fullName").fill("QA SYNTHETIC NEW EMPLOYEE");
  await p.locator("#employeeId").fill("QA-NEW-123");
  await p.locator("#mobileNumber").fill("0000000000");
  await p.locator("#jobType").selectOption({label:"طبيب"});
  await p.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
  await p.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
  await p.locator("#rememberTrustedDevice").uncheck();
  await p.locator("#confirmAccuracy").check();
  await p.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await p.waitForFunction(()=>document.querySelector("#resultCard")?.classList.contains("limited"),null,{timeout:18000});
  assert.equal(traces.upload.length,1,"Expected one new-image upload");
  assert.equal(traces.newRpc.length,1,"Expected exactly one new-only registration");
  assert.equal(traces.newRpc[0].p_employee_id,"QA-NEW-123");
  assert.equal(traces.newRpc[0].p_photo_url,"registrations/QA-NEW-123/aa123456-78ab-41cd-91ab-123456789abc.jpg");
  assert.match(traces.upload[0].body,/QA-NEW-123/);
  assert.equal(traces.newRpc[0].p_device_id,null,"Remember-phone opt-out should not enroll device");
  assert.equal(traces.newRpc[0].p_registration_category,"PERMANENT");
  assert.deepEqual(traces.unexpected,[],"New route leaked traffic outside isolated Staging");
  assert.deepEqual(errors,[],"Browser JavaScript errors");
  await context.close();

  // Browser negative: a known old/registered employee ID must be stopped
  // by the backend upload eligibility check without ANY new-only RPC.
  // Entirely mocked: no real employee identity or photo is read or written.
  const deniedCtx=await browser.newContext({serviceWorkers:"block",viewport:{width:390,height:844}});
  const deniedTrace={upload:0,rpc:0,nonStage:[]};
  await deniedCtx.route("**/*",async route=>{
    const req=route.request(),u=new URL(req.url());
    if(u.origin===origin)return route.continue();
    if(turnstileMock(route,u))return;
    if(u.hostname!==stageHost){deniedTrace.nonStage.push(u.hostname);return route.abort();}
    const cors={"access-control-allow-origin":"*","access-control-allow-headers":"*",
      "access-control-allow-methods":"GET,POST,OPTIONS"};
    if(req.method()==="OPTIONS")return route.fulfill({status:204,headers:cors});
    if(u.pathname==="/functions/v1/employee-photo-upload-new"){
      deniedTrace.upload++;
      return route.fulfill({status:403,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:false,code:"EXISTING_EMPLOYEE",
          message:"الموظف مسجل مسبقًا؛ استخدم صفحة التسجيل السابقة."})});
    }
    if(u.pathname.includes("/rpc/"))deniedTrace.rpc++;
    return route.abort();
  });
  const rejected=await deniedCtx.newPage();
  const deniedErrors=[];rejected.on("pageerror",e=>deniedErrors.push(e.message));
  await rejected.goto(origin+"/register-new.html");
  await rejected.locator("#registrationCategory").selectOption("PERMANENT");
  await rejected.locator("#fullName").fill("QA EXISTING EMPLOYEE REJECTION");
  await rejected.locator("#employeeId").fill("1234567");
  await rejected.locator("#mobileNumber").fill("0000000000");
  await rejected.locator("#jobType").selectOption({label:"طبيب"});
  await rejected.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
  await rejected.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
  await rejected.locator("#confirmAccuracy").check();
  await rejected.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await rejected.waitForFunction(()=>
    document.querySelector("#resultCard")?.classList.contains("denied") &&
    !document.querySelector("#registerForm")?.inert &&
    !document.querySelector("#registerButton")?.disabled,null,{timeout:18000});
  assert.equal(deniedTrace.upload,1,"Expected one upload eligibility rejection");
  assert.equal(deniedTrace.rpc,0,"Existing employee rejection must NEVER call new-only registration");
  assert.equal(await rejected.locator("#employeeId").inputValue(),"1234567",
    "A rejected registration must preserve all user input");
  assert.deepEqual(deniedTrace.nonStage,[],"Existing flow leaked to Production/other host");
  assert.deepEqual(deniedErrors,[],"Unexpected browser error on denied upload");
  await deniedCtx.close();

  // Browser retry: a temporarily failing RPC should not upload a second
  // private photo object when the same QA employee and File are retried.
  const retryCtx=await browser.newContext({serviceWorkers:"block"});
  const retryTrace={upload:0,rpc:[],leaked:[]};
  await retryCtx.route("**/*",async route=>{
    const req=route.request(),u=new URL(req.url());
    if(u.origin===origin)return route.continue();
    if(turnstileMock(route,u))return;
    if(u.hostname!==stageHost){retryTrace.leaked.push(u.hostname);return route.abort();}
    const cors={"access-control-allow-origin":"*","access-control-allow-headers":"*",
      "access-control-allow-methods":"GET,POST,OPTIONS"};
    if(req.method()==="OPTIONS")return route.fulfill({status:204,headers:cors});
    if(u.pathname==="/functions/v1/employee-photo-upload-new" && req.method()==="POST"){
      retryTrace.upload++;
      return route.fulfill({status:201,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,path:"registrations/QA-RETRY-123/aa123456-78ab-41cd-91ab-123456789abc.jpg"})});
    }
    if(u.pathname==="/rest/v1/rpc/register_new_employee_request" && req.method()==="POST"){
      retryTrace.rpc.push(JSON.parse(req.postData()||"{}"));
      if(retryTrace.rpc.length===1)
        return route.fulfill({status:503,contentType:"application/json",headers:cors,
          body:JSON.stringify({code:"PGRST000",message:"QA synthetic transient outage"})});
      return route.fulfill({status:200,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,result:"PENDING",message:"QA simulated retry succeeded"})});
    }
    retryTrace.leaked.push(req.method()+" "+u.pathname);
    return route.abort();
  });
  const retried=await retryCtx.newPage();
  const retryErrors=[];retried.on("pageerror",e=>retryErrors.push(e.message));
  await retried.goto(origin+"/register-new.html");
  await retried.locator("#registrationCategory").selectOption("PERMANENT");
  await retried.locator("#fullName").fill("QA RETRY");
  await retried.locator("#employeeId").fill("QA-RETRY-123");
  await retried.locator("#mobileNumber").fill("0000000000");
  await retried.locator("#jobType").selectOption({label:"طبيب"});
  await retried.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
  await retried.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
  await retried.locator("#rememberTrustedDevice").uncheck();
  await retried.locator("#confirmAccuracy").check();
  await retried.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await retried.waitForFunction(()=>
    document.querySelector("#resultCard")?.classList.contains("denied") &&
    !document.querySelector("#registerForm")?.inert &&
    !document.querySelector("#registerButton")?.disabled,null,{timeout:18000});
  assert.equal(retryTrace.rpc.length,1,"First attempt must reach new-only RPC once");
  assert.equal(retryTrace.upload,1,"First attempt must upload once");
  await retried.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await retried.waitForFunction(()=>
    document.querySelector("#resultCard")?.classList.contains("limited") &&
    !document.querySelector("#registerForm")?.inert,null,{timeout:18000});
  assert.equal(retryTrace.upload,1,"Same-file retry must reuse already-uploaded QA photo");
  assert.equal(retryTrace.rpc.length,2,"Retry must call new-only RPC exactly once more");
  assert.equal(retryTrace.rpc[0].p_employee_id,retryTrace.rpc[1].p_employee_id);
  assert.equal(retryTrace.rpc[0].p_photo_url,retryTrace.rpc[1].p_photo_url);
  assert.equal(retryTrace.rpc[0].p_device_token,retryTrace.rpc[1].p_device_token,
    "Same QA pending owner proof must persist across RPC retry");
  assert.deepEqual(retryTrace.leaked,[],"Retry made an unexpected external call");
  assert.deepEqual(retryErrors,[],"Unexpected browser errors on QA retry");
  await retryCtx.close();

  // Real Chromium DOM + localStorage hand-off: approval should not require
  // re-entering the applicant's fields when a trusted device was requested.
  // ALL HTTP is intercepted locally; legacy portal's Production-bound RPC is
  // *mocked* (never sent). This tests browser behavior, not real admin approval.
  const trustCtx=await browser.newContext({serviceWorkers:"block",viewport:{width:390,height:844}});
  const trustTrace={upload:0,register:0,fastLogin:0,unexpected:[]};
  let storedDevice=null;
  await trustCtx.route("**/*",async route=>{
    const req=route.request(),u=new URL(req.url());
    if(u.origin===origin)return route.continue();
    if(turnstileMock(route,u))return;
    const cors={"access-control-allow-origin":"*",
      "access-control-allow-headers":"*","access-control-allow-methods":"GET,POST,OPTIONS"};
    if(req.method()==="OPTIONS" && u.hostname===stageHost)return route.fulfill({status:204,headers:cors});
    if(u.hostname===stageHost&&u.pathname==="/functions/v1/employee-photo-upload-new"&&req.method()==="POST"){
      trustTrace.upload++;
      return route.fulfill({status:201,headers:cors,contentType:"application/json",
        body:JSON.stringify({ok:true,path:"registrations/QA-TRUST-123/aa123456-78ab-41cd-91ab-123456789abc.jpg"})});
    }
    if(u.hostname===stageHost&&u.pathname==="/rest/v1/rpc/register_new_employee_request"&&req.method()==="POST"){
      trustTrace.register++;
      storedDevice=JSON.parse(req.postData()||"{}");
      return route.fulfill({status:200,headers:cors,contentType:"application/json",
        body:JSON.stringify({ok:true,result:"PENDING",message:"QA test pending approval"})});
    }
    // Existing portal.html uses Production as its configured RPC host.
    // Here we intercept that request and return simulated APPROVED only.
    // Never contact the actual Production service or any real employee.
    if(u.hostname===productionHost&&u.pathname==="/rest/v1/rpc/trusted_device_profile_login"&&req.method()==="POST"){
      trustTrace.fastLogin++;
      const args=JSON.parse(req.postData()||"{}");
      assert.equal(args.p_device_token,storedDevice?.p_device_token,
        "Approved fast login must reuse the exact original token");
      assert.equal(args.p_device_id,storedDevice?.p_device_id,
        "Approved fast login must reuse same registered device ID");
      return route.fulfill({status:200,headers:cors,contentType:"application/json",
        body:JSON.stringify({ok:true,profile:{
          employee_id:"QA-TRUST-123",mobile_number:"0000000000",
          full_name:"QA TRUSTED DEVICE",status:"APPROVED"
        }})});
    }
    trustTrace.unexpected.push(req.method()+" "+u.hostname+u.pathname);
    return route.abort();
  });
  const trusted=await trustCtx.newPage();
  await trusted.goto(origin+"/register-new.html");
  await trusted.locator("#registrationCategory").selectOption("PERMANENT");
  await trusted.locator("#fullName").fill("QA TRUSTED DEVICE");
  await trusted.locator("#employeeId").fill("QA-TRUST-123");
  await trusted.locator("#mobileNumber").fill("0000000000");
  await trusted.locator("#jobType").selectOption({label:"طبيب"});
  await trusted.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
  await trusted.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
  assert.equal(await trusted.locator("#rememberTrustedDevice").isChecked(),true);
  await trusted.locator("#confirmAccuracy").check();
  await trusted.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await trusted.waitForFunction(()=>
    document.querySelector("#resultCard")?.classList.contains("limited")&&
    !document.querySelector("#registerForm")?.inert,null,{timeout:18000});
  assert.equal(trustTrace.upload,1);
  assert.equal(trustTrace.register,1);
  assert.equal(storedDevice.p_employee_id,"QA-TRUST-123");
  assert.equal(storedDevice.p_registration_category,"PERMANENT");
  assert.match(storedDevice.p_device_token,/^[0-9a-f]{96}$/);
  assert.ok(storedDevice.p_device_id?.startsWith("mobile-"));
  const saved=await trusted.evaluate(()=>({
    token:localStorage.getItem("erp_trusted_device_token_v1"),
    id:localStorage.getItem("erp_trusted_device_id_v1"),
    pending:JSON.parse(localStorage.getItem("erp_pending_registration_v1")||"null"),
    session:sessionStorage.getItem("alb_portal_session_v1")
  }));
  assert.equal(saved.token,storedDevice.p_device_token);
  assert.equal(saved.id,storedDevice.p_device_id);
  assert.equal(saved.pending?.employee_id,"QA-TRUST-123");
  assert.equal(saved.pending?.token,storedDevice.p_device_token);
  assert.equal(saved.session,null,"Registration must not silently log in the employee");

  // Navigate to *unchanged* portal.html in the same browser. With a mock
  // server-side approval, fastTrustedLogin must not ask for ID or phone.
  await trusted.goto(origin+"/portal.html");
  assert.equal(new URL(trusted.url()).pathname,"/portal.html");
  assert.equal(await trusted.locator("#employeeId").inputValue(),"");
  assert.equal(await trusted.locator("#employeePhone").inputValue(),"");
  await trusted.evaluate(()=>{void openEmployeeProfile();});
  await trusted.waitForURL(url=>url.pathname.endsWith("/profile.html"),{timeout:18000});
  const portalSession=await trusted.evaluate(()=>
    JSON.parse(sessionStorage.getItem("alb_portal_session_v1")||"null"));
  assert.equal(portalSession?.role,"EMPLOYEE");
  assert.equal(portalSession?.employeeId,"QA-TRUST-123");
  assert.equal(portalSession?.mobileNumber,"0000000000");
  assert.equal(trustTrace.fastLogin,1,
    "No duplicate manual login should be needed after simulated approval");
  assert.equal(trustTrace.upload,1,"No photo upload during fast-device login");
  assert.equal(trustTrace.register,1,"No repeated registration after approval");
  // Profile's own extra network calls (if any) are separately aborted;
  // no Production request has ever left this browser.
  await trustCtx.close();

  // A second registration on a browser already trusted for a different
  // employee must NOT revoke or overwrite that employee's local device.
  // Check blocked opt-in BEFORE upload, followed by safe opt-out success.
  const oldCtx=await browser.newContext({serviceWorkers:"block"});
  const oldTrace={upload:0,newRpc:0,unexpected:[]};
  await oldCtx.route("**/*",async route=>{
    const req=route.request(),u=new URL(req.url());
    if(u.origin===origin)return route.continue();
    if(turnstileMock(route,u))return;
    if(u.hostname!==stageHost){oldTrace.unexpected.push(u.hostname);return route.abort();}
    const cors={"access-control-allow-origin":"*","access-control-allow-headers":"*",
      "access-control-allow-methods":"GET,POST,OPTIONS"};
    if(req.method()==="OPTIONS")return route.fulfill({status:204,headers:cors});
    if(u.pathname==="/functions/v1/employee-photo-upload-new"&&req.method()==="POST"){
      oldTrace.upload++;
      return route.fulfill({status:201,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,path:"registrations/QA-SECOND-123/aa123456-78ab-41cd-91ab-123456789abc.jpg"})});
    }
    if(u.pathname==="/rest/v1/rpc/register_new_employee_request"&&req.method()==="POST"){
      oldTrace.newRpc++;
      const args=JSON.parse(req.postData()||"{}");
      assert.equal(args.p_employee_id,"QA-SECOND-123");
      assert.equal(args.p_device_id,null,"Opt-out must not enroll the shared browser");
      return route.fulfill({status:200,contentType:"application/json",headers:cors,
        body:JSON.stringify({ok:true,result:"PENDING",message:"QA opt-out accepted"})});
    }
    oldTrace.unexpected.push(req.method()+" "+u.pathname);
    return route.abort();
  });
  const oldPage=await oldCtx.newPage();
  await oldPage.goto(origin+"/register-new.html");
  const oldToken="b".repeat(96),oldDevice="mobile-previous-employee";
  const previousContext={employee_id:"QA-PREVIOUS-EMPLOYEE",device_id:oldDevice,token:oldToken};
  await oldPage.evaluate(({token,device,context})=>{
    localStorage.setItem("erp_trusted_device_token_v1",token);
    localStorage.setItem("erp_trusted_device_id_v1",device);
    localStorage.setItem("erp_pending_registration_v1",JSON.stringify(context));
  },{token:oldToken,device:oldDevice,context:previousContext});
  await oldPage.locator("#registrationCategory").selectOption("PERMANENT");
  await oldPage.locator("#fullName").fill("QA SECOND APPLICANT");
  await oldPage.locator("#employeeId").fill("QA-SECOND-123");
  await oldPage.locator("#mobileNumber").fill("0000000000");
  await oldPage.locator("#jobType").selectOption({label:"طبيب"});
  await oldPage.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
  await oldPage.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
  await oldPage.locator("#confirmAccuracy").check();
  assert.equal(await oldPage.locator("#rememberTrustedDevice").isChecked(),true);
  await oldPage.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await oldPage.waitForFunction(()=>document.querySelector("#resultCard")?.classList.contains("denied"),null,{timeout:18000});
  assert.equal(oldTrace.upload,0,"Existing trusted browser must be blocked before photo upload");
  assert.equal(oldTrace.newRpc,0,"Existing trusted browser must not submit with opt-in");
  const beforeOptOut=await oldPage.evaluate(()=>({
    token:localStorage.getItem("erp_trusted_device_token_v1"),
    id:localStorage.getItem("erp_trusted_device_id_v1"),
    pending:localStorage.getItem("erp_pending_registration_v1")
  }));
  assert.equal(beforeOptOut.token,oldToken);
  assert.equal(beforeOptOut.id,oldDevice);
  assert.deepEqual(JSON.parse(beforeOptOut.pending),previousContext);
  await oldPage.locator("#rememberTrustedDevice").uncheck();
  await oldPage.locator("#registerForm").evaluate(f=>f.requestSubmit());
  await oldPage.waitForFunction(()=>
    document.querySelector("#resultCard")?.classList.contains("limited")&&
    !document.querySelector("#registerForm")?.inert,null,{timeout:18000});
  assert.equal(oldTrace.upload,1,"Opt-out should upload new synthetic photo exactly once");
  assert.equal(oldTrace.newRpc,1,"Opt-out should register synthetic applicant exactly once");
  const afterOptOut=await oldPage.evaluate(()=>({
    token:localStorage.getItem("erp_trusted_device_token_v1"),
    id:localStorage.getItem("erp_trusted_device_id_v1"),
    pending:localStorage.getItem("erp_pending_registration_v1")
  }));
  assert.equal(afterOptOut.token,oldToken,"Opt-out deleted earlier employee's token");
  assert.equal(afterOptOut.id,oldDevice,"Opt-out deleted earlier employee's device ID");
  assert.deepEqual(JSON.parse(afterOptOut.pending),previousContext,
    "Opt-out modified earlier employee's pending context");
  assert.deepEqual(oldTrace.unexpected,[],"Unexpected host in shared-browser QA");
  await oldCtx.close();

  // PENDING Recovery on fresh page reload with EMPTY file input
  const reloadCtx = await browser.newContext({ serviceWorkers: "block", viewport: { width: 390, height: 844 } });
  const reloadTrace = { upload: 0, rpc: [] };
  await reloadCtx.route("**/*", async route => {
    const req = route.request(), u = new URL(req.url());
    if (u.origin === origin) return route.continue();
    if (turnstileMock(route, u)) return;
    const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "GET,POST,OPTIONS" };
    if (req.method() === "OPTIONS") return route.fulfill({ status: 204, headers: cors });
    if (u.pathname === "/functions/v1/employee-photo-upload-new" && req.method() === "POST") {
      reloadTrace.upload++;
      return route.fulfill({ status: 201, contentType: "application/json", headers: cors,
        body: JSON.stringify({ ok: true, path: "registrations/QA-RELOAD-123/img-reload-123.jpg" }) });
    }
    if (u.pathname === "/rest/v1/rpc/register_new_employee_request" && req.method() === "POST") {
      const payload = JSON.parse(req.postData() || "{}");
      reloadTrace.rpc.push(payload);
      return route.fulfill({ status: 200, contentType: "application/json", headers: cors,
        body: JSON.stringify({ ok: true, result: "PENDING", message: "طلب معلق مستعاد" }) });
    }
    return route.abort();
  });
  const rp = await reloadCtx.newPage();
  await rp.goto(origin + "/register-new.html");
  await rp.locator("#registrationCategory").selectOption("PERMANENT");
  await rp.locator("#fullName").fill("QA RELOAD TEST");
  await rp.locator("#employeeId").fill("QA-RELOAD-123");
  await rp.locator("#mobileNumber").fill("0791111111");
  await rp.locator("#jobType").selectOption({ label: "طبيب" });
  await rp.locator("#department").selectOption({ label: "الإسعاف والطوارئ (DRS/NRS/EMT/MLT)" });
  await rp.locator("#employeePhoto").setInputFiles({ name: "qa.png", mimeType: "image/png", buffer: png });
  await rp.locator("#rememberTrustedDevice").uncheck();
  await rp.locator("#confirmAccuracy").check();
  await rp.locator("#registerForm").evaluate(f => f.requestSubmit());
  await rp.waitForFunction(() => document.querySelector("#resultCard")?.classList.contains("limited"), null, { timeout: 18000 });
  assert.equal(reloadTrace.upload, 1, "First submission uploads photo");
  assert.equal(reloadTrace.rpc.length, 1);
  assert.equal(reloadTrace.rpc[0].p_device_id, null, "Device saving must be disabled on first submit");

  // Verify localStorage has NO pending context (since rememberDevice was false)
  const localPendingBefore = await rp.evaluate(() => localStorage.getItem("erp_pending_registration_v1"));
  assert.equal(localPendingBefore, null, "localStorage must NOT contain pending registration when rememberDevice is unchecked");

  // Now simulate a full browser page reload (where Chromium empties <input type="file">)
  await rp.reload();
  await rp.waitForFunction(() => document.querySelector("#connectionBadge")?.textContent?.includes("Supabase جاهز"));

  // Check that employeePhoto file input is indeed empty after reload
  const fileCount = await rp.locator("#employeePhoto").evaluate(el => el.files.length);
  assert.equal(fileCount, 0, "Chromium must have empty file input after reload");

  // User edits mobile number and re-submits without selecting any photo file and with rememberDevice UNCHECKED
  await rp.locator("#registrationCategory").selectOption("PERMANENT");
  await rp.locator("#fullName").fill("QA RELOAD TEST");
  await rp.locator("#employeeId").fill("QA-RELOAD-123");
  await rp.locator("#mobileNumber").fill("0792222222");
  await rp.locator("#jobType").selectOption({ label: "طبيب" });
  await rp.locator("#department").selectOption({ label: "الإسعاف والطوارئ (DRS/NRS/EMT/MLT)" });
  await rp.locator("#rememberTrustedDevice").uncheck();
  await rp.locator("#confirmAccuracy").check();
  await rp.locator("#registerForm").evaluate(f => f.requestSubmit());
  await rp.waitForFunction(() => document.querySelector("#resultCard")?.classList.contains("limited"), null, { timeout: 18000 });

  assert.equal(reloadTrace.upload, 1, "RELOAD RECOVERY: Must NOT upload photo a second time!");
  assert.equal(reloadTrace.rpc.length, 2, "Must submit update to PENDING request");
  assert.equal(reloadTrace.rpc[1].p_photo_url, "registrations/QA-RELOAD-123/img-reload-123.jpg",
    "Must reuse previously linked photo URL without requiring re-selection");
  assert.equal(reloadTrace.rpc[1].p_device_id, null, "Device saving must remain disabled on reload retry");
  const localPendingAfter = await rp.evaluate(() => localStorage.getItem("erp_pending_registration_v1"));
  assert.equal(localPendingAfter, null, "localStorage must remain empty across recovery when rememberDevice is unchecked");
  await reloadCtx.close();

  // QA source-of-truth for accepted ID shapes: employee identifiers are
  // NOT restricted to 5-8 digit Ministry IDs or 10-digit national IDs.
  // All HTTP is local or mocked, no Storage object or live employee created.
  const {createHash}=require("node:crypto");
  const acceptedIdShapes=[
    {id:"12345",category:"PERMANENT",kind:"EMPLOYEE"},
    {id:"12345678",category:"PERMANENT",kind:"EMPLOYEE"},
    {id:"1234567890",category:"TEMPORARY",kind:"NATIONAL"},
    {id:"QA/NEW-1112",category:"PERMANENT",kind:"EMPLOYEE"}
  ];
  for(const config of acceptedIdShapes){
    const idCtx=await browser.newContext({serviceWorkers:"block",viewport:{width:390,height:844}});
    const calls={upload:0,rpc:0,unexpected:[],payload:null,formId:false};
    const folder=/^[A-Za-z0-9_-]{1,32}$/.test(config.id)?config.id:
      createHash("sha256").update("employee-photo-folder-v1:"+config.id).digest("hex");
    const expectedPath="registrations/"+folder+"/aa123456-78ab-41cd-91ab-123456789abc.jpg";
    await idCtx.route("**/*",async route=>{
      const req=route.request(),u=new URL(req.url());
      if(u.origin===origin)return route.continue();
      if(turnstileMock(route,u))return;
      if(u.hostname!==stageHost){calls.unexpected.push("DISALLOWED_HOST:"+u.hostname);return route.abort();}
      const cors={"access-control-allow-origin":"*","access-control-allow-headers":"*",
        "access-control-allow-methods":"GET,POST,OPTIONS"};
      if(req.method()==="OPTIONS")return route.fulfill({status:204,headers:cors});
      if(u.pathname==="/functions/v1/employee-photo-upload-new"&&req.method()==="POST"){
        calls.upload++;
        calls.formId=Buffer.from(req.postDataBuffer()||[]).includes(Buffer.from(config.id));
        return route.fulfill({status:201,contentType:"application/json",headers:cors,
          body:JSON.stringify({ok:true,path:expectedPath})});
      }
      if(u.pathname==="/rest/v1/rpc/register_new_employee_request"&&req.method()==="POST"){
        calls.rpc++;calls.payload=JSON.parse(req.postData()||"{}");
        return route.fulfill({status:200,contentType:"application/json",headers:cors,
          body:JSON.stringify({ok:true,result:"PENDING",message:"QA synthetic ID-shape acceptance"})});
      }
      calls.unexpected.push(req.method()+" "+u.pathname);
      return route.abort();
    });
    const idPage=await idCtx.newPage(),errors=[];
    idPage.on("pageerror",e=>errors.push(e.message));
    await idPage.goto(origin+"/register-new.html");
    await idPage.locator("#registrationCategory").selectOption(config.category);
    if(config.category==="TEMPORARY"){
      await idPage.locator("#employeeIdType").selectOption(config.kind);
      await idPage.locator("#specialty").selectOption({label:"ENT"});
      await idPage.locator("#affiliatedEntity").selectOption({label:"أمن"});
    } else {
      await idPage.locator("#jobType").selectOption({label:"طبيب"});
      await idPage.locator("#department").selectOption({label:"الإسعاف والطوارئ (DRS/NRS/EMT/MLT)"});
    }
    await idPage.locator("#fullName").fill("QA ID SHAPE SYNTHETIC");
    await idPage.locator("#employeeId").fill(config.id);
    await idPage.locator("#mobileNumber").fill("0000000000");
    await idPage.locator("#employeePhoto").setInputFiles({name:"qa.png",mimeType:"image/png",buffer:png});
    await idPage.locator("#rememberTrustedDevice").uncheck();
    await idPage.locator("#confirmAccuracy").check();
    await idPage.locator("#registerForm").evaluate(f=>f.requestSubmit());
    await idPage.waitForFunction(()=>document.querySelector("#resultCard")?.classList.contains("limited"),null,{timeout:18000});
    assert.equal(calls.upload,1,"Each synthetic ID shape should upload once: "+config.id);
    assert.equal(calls.rpc,1,"Each synthetic ID shape should register once: "+config.id);
    assert.equal(calls.formId,true,"Multipart upload lost the exact ID: "+config.id);
    assert.equal(calls.payload?.p_employee_id,config.id);
    assert.equal(calls.payload?.p_photo_url,expectedPath,"New folder derivation mismatch: "+config.id);
    assert.equal(calls.payload?.p_registration_category,config.category);
    assert.equal(calls.payload?.p_device_id,null,"New ID shape test must never enroll a device");
    assert.deepEqual(calls.unexpected,[],"New ID shape leaked a remote call");
    assert.deepEqual(errors,[],"Browser error for synthetic ID shape: "+config.id);
    await idCtx.close();
  }

  // Exercise the EXACT existing admin dashboard approval handler inside
  // real Chromium. This is a controlled UI + mocked Supabase RPC contract,
  // never a real admin JWT/session or a write to Staging/Production.
  const adminHtml=fs.readFileSync(path.join(root,"admin_dashboard.html"),"utf8");
  const adminFnStart=adminHtml.indexOf("    async function updateRegistration(id, status) {");
  const adminFnEnd=adminHtml.indexOf("\n    function escapeAttr(value)",adminFnStart);
  assert(adminFnStart>0&&adminFnEnd>adminFnStart,
    "Original admin dashboard approval handler unavailable");
  const adminFunctionSource=adminHtml.slice(adminFnStart,adminFnEnd);
  assert(adminFunctionSource.includes('supabaseClient.rpc("admin_update_registration_status"'));
  const adminCtx=await browser.newContext({serviceWorkers:"block"});
  const adminNetwork=[];
  await adminCtx.route("**/*",route=>{
    adminNetwork.push(route.request().url());
    return route.abort();
  });
  const adminPage=await adminCtx.newPage();
  await adminPage.setContent(`<main><button id="approve" onclick="updateRegistration('qa-registration-id','APPROVED')">Approve</button><button id="reject" onclick="updateRegistration('qa-registration-id','REJECTED')">Reject</button><output id="status">PENDING</output></main>`);
  await adminPage.addScriptTag({content:`
    var adminState={requests:[],toasts:[],refresh:0,audit:0,allow:false,status:"PENDING"};
    function confirm(){return true;}
    function showToast(text,kind){adminState.toasts.push({text,kind});}
    async function loadRegistrations(){adminState.refresh++;}
    async function loadAudit(){adminState.audit++;}
    var supabaseClient={rpc:async (name,args)=>{
      adminState.requests.push({name,args});
      if(name!=="admin_update_registration_status"||
         args.p_registration_id!=="qa-registration-id")
        return {data:null,error:{message:"Wrong QA id"}};
      if(!adminState.allow)return {data:{ok:false,message:"ليس لديك صلاحية الموافقة"},error:null};
      adminState.status=args.p_status;
      document.querySelector("#status").textContent=adminState.status;
      return {data:{ok:true,message:"QA simulated admin decision"},error:null};
    }};
  `+adminFunctionSource});
  await adminPage.locator("#approve").click();
  const firstDenial=await adminPage.evaluate(()=>adminState);
  assert.equal(firstDenial.status,"PENDING","Unprivileged admin must not approve");
  assert.equal(firstDenial.refresh,0,"Unauthorized approval must not refresh status");
  assert.equal(firstDenial.audit,0);
  assert(firstDenial.toasts.some(t=>t.kind==="error"));
  await adminPage.evaluate(()=>{adminState.allow=true;});
  await adminPage.locator("#approve").click();
  const approved=await adminPage.evaluate(()=>({
    status:adminState.status,requests:adminState.requests,refresh:adminState.refresh,
    audit:adminState.audit,toast:adminState.toasts.at(-1)
  }));
  assert.equal(approved.status,"APPROVED");
  assert.equal(approved.requests[1].name,"admin_update_registration_status");
  assert.deepEqual(approved.requests[1].args,{
    p_registration_id:"qa-registration-id",p_status:"APPROVED"
  });
  assert.equal(approved.refresh,1);
  assert.equal(approved.audit,1);
  assert.equal(approved.toast.kind,"ok");
  await adminPage.locator("#reject").click();
  const rejectedByAdmin=await adminPage.evaluate(()=>({
    status:adminState.status,last:adminState.requests.at(-1),refresh:adminState.refresh,audit:adminState.audit
  }));
  assert.equal(rejectedByAdmin.status,"REJECTED");
  assert.equal(rejectedByAdmin.last.args.p_status,"REJECTED");
  assert.equal(rejectedByAdmin.refresh,2);
  assert.equal(rejectedByAdmin.audit,2);
  assert.deepEqual(adminNetwork,[],"Isolated admin simulator attempted external network traffic");
  await adminCtx.close();

  // Independently test original Production hostname with ALL remote requests
  // blocked: new-only form must disable itself before it could send any data.
  const prod=await browser.newContext({serviceWorkers:"block"});
  let externalCalls=[];
  await prod.route("**/*",async route=>{
    const request=route.request(),url=new URL(request.url());
    if(url.hostname!== "albashir-stone-karag.vercel.app"){externalCalls.push(url.hostname);return route.abort();}
    const name=decodeURIComponent(url.pathname.replace(/^\//,""))||"index.html";
    const f=path.resolve(root,name);
    if(!f.startsWith(root+path.sep))return route.fulfill({status:403,body:"Denied"});
    try {
      const body=fs.readFileSync(f);
      return route.fulfill({status:200,body,contentType:name.endsWith(".html")?"text/html":name.endsWith(".js")?"text/javascript":"application/octet-stream"});
    }catch{return route.fulfill({status:404,body:"Not Found"});}
  });
  const page=await prod.newPage();
  await page.goto("https://albashir-stone-karag.vercel.app/register-new.html");
  await page.waitForFunction(()=>document.querySelector("#registerButton")?.disabled===true);
  assert.equal(await page.evaluate(()=>APP_CONFIG.SUPABASE_URL),"");
  assert.equal(await page.evaluate(()=>sessionStorage.getItem("alb_portal_session_v1")),null,"Disabled page must not create Production onboarding session");
  assert.equal(await page.evaluate(()=>APP_CONFIG.SUPABASE_ANON_KEY),"");
  assert.equal(await page.locator("#registerForm").evaluate(el=>el.inert),true);
  assert.equal(externalCalls.length,0,"Production-route page attempted external requests");
  await prod.close();
  console.log("PASS direct new-only browser form + mocked Stage JPEG upload/RPC; old URLs untouched; Production host fail-closed; no live network writes");
 }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(e=>{console.error(e);process.exitCode=1});
