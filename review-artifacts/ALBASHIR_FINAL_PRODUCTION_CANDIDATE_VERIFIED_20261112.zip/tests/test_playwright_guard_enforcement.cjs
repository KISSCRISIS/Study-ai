/**
 * test_playwright_guard_enforcement.cjs
 * Verifies that the Playwright Production Guard traps Production requests,
 * logs the attempted URL, and fails the test as required by Phase 1.
 */
const fs = require("node:fs");
const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const { installProductionGuard, PROD_HOSTS } = require("./playwright-production-guard.cjs");

(async () => {
  console.log("================================================================================");
  console.log("STARTING PLAYWRIGHT MANDATORY PRODUCTION GUARD VERIFICATION");
  console.log("================================================================================");

  const chromePath = fs.existsSync('C:/Users/USER/AppData/Local/ms-playwright/chromium-1254/chrome-win64/chrome.exe') ? 'C:/Users/USER/AppData/Local/ms-playwright/chromium-1254/chrome-win64/chrome.exe' : undefined;
  const browser = await chromium.launch({ headless: true, executablePath: chromePath });

  try {
    // 1. Verify legitimate local navigation passes
    console.log("[TEST 1] Legitimate local navigation...");
    const ctx1 = await browser.newContext({ serviceWorkers: "block" });
    installProductionGuard(ctx1);
    const p1 = await ctx1.newPage();
    await p1.goto("about:blank");
    assert.equal(p1.url(), "about:blank");
    console.log("  ✅ PASS: Local about:blank navigation allowed cleanly");
    await ctx1.close();

    // 2. Verify attempted request to Supabase Production triggers TEST FAILED
    console.log("[TEST 2] Trapping Supabase Production fetch attempt and verifying immediate test failure...");
    let caughtAssertion = null;
    const originalUncaught = process.listeners("unhandledRejection");
    process.removeAllListeners("unhandledRejection");
    process.once("unhandledRejection", (reason) => {
      caughtAssertion = reason;
    });

    const ctx2 = await browser.newContext({ serviceWorkers: "block" });
    const guard2 = installProductionGuard(ctx2);
    const p2 = await ctx2.newPage();
    await p2.goto("about:blank");

    try {
      await p2.evaluate(async () => {
        try {
          await fetch("https://qinsfvlspdticposbvst.supabase.co/rest/v1/employee_registrations", { method: "GET" });
        } catch {}
      });
    } catch {}

    // Give microtask queue a tick
    await new Promise(r => setTimeout(r, 100));

    assert(caughtAssertion !== null, "Guard must trigger assertion failure on production request");
    assert(caughtAssertion.message.includes("TEST FAILED: Playwright test attempted connection to Production"), "Must contain exact TEST FAILED message");
    assert(caughtAssertion.message.includes("qinsfvlspdticposbvst.supabase.co"), "Must log exact production URL");
    console.log("  ✅ PASS: Verified TEST FAILED assertion thrown with URL:", guard2.getViolations()[0].url);
    await ctx2.close();

    // 3. Verify attempted request to Vercel Production triggers TEST FAILED
    console.log("[TEST 3] Trapping Vercel Production fetch attempt...");
    let caughtVercelAssertion = null;
    process.once("unhandledRejection", (reason) => {
      caughtVercelAssertion = reason;
    });

    const ctx3 = await browser.newContext({ serviceWorkers: "block" });
    const guard3 = installProductionGuard(ctx3);
    const p3 = await ctx3.newPage();
    await p3.goto("about:blank");

    try {
      await p3.evaluate(async () => {
        try {
          await fetch("https://albashir-stone-karag.vercel.app/portal.html", { method: "GET" });
        } catch {}
      });
    } catch {}

    await new Promise(r => setTimeout(r, 100));

    assert(caughtVercelAssertion !== null, "Guard must trigger assertion failure on Vercel production request");
    assert(caughtVercelAssertion.message.includes("albashir-stone-karag.vercel.app"), "Must log exact Vercel production URL");
    console.log("  ✅ PASS: Verified TEST FAILED assertion thrown with URL:", guard3.getViolations()[0].url);
    await ctx3.close();

    // Restore listeners
    originalUncaught.forEach(l => process.on("unhandledRejection", l));

    console.log("\n================================================================================");
    console.log("🎉 ALL PLAYWRIGHT PRODUCTION GUARD ENFORCEMENT CHECKS PASSED PERFECTLY!");
    console.log("================================================================================");
  } finally {
    await browser.close();
  }
})();
