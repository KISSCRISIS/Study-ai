# Historical material and retired branches

This archive is not an installation or deployment instruction. Dated claims describe their original review, not today's live state. Paths and external links inside snapshots may refer to the original repository layout. The current README and OPERATIONS_24_7.md take precedence. No SQL is applied by this archive.

## Files

pre-unification-20261011 retains the previous README, operating checklist, production migration/RPC mapping, architecture index, 24/7 report and offline-sync procedure. Historical schema files, migrations, canonical references and test fixtures retain their original paths because isolated regressions and historical provenance depend on them. The legacy qr_load_test_100.js tool is retained under scripts/archive and should not be run as a current acceptance procedure.

## Completed branch disposition — explicit owner approval, 2026-10-11

branch-heads-20261011.json records every retired branch head, its archive tag, ancestry and file comparisons with main at c873d6d. Four heads were fully contained in main; twenty had diverged history. Divergence does not prove missing runtime behavior, especially after squash merges/source reconciliation. No diverged branch was blindly merged. All 24 remote archive tags were created and verified against the recorded commit heads before deleting the old branch names. They preserve every commit and unique file. The verified local Git bundle also preserves the complete fetched history.

- PR #17: direct creation of new Auth accounts is an unaccepted/incomplete alternative to the current approved-employee appointment flow. Its own rollout requires additional lifecycle and hosted checks. Preserve it as a proposal; do not deploy its Edge Function or password form as cleanup.
- PR #18: earlier diagnosis/manual-entry plan is superseded by the current screen-scoped implementation and the explicitly deferred Staging alignment. Preserve the earlier plan; do not restore its old guard pages.
- PR #19: old integrated dashboard/guards/appointments branch predates the reconciled 72-file main runtime. Current reviewed pages remain authoritative. Its additional historical SQL, tests and proposals are retained in its archive tag, not silently applied or claimed equivalent to live database definitions.
- Other historical feature/security branches: preserve all source in archive tags. Current validated runtime, isolated tests and captured backend references remain authoritative; closed old branches are not upgrade instructions.

The owner explicitly approved this exact 24-branch scope and closure of PRs #17–#19. Archive verification, branch retirement and those three closures completed at 2026-10-11T14:42:15Z. main remained unchanged, and only main plus the active cleanup branch remained. No old proposal was merged or deployed. Closing does not imply every proposed feature passed or was deployed. Restore a branch with git branch <name> <recorded-sha> and git push origin <name>, or from the corresponding archive tag. A verified full-history Git bundle is retained locally outside the repository. Never remove main, archive tags or live monitoring evidence during branch cleanup.
