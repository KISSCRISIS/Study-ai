# New-only registration candidate (2026-11-11) — NO Production release

This Draft adds standalone registration pages while preserving existing
Production interfaces and APIs byte-for-byte. `register.html` and
all existing portal, profile, guard, QR, service-worker, employee-photo,
Storage/Edge and database files remain unchanged. `register-new.html`
calls only the new-first-time RPC; `register-existing.html` is a
byte-identical alias for the already-published old registration page.

Staging backend v9 passed a real 4x4 synthetic JPEG HTTP upload,
new-only PENDING registration, own-image display, signed download and
wrong-owner denial (run 43075751216). This does not establish
Production safety or end-to-end browser SSO/QR behavior.

**Hard stop for Production**:
- Production still uses its different original 15-argument registration
  RPC and has no `register_new_employee_request` endpoint.
- Legacy employee data/photos/approval status, phone, QR, trusted device,
  historical Storage policies and existing routes are immutable under
  this effort.
- An independently reviewed, first-time-only, backward-compatible
  Production backend plan with no historical data writes, snapshot
  verification, rollback and explicit authorization is required.
- The new page intentionally has no link from existing homepage/portal
  yet, so this Draft cannot be publicly activated as-is.
- Vercel Staging is SSO-protected; authenticated browser UX remains
  unverified. PR #58 remains a separate unsafe, blocked Draft.
- Do not merge to main or deploy Production.

## New-route production isolation and direct navigation fix (2026-11-11)
Read-only source inspection found two blockers in the additive page:
the original `access-control.js` directly admits onboarding only at
`/register.html`, and original `verify-shared.js` points to Production.
The new-only form now loads the existing access-control helper **without
requesting or creating a portal session**, so merely viewing the new page
never changes an existing employee/login session on any host. Backend
new-only eligibility and photo attestation remain the actual security
boundary; the original access-control script remains byte-identical. On isolated Staging/localhost
hosts only, it overrides the inherited public runtime settings with
the isolated Staging URL and publishable key. On Production and unknown
hosts, it empties both backend settings and disables the form.
The new route does not include the legacy leadership JS, which has its
own Production binding. None of the existing pages or Production systems
are modified.

## Local Playwright UI acceptance without real employee activity
`tests/new-only-ui-browser.cjs` serves the reviewed HTML locally and
intercepts all external HTTP calls. It tests unauthenticated direct
navigation, form fields, one synthetic JPEG upload/first-time RPC,
pending status, optional trusted-phone opt-out and Stage-only routing.
It also renders the exact Production hostname using in-memory mocked
responses and checks that the **new-only** form is disabled with no
backend credentials or external requests. Existing Production pages,
employee records, image objects and QR data remain untouched.

## Additional real Playwright tests — completely intercepted HTTP (2026-11-12)
The isolated GitHub Actions Chromium suite now additionally tests:
- **Existing-employee upload rejection:** a synthetic old-ID upload
  returns HTTP 403 and the browser makes **zero** new registration RPCs,
  preserving form data and never contacting Production.
- **Transient first-time registration RPC failure and safe retry:** the
  first mocked RPC returns 503; the user can retry without a second
  photo upload, reuses the exact private photo path and the same
  pending-ownership proof, and receives PENDING on the second attempt.
These are **actual browser runs with mocked Staging HTTP responses**:
zero real registration, photo/Storage/SQL writes. They are not a
substitute for authenticated, published Staging E2E/guard QR tests.

## Trusted device / zero re-entry browser hand-off (2026-11-12)
A new test runs the **actual local** standalone new-employee form with
a simulated successful PENDING registration and the remembered-device
checkbox enabled. It checks that the 96-hex ownership token,
trusted-device ID and pending context are correctly saved, **without**
silently granting an employee session. Then it opens the original
unmodified `portal.html` in the *same* Chromium localStorage context,
simulates the server's approved trusted-device response and verifies
the existing fast-login button enters `profile.html` without
re-entering employee ID or phone, re-registering or re-uploading.
**Every external HTTP call is intercepted or aborted; even the portal's
Production-configured RPC is fulfilled in-memory, never sent.**
The test is **not** evidence of a real admin approval or actual
Production/Staging browser E2E. No live employee/Storage data is touched.

## Previous employee trusted-browser protection — hard negative test
A source audit identified a separate **local browser-state hazard**:
the new-only page's earlier opt-out path could call the old shared
`clearTrustedDeviceToken()` and erase another employee's saved login
and device ID on a reused browser. Opt-in on that browser could also
overwrite the older employee's token. This is now fixed **only inside
the additive new-only registration page**:
- When an existing trusted token belongs to another pending/legacy
  identity, new-device opt-in stops BEFORE modifying browser storage
  or sending photo/RPC data; it asks the user to opt out or use another
  dedicated device.
- A new applicant who unchecks device enrollment may register, but the
  page never erases an older employee's trusted token, device ID or
  saved pending context.
- Same-applicant retry and first-device opt-in remain supported.
Chromium QA preloads a **fictional old employee token** (no real user),
checks zero photo/RPC calls on conflicting opt-in, then checks opt-out
success and byte-identical previous localStorage values. Every remote
request is mocked/blocked. The original portal, shared helpers, old
employee login/registration and Production data are unchanged.

## New identifier compatibility: actual Chromium form validation (2026-11-12)
Four **fully mocked** isolated local Playwright browser cases assert that
the first-time registration page accepts both typical 5- and 8-digit
Ministry employee IDs, a 10-digit national ID for a temporary registrant,
and a *new-only* irregular identifier containing a slash. The upload
and new-only RPC receive the exact unchanged original identifier, while
the expected SHA-256-derived folder is checked for the irregular ID.
No old employee ID is rewritten, normalized to a new ID, or rejected
by the untouched historical registration page. All external HTTP is
intercepted, including Production, so these tests do not authorize
real-world identifier eligibility or Production release. The backend
remains the final authoritative validator.

## Actual admin dashboard approval handler exercised in local Chromium
A new additional Playwright test extracts the exact unchanged
`updateRegistration(id,status)` handler from `admin_dashboard.html`
and runs it in a browser with a **fully mocked** Supabase client.
It validates a denied authorization leaves PENDING untouched with
no success refresh, then a synthetic authorized APPROVED decision
sends exactly `admin_update_registration_status` with the correct
registration UUID-like QA identifier/status, triggers list and audit
refresh once, and tests the REJECTED decision separately. **No real
admin login, token, employee approval, Storage, staging SQL or external
HTTP** occurs. The original admin page and SQL functions are not edited.
The Stage/Production admin permission verification and real QR browser
flow remain release blockers.
