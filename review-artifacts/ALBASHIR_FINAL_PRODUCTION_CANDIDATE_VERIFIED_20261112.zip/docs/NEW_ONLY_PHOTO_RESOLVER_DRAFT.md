# FIRST-TIME PHOTO VIEWER — DRAFT / NONDEPLOYED
Date: 2026-11-11

This separate feature is for **newly registered employees only**.
Current Production `employee-photo-url` v2 stays byte-identical. All
original employee IDs (including legacy symbols), referenced photos,
credentials, approvals, trusted devices, and QR/guard/portal flows
remain untouched.

The independent `employee-photo-url-new` Edge route supports the five
reviewed actor types (employee, employee_device, admin, guard_device,
public_guard_session), but **only for new attested employee JPEGs**.
It first checks a service-role-only Boolean SQL attestation against
the exact original ID/path and the frozen historical cutoff, **before**
calling legacy employee/device/admin/guard credential verifiers.
It issues a 60-second private signed URL only after authorization,
exact binding and authenticated global rate-limit checks.
It accepts collision-resistant hashed folders for irregular new IDs
without changing the original IDs. No sweep, deletion or image upload
logic is present. No current employee can use this separate route.

**Production release BLOCKERS:**
- New SQL binding function is deliberately execution-LOCKED. It has NOT
  been deployed to Production or Staging.
- This new Edge function has NOT been deployed. Configuration must
  include an explicit allowed origin list; without it it fails closed.
- Five actor types exist on this Draft backend, but the old production
  admin/guard/profile photo clients still target the old v2 resolver:
  genuine staging UI integration and access controls are NOT proven.
  Never replace Production's resolver with Staging's version blindly.
- Rate-limit the credential verifier with a dedicated new-only budget
  (not the old employee upload budget) before enabling this endpoint.
- The existing new-only web form is only a QA candidate on Draft PR #61.
  It is not linked from the Production homepage, and existing profile/
  guard clients still call the legacy photo URL function.
- Signed URL proof and IDOR tests are offline/mock only in this PR;
  live preview, admin/guard and QR acceptance are still required.
- Never merge/deploy any PR without independent review, controlled
  rollback and explicit approval. No changes to current employee
  images, Storage policies or Production SQL are authorized.

## Isolated Staging SQL verification — actual PASS (rolled back)
A staging-only transaction created the new service-role photo-binding
function and tested it against existing **synthetic QA** records. Results:
new first-time employee + attested exact JPEG reference → `ok:true`;
historical QA registration photo → `ok:false`; changed path →
`ok:false`; simulated anonymous claim → `ok:false`.
The function was never committed; transaction ended `ROLLBACK`.
`STAGING_QA_NEW_ONLY_PHOTO_ROLLBACK.sql` is a guard-protected,
reproducible QA script. This tests SQL binding only, not production
deployment, real browser/QR routes or rate-limit security.

## Persistent new-only photo-view rate limit (review and Stage SQL)
The first-time-only photo reader now **requires** a service-role-only
`new_employee_photo_view_admit` RPC BEFORE checking the employee's
credentials or signing a URL. Without the RPC, the Edge fails closed.
The separate locked SQL candidate creates only
`private.new_employee_photo_view_limits`; it never touches current
employees, their images or the existing upload throttle.
Quotas: **12 attempts per employee ID / 10 minutes**, **600 aggregate
attempts / 10 minutes**. Keys contain only a SHA-256 salted-by-purpose
employee digest, not raw employee ID. Global quota cannot be bypassed
by changing client-controlled IP or employee ID; no trust is placed in
the caller's browser Origin as authentication. Row-conflict updates are
atomic; stale new-only counters are pruned at most 20 at a time.
Rate-limit rejects fail closed with HTTP 429 and generic DENIED.
Persistent rate-limit SQL remains **execution-locked** until explicit
release approval. A Staging-only transaction test in
`STAGING_QA_NEW_PHOTO_RATE_LIMIT_ROLLBACK.sql` exercises the function,
denial and grants before rollback.

**Additional isolated QA:** A future aggregate quota is simulated by setting the
synthetic new-only `global` counter to 600 inside the rollback transaction,
then checking another invented employee ID is denied. The per-ID quota
must not spill into a separate ID before the global limit. All counters
are rolled back; no historical table or photograph is modified. The
employee hash is domain-separated SHA-256, **not** a substitute for
cryptographic authentication or secret-key anonymization. This
independent endpoint must still not be deployed before an auth review.

## Nonstandard newly registered ID compatibility — isolated PostgreSQL PASS
Inside a single Stage BEGIN/ROLLBACK transaction we inserted **only a
fictional QA employee** with employee ID containing `/`, a derived
SHA-256 folder, fake private JPEG Storage metadata and a new-only
attestation row. The reviewed new-only binding returned:
`new_nonstandard_id_authorized=true`,
`old_id_wrong_photo_denied=false`,
`wrong_photo_denied=false`. The Stage transaction was rolled back.
No image bytes existed or were fetched. This proves the SQL binding
case for irregular **new** IDs, NOT that the live Production v2
photo resolver works with them. The historical employee cohort,
including legacy nonstandard IDs, remains strictly outside the new route.

## Actor adapter review — mock acceptance, no existing UI changes
The separate new-only photo resolver now supports **five** independently
verified actor types, each with the **same** post-cutover, service-only,
attested exact-photo-binding SQL gate and global/per-ID quota:
- `employee`: ID+mobile profile credential and exact registered photo.
- `employee_device`: existing trusted-device token+device ID; the
  trusted-device RPC must return the exact employee ID and photo path.
- `admin`: authenticated Supabase JWT verified with a separate
  **publishable/anon-key user-scoped client**, followed by
  `get_my_admin_profile`; no service-role-key fallback for user sessions.
- `guard_device`: existing gate device code+token verified using the
  current approved-device SQL RPC. Guard requests must supply the
  new employee ID and exact photo path.
- `public_guard_session`: 64-hex secure read capability checked by
  `resolve_public_guard_photo`; only the session-returned photo path
  may be signed, plus the new-only attestation and same employee ID.

**No claim that these are live browser tests:** specialized CI uses
negative/positive mocks for every actor, wrong owner, wrong path,
invalid admin credentials, denied/expired capabilities, quota failure
and nonstandard newly registered IDs. Existing employee-photo.js,
profile, admin pages, guard pages, QR UI and Production v2 Edge are
byte-identical and were **not** changed. New-only client routing and
real isolated Staging device/admin/QR end-to-end remain release blockers.
The new reader remains **non-deployed** until authorized.

## Live Production trusted-device return contract
Read-only RPC inspection confirmed Production
`verify_trusted_device_credentials(text,text)` returns validated
`employee_id` but **does not** return `employee_photo_url` (unlike
Staging). The isolated new-only device actor must verify trusted-device
identity using the Production-compatible payload, then require the
service-only photo-binding SQL to match the exact registered JPEG.
Do not modify the legacy trusted-device RPC or old photo paths.

## Cheap actor-shape gate before global rate-budget consumption
The new-only Edge rejects unsupported actor labels, absent admin JWT,
malformed QR read keys and absent device credentials **before** touching
the shared 600-attempt quota. This reduces trivial quota exhaustion, but
does **not** prove protection against deliberate denial of service
using forged requests with syntactically valid credentials. Deployment
remains blocked pending abuse modelling and approval.

## 2026-11-11 — Two-stage abuse mitigation (Draft; NOT deployed)
Security review identified a denial-of-service flaw in the old new-only
limit: any forged credential attempt could increment the **global 600**
signed-image quota and prevent legitimate new employees/guards from
retrieving images. The Draft now splits quota checks, without editing
any Production employee/photo/legacy code:
1. **Before identity verification:** 12 attempts/employee ID/10 minutes
   in a dedicated hashed-ID counter. Forged attempts affect ONLY the
   chosen ID and cannot consume the global signed-URL quota.
2. **Only AFTER successful credential verification and exact
   post-cutover attested JPEG SQL binding:** 600 total signed-URL attempts
   /10 minutes. It is counted immediately before issuing the URL.

Both RPCs require service_role, are execution-LOCKED, and fail closed
on database errors. The Staging rollback QA validates the split,
unauthorized callers, independent IDs, and aggregate cap. This still
does not eliminate targeted per-ID denial-of-service; further controls
and real admin/guard/QR acceptance remain mandatory before release.

## Admin bearer-header compatibility
The standalone new-only admin path now accepts a **valid JWT in the
Authorization: Bearer header** without requiring a duplicate token in
the JSON actor payload. A review found an over-escaped preflight regex
that would reject this legitimate request before verification. It has
been corrected and covered by positive/negative simulated admin tests.
This does not change any historical admin session or legacy resolver.

## Guard/QR decision binding: independent, ALLOWED-only (review only)
A rollback-only SQL test of the **existing** Staging `resolve_public_guard_photo` revealed that it returns an employee photo path for any completed QR result, including `DENIED`. Existing Production code has **not** been changed: those legacy UI/QR semantics require a separate compatibility decision. For the **new employee-only** reader, both `guard_device` and `public_guard_session` now require a dedicated 64-hex QR read capability linked to the exact newly registered approved employee and exact attested JPEG, with session and QR unexpired and **result='ALLOWED'**. A valid guard device by itself is insufficient. The new-only SQL function is service-role only and intentionally execution-locked; no migration was deployed. Admin roles must be SUPER_ADMIN or SUB_ADMIN, not any non-empty role. This is a strictly stronger new-only policy; existing guard UI routing to it requires a separate integration review. Tests include ALLOWED, DENIED, expired, wrong-photo and wrong-ID cases, and run on isolated Staging with transaction rollback.

## Historical login-rate non-interference security fix — 2026-11-12
**Confirmed from existing Stage SQL definition:** the production-compatible
`employee_profile_login` used by the isolated image Edge function
calls `is_rate_limited` and `write_security_attempt`. Previously, the
new-only photo reader checked old employee/mobile credentials **before**
checking new-only registration attestation. Requests against a known old
employee therefore could mutate the shared legacy login-attempt ledger
and possibly rate-limit their legitimate access, even though the image
URL would subsequently be denied. This violated the historical
zero-touch requirement.

The reader now validates **only the post-freeze new-employee attested
photo binding first**, *after* malformed-actor rejection and the separate
new-only per-ID quota, but before **ANY** shared
employee/device/admin/guard/QR verifier or old login-attempt logger.
Missing SQL, bad binding and old records all fail closed; old employee
records/photos are not changed. Test cases for **all five actor types**
inject a denied old-record binding and make every downstream verifier
throw if invoked. Expected: 403, zero verifier calls, zero private URL
signing, and no global signed-URL quota; service outage gives 503 without
fallback. No Production migration or Edge deployment was performed.

This does not prove the rate limiter is immune to every DoS scenario.
New-only per-ID quota can still be exhausted by a party knowing the ID;
Production release requires independent abuse review and real staging
end-to-end acceptance.
