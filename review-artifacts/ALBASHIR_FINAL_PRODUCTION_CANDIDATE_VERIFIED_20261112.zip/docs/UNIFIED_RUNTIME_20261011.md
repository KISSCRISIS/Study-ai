# Unified source reconciliation — 11 October 2026

The linked main branch was behind the owner-approved Production site. This change restores the complete 73-file application runtime from Production deployment `dpl_EVZS3QCfHvyKPF4DRAUztaJc8ae8`, including the modern dashboard without its leadership footer, administrator profiles, employee directory and appointments, registration occupations, QR/result recovery, photo handling, about/support page and Amman portal clock. Existing source files are retained; the build publishes only the explicit list in `config/runtime-files.json`.

`config/runtime-baseline.json` records SHA-256 of the release candidate assets. Seventy files remain byte-identical to the approved deployment. Three files additionally address quality findings: `admin-profile.js` uses a literal owner-path matcher and restricts requests to the configured approved Supabase origin; `service-worker.js` restricts deadline-managed requests to same-origin GET and blocks redirects; `navigation-polish.css` combines equivalent chained exclusions into selector-list notation. Both network boundaries reject credential-bearing URLs. These changes do not alter QR contracts or database permissions. Production output must match this deliberately updated candidate baseline. `.gitattributes` preserves runtime bytes, including inline CSP hashes, across Windows and Linux. Build version metadata is retained from the approved release; this reconciliation does not claim that its historical sourceHash is a new Git commit fingerprint.

## One repository, two isolated environments

- Production: `node scripts/build-public-runtime.cjs`, Vercel output `public-runtime`, project `albashir-stone-karag`.
- Staging: the same `node scripts/build-public-runtime.cjs` command with `ALBASHIR_ENVIRONMENT=staging` (or explicit `--staging`), same output directory, project `albashir-staging`. Set `ALBASHIR_SUPABASE_URL=https://adwvokwucotohwayorgx.supabase.co` and its public browser key in `ALBASHIR_SUPABASE_PUBLISHABLE_KEY` for that environment. Never supply a service-role key. Unknown environment names fail closed.
- The Staging build fails closed if the URL is not the approved Staging project or the public key is missing/invalid. It replaces only the known Production public connection strings in output, and recalculates existing guard/verify script CSP hashes after replacement. Repository source remains Production's approved baseline.
- Vercel/Git links and environment variables are not changed by this PR. Production database `qinsfvlspdticposbvst` and Staging database remain separate. No database creation, migration, deployment or data transfer is performed by the build.

## Validation and source history

The existing regression suite retains isolated SQL/RLS tests. Updated tests use the existing approved monotonic guard deadline, attribute-safe photo escaping, current about card, native dialog opening and remembered-session continuation. Generation-failure testing keeps heartbeat approval valid; heartbeat rejection is tested separately rather than confused with a generation outage.

`tests/unified-artifact.cjs` verifies exact allowlisted output/baseline, excludes extra public files, rejects Production URLs and secret/service-role keys in Staging configuration, and checks recalculated inline script hashes. Browser tests use synthetic backend responses and QR camera frames; real employee/phone and load acceptance are separate.

Open PRs 17, 18 and 19 must remain available for comparison. This runtime incorporates their deployed UI where present; it does not assert every backend proposal in those PRs is approved or applied. Existing SQL, schema and backend files from main are retained without modification. They are not certified to reproduce all recent live database changes; reconcile those definitions in a separate reviewed backend change before treating this repository as a complete fresh-install recovery package.

The local dirty-work archive, session credentials, browser cookies, synced `sources/`, local continuation summary and local inspection inventories are intentionally excluded from GitHub and deployment. The old repository and local release folders are not deleted by this reconciliation. Before archiving them, verify no unique code, schema corrections, tests or unmerged owner-approved work remains.

## Release and rollback

Review and merge this reconciliation only after CI. The Production project is linked to main: merging can trigger its normal deployment, so do not merge automatically during source review. Keep previous deployment `dpl_EVZS3QCfHvyKPF4DRAUztaJc8ae8` as the rollback reference. A repository revert restores the previous source/build; a Vercel rollback restores the reviewed prior runtime without changing databases. No reverse SQL is required for this PR.

There is no 24-hour soak or 300–400-user load success claim. The old soak status was stale after 407 samples. Backend equivalence, further security debt and archival decisions remain explicit follow-up work.

`tests/network-origin-boundaries.cjs` exercises foreign-account avatar paths, cross-environment/external/credential-bearing URL rejection, preservation of upload method/body, redirect refusal and same-origin worker requests. Static and browser regression results must be renewed for this candidate before deployment.
