# Stage 1 — Guard Manual Entry & Emergency Mode Repair (2026-11-07)

## Scope & Objectives
1. **Unify `guard_manual_employee_entry_v2` and emergency RPCs across Production and Staging:**
   - `private.guard_qr_generation_failure_status()`
   - `public.guard_manual_employee_entry(p_token, p_employee_id, p_request_id)`
   - `public.guard_manual_employee_entry_v2(p_token, p_employee_id, p_request_id, p_screen_read_key DEFAULT NULL)`
   - `public.guard_session_status(p_token)`
   - `public.guard_set_emergency(p_token, p_enabled)`
2. **Fix Cold-Start QR Failure (No `readKey` on Initial Screen Open):**
   - When `guard.html` opens for the first time while QR generation is failing (`current === null`, `p_screen_read_key` is `''` or `NULL`), `guard_manual_employee_entry_v2` probes `private.guard_qr_generation_failure_status()`.
   - When the server confirms `QR_GENERATION_FAILED`, emergency mode is automatically enabled and the manual entry is processed and audited with `COLD_START`.
3. **Server-Observed QR Outage Sufficiency & Automatic Recovery Stop:**
   - Server detection of `QR_GENERATION_FAILED` automatically activates `private.guard_emergency_settings.enabled = true`.
   - When `create_public_guard_qr()` is healthy (or returns a non-generator error such as `RATE_LIMITED`), manual entry is blocked and `private.guard_emergency_settings.enabled` is automatically reset to `false`.
4. **Elderly-Friendly Guard Instructions:**
   - Added high-contrast, large-type numbered instructions (`#guardManualInstructions`) in `guard.html` and `guard-manual.css`, and clear Arabic status prompts in `guard-manual.js`.

## Verified Stage 1 Acceptance Criteria
| # | Scenario | Expected Result | Verified By |
|---|---|---|---|
| 1 | QR working normally | Block manual entry (`SCREEN_NOT_EXPIRED` / `QR_AVAILABLE` / `SCREEN_REQUIRED`) | `tests/guard-emergency-stage1.cjs` |
| 2 | QR failed since first screen open (no `readKey`) | Allow emergency entry after server verification | `tests/guard-emergency-stage1.cjs`, `tests/staging-alignment.cjs` |
| 3 | QR failed after code expiry | Activate emergency mode and allow entry | `tests/guard-emergency-stage1.cjs`, `tests/staging-alignment.cjs` |
| 4 | QR recovered | Automatically stop emergency mode on server and UI | `tests/guard-emergency-stage1.cjs` |
| 5 | Unauthenticated guard | Deny entry (`AUTH_REQUIRED`) | `tests/guard-emergency-stage1.cjs`, `tests/staging-alignment.cjs` |
| 6 | Duplicate entry request | Return cached decision without counting a second visit | `tests/guard-emergency-stage1.cjs`, `tests/staging-alignment.cjs` |
| 7 | Daily limit exceeded | Enforce denial (`DENIED`, `counted: false`) via `manual_employee_check` | `tests/guard-emergency-stage1.cjs` |
| 8 | Unable to prove QR failure | Refuse emergency activation (`QR_NOT_FAILED`) | `tests/guard-emergency-stage1.cjs` |

## Rollback Capability
- **Frontend:** Revert the Stage 1 commit on the deployment branch and re-run `node scripts/build-public-runtime.cjs`.
- **Database:** Restore the environment's prior routine definitions recorded in `supabase/reference/staging-catalog-20261011.json` (Staging) or `supabase/reference/production-catalog-20261011.json` (Production) while retaining the nullable `private.guard_manual_entries.screen_read_key_hash` column.
