# Backend unification review — 11 October 2026

Read-only catalog checks were made against Production `qinsfvlspdticposbvst` and Staging `adwvokwucotohwayorgx`. No employee rows were read or transferred. No SQL was applied, migration created, Edge Function deployed or database deleted in this review.

## Confirmed differences

| Metadata | Production | Staging |
|---|---:|---:|
| Application functions in public/private | 118 | 116 |
| Application tables | 36 | 36 |
| Policies in public/private/storage | 23 | 22 |
| Private Storage buckets | 3 | 2 |

There are 115 common function signatures. Forty-nine full definition hashes differ; after normalizing whitespace in function bodies, twelve body hashes still differ. A body hash difference requires review and does not by itself establish a behavioral defect. Eighty-five common signatures have different explicit ACL text; role membership and effective privileges must be considered before classifying these as access regressions. Equal table counts likewise do not prove equal schemas.

Production has an additional `create_qr_session` overload, `guard_manual_employee_entry_v2`, and `prevent_approved_employee_identity_change`. Staging has `guard_qr_generation_failure_status`, absent in Production. The three overloads of registration, manual verification, employee profile login, guard emergency/session functions and notice dispatch/claim/completion are among the differing bodies. Do not copy them between environments without reviewing their deployed contracts and authorization.

`create_public_guard_qr`, `claim_qr_session_v2`, `get_public_guard_result` and the public guard v2 verification functions have matching full definition hashes in the two environments at inspection time. This is source equivalence, not a new live concurrency or phone acceptance test.

Production contains private `admin-avatars` (JPEG, 2 MiB); Staging does not contain that bucket. Both have private `employee-photos` and `violation-photos`. Deploying the same frontend to Staging cannot alone make administrator photo saving operational. Provisioning the missing bucket/policies is a separate database/storage change, requiring review and explicit approval of its concrete diff. Preserve account ownership and private downloads.

## Recovery and archival boundaries

This PR reconciles the application runtime, not a fresh-install database recovery package. Historical SQL retained from main must not be replayed on either live project. The owner explicitly approved exporting the inspected function definitions and ACL metadata to the private unified repository on 11 October 2026. Non-executable JSON references are preserved under `supabase/reference`, with a local copy in the operational audit, and are excluded from the public artifact. They contain no employee records or password/session values. Lexical inspection found 39 Production routine names absent from existing repository SQL; preserving their deployed definitions closes the source-record gap without certifying install order or schema replay. The references are not executable migrations or data backups.

Before retiring old repositories, reconcile unique backend changes, open PRs and the saved local work. Before connecting Staging to the unified build, supply its public configuration and resolve or explicitly document unsupported Staging functionality. Keep Production and Staging databases separate. No claim of a completed 24-hour soak, load test, backup restoration or real-phone test is made by this source review.

## Reviewed alignment remains unapplied

On 11 October the owner declined application and requested that the concrete Staging SQL remain for review. `supabase/staging_alignment_reviewed.sql` adds private owner-only administrator-avatar storage and matches the approved Production same-screen emergency contract. It includes a nullable hash column required by the v2 routine, revokes direct legacy entry, and preserves central QR issuance, thirty-second expiry and existing decision rules. `tests/staging-alignment.cjs` verifies isolated RLS, expired screen proof, server generation failure, mismatched retries and one decision for repeated request IDs. Its generation/decision collaborators are synthetic; this is not a live concurrency or end-to-end phone acceptance test. No database application occurred. A local rollback restores previous routines/grants and removes the new policies while retaining uploaded objects and the nullable column; applying it also needs approval.
