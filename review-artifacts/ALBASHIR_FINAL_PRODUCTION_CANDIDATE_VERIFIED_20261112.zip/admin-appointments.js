/* Owner-selected grants; database RPCs make every authorization decision. */
window.AdminAppointments=(() => {
 const el=id=>document.getElementById(id);let editing=false,selected='';
 async function rpc(name,args={}){const {data,error}=await supabaseClient.rpc(name,args);if(error||data?.ok!==true)throw Error(data?.message||'تعذر حفظ التعيين.');return data;}
 function employees(rows){
  const picker=el('adminEmployeePicker');if(!picker)return;const value=picker.value;
  picker.replaceChildren(new Option('اختر موظفًا معتمدًا',''));
  rows.filter(r=>r.status==='APPROVED').sort((a,b)=>String(a.full_name).localeCompare(String(b.full_name),'ar')).forEach(row=>picker.add(new Option((row.full_name||'موظف')+' — '+row.employee_id,row.id)));
  if([...picker.options].some(o=>o.value===value))picker.value=value;
  preview();
 }
 function preview(){const row=registrationsData.find(r=>r.id===el('adminEmployeePicker').value);selected=row?.id||'';const host=el('adminEmployeePreview');host.replaceChildren();if(!row)return;
  if(row.employee_photo_url){const img=document.createElement('img');img.alt='صورة الموظف';img.dataset.photoRef=row.employee_photo_url;img.width=72;img.height=72;host.append(img);}
  const text=document.createElement('p');text.textContent=(row.full_name||'')+' — '+(row.job_type||'')+' — '+(row.mobile_number||'');host.append(text);hydrateAdminPhotos(host);
 }
 async function load(){if(typeof adminProfile==='undefined'||adminProfile?.role!=='SUPER_ADMIN')return;try{const data=await rpc('super_admin_assignment_accounts');const host=el('adminAssignmentList');host.replaceChildren();el('adminAppointmentStatus').textContent='';
  for(const a of data.assignments){const card=document.createElement('article');card.className='directory-card';const heading=document.createElement('h3');heading.textContent=a.full_name+' — '+a.employee_id;const text=document.createElement('p');text.textContent=({PENDING:a.account_exists?'جاهز لاعتماد الربط والتفعيل':'بانتظار بيانات الدخول',ACTIVE:a.is_active?'حساب الإدارة مفعّل':'حساب الإدارة معطّل',REVOKED:'التعيين ملغى'}[a.status]||a.status)+' — '+(a.role==='SUPER_ADMIN'?'صلاحية كاملة':'صلاحيات محددة');card.append(heading,text);
   if(a.email){const mail=document.createElement('p');mail.dir='ltr';mail.textContent=a.email;card.append(mail);}
   if(a.status==='PENDING'){
    const label=document.createElement('label');label.textContent='بريد حساب الموظف المسجّل';const input=document.createElement('input');input.type='email';input.dir='ltr';input.autocomplete='off';input.maxLength=254;input.value=a.email||'';label.append(input);card.append(label);
    const activate=document.createElement('button');activate.type='button';activate.className='btn-green';activate.textContent='اعتماد وتفعيل الحساب';
    activate.onclick=async()=>{const email=input.value.trim();if(!email||!input.reportValidity())return;
     if(!confirm('أؤكد أن الحساب '+email+' يخص الموظف '+a.full_name+' — '+a.employee_id+'، وأعتمد ربطه وتفعيله بصلاحيات التعيين. لن تتغير كلمة مروره.'))return;
     activate.disabled=true;try{const response=await rpc('super_admin_activate_employee_account',{p_id:a.id,p_email:email});showToast(response.message,'ok');await loadAdmins();await loadAudit();}catch(e){showToast(e.message,'error');activate.disabled=false;}};card.append(activate);
   }
   if(a.status==='PENDING'){const edit=document.createElement('button');edit.type='button';edit.textContent='تعديل التعيين';edit.onclick=()=>{clearAdminForm();el('adminEmployeePicker').value=a.registration_id;preview();el('adminRole').value=a.role;setPermissionCheckboxes(a.permissions);lockFullRole();el('adminEmployeePicker').focus();};card.append(edit);}
   if(a.status!=='REVOKED'){const revoke=document.createElement('button');revoke.type='button';revoke.className='btn-red';revoke.textContent='إلغاء التعيين';revoke.onclick=async()=>{if(!confirm('إلغاء تعيين الموظف وتعطيل حساب الإدارة إن كان مفعّلًا؟'))return;revoke.disabled=true;try{const response=await rpc('super_admin_revoke_employee_assignment',{p_id:a.id});showToast(response.message,'ok');await load();await loadAdmins();}catch(e){showToast(e.message,'error');revoke.disabled=false;}};card.append(revoke);}host.append(card);
  }
  if(!data.assignments.length)host.textContent='لا توجد تعيينات موظفين بعد.';
 }catch(e){el('adminAppointmentStatus').textContent=e.message;}}
 function lockFullRole(){const full=el('adminRole').value==='SUPER_ADMIN';for(const id of ['permApprove','permViolations','permLogs','permExport','permLimits','permAudit']){el(id).disabled=full;if(full)el(id).checked=true;}}
 const oldClear=window.clearAdminForm,oldFill=window.fillAdminByIndex,oldSave=window.saveAdmin,oldRole=window.applyRoleDefaultPermissions;
 window.clearAdminForm=function(){oldClear();editing=false;el('adminExistingIdentity').hidden=true;el('adminEmployeeSelection').hidden=false;el('adminEmployeePicker').value='';preview();el('adminActive').value='true';el('adminActive').parentElement.hidden=true;el('saveAdminButton').textContent='تعيين الموظف كمشرف';lockFullRole();};
 window.fillAdminByIndex=function(index){oldFill(index);editing=true;el('adminExistingIdentity').hidden=false;el('adminEmployeeSelection').hidden=true;el('adminActive').parentElement.hidden=false;lockFullRole();};
 window.applyRoleDefaultPermissions=function(){oldRole();lockFullRole();};
 window.saveAdmin=async function(){if(editing)return oldSave();if(adminProfile?.role!=='SUPER_ADMIN'){showToast('هذه العملية للمشرف الرئيسي فقط.','error');return;}if(!selected){showToast('اختر موظفًا معتمدًا.','error');return;}
  const button=el('saveAdminButton');if(button.disabled)return;button.disabled=true;try{const data=await rpc('super_admin_assign_employee',{p_registration_id:selected,p_role:el('adminRole').value,p_permissions:getAdminPermissionsFromForm()});showToast(data.message,'ok');clearAdminForm();await load();await loadAudit();}catch(e){showToast(e.message,'error');}finally{button.disabled=false;}
 };
 let connectionBusy=false,connectionRows=[],connectionUpdated=0;
 function renderConnections(){const host=el('adminConnectionList');if(!host)return;host.replaceChildren();const stale=Date.now()-connectionUpdated>90000;const onlineOnly=el('adminConnectionFilter').value==='online';
  const rows=connectionRows.filter(row=>!onlineOnly||(!stale&&row.online));
  for(const row of rows){const card=document.createElement('article');card.className='directory-card';const name=document.createElement('h3');name.textContent=row.full_name||row.email;const mail=document.createElement('p');mail.dir='ltr';mail.textContent=row.email;const state=document.createElement('p');state.textContent=!row.is_active?'معطّل':stale?'حالة الاتصال غير معروفة':row.online?'🟢 متصل حديثًا':'غير متصل';const seen=document.createElement('p');seen.textContent=row.last_seen?'آخر اتصال: '+new Date(row.last_seen).toLocaleString('ar-JO',{timeZone:'Asia/Amman'}):'لم يسجل اتصالًا باللوحة بعد';card.append(name,mail,state,seen);host.append(card);}
  if(!rows.length)host.textContent=stale?'تعذر التحقق من المتصلين؛ أعد التحديث.':'لا يوجد مشرفون ضمن هذا الفلتر.';
 }
 async function connectionTick(){if(connectionBusy||typeof adminProfile==='undefined'||!adminProfile)return;connectionBusy=true;try{
  await rpc('record_admin_connection',{p_connected:true});
  if(adminProfile.role==='SUPER_ADMIN'){const data=await rpc('super_admin_connections');connectionRows=data.admins;connectionUpdated=Date.now();el('adminConnectionStatus').textContent='تم تحديث حالة الاتصال.';renderConnections();}
 }catch(e){if(el('adminConnectionStatus'))el('adminConnectionStatus').textContent='تعذر تحديث حالة الاتصال: '+e.message;renderConnections();}finally{connectionBusy=false;}}
 async function disconnect(){try{await rpc('record_admin_connection',{p_connected:false});}catch(e){console.warn('Admin connection close unavailable');}}
 let connectionTimer=setInterval(connectionTick,30000);window.addEventListener('pagehide',()=>{clearInterval(connectionTimer);connectionTimer=null;});window.addEventListener('pageshow',()=>{if(!connectionTimer){connectionTimer=setInterval(connectionTick,30000);connectionTick();}});
 el('adminConnectionFilter').onchange=renderConnections;el('adminConnectionRefresh').onclick=connectionTick;
 el('adminEmployeePicker').onchange=preview;clearAdminForm();
 return {employees,load,connectionTick,disconnect};
})();
