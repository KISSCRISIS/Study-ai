(() => {
  'use strict';
  const nav = document.querySelector('.nav-tabs');
  const buttons = [...nav.querySelectorAll('.tab-btn')];
  const groups = [['نظرة عامة',['overview','notifications']],['الموظفون',['registrations','profileChanges','employeeDirectory']],['الدخول والحدود',['logs','limits','dailyUsage']],['الأمان والإدارة',['violations','admins','audit','exports']]];
  const brand = document.createElement('div'); brand.className='admin-nav-brand'; brand.textContent='البشير | لوحة الإدارة'; nav.prepend(brand);
  for (const [label, ids] of groups) {
    const heading=document.createElement('div'); heading.className='admin-nav-group'; heading.textContent=label; nav.append(heading);
    ids.forEach(id=>{const button=buttons.find(b=>b.getAttribute('onclick').includes("'"+id+"'")); if(button) nav.append(button);});
  }
  const search=document.createElement('div'); search.className='admin-section-search';
  const label=document.createElement('label'); label.htmlFor='adminSectionSearch'; label.textContent='البحث في الأقسام';
  const input=document.createElement('input'); input.id='adminSectionSearch'; input.type='search'; input.placeholder='طلبات، موظفون، سجلات…';
  search.append(label,input); document.querySelector('.topbar').append(search);
  input.addEventListener('input',()=>{const q=input.value.trim(); buttons.forEach(b=>{b.hidden=!!q&&!b.textContent.includes(q);});});
  input.addEventListener('keydown',event=>{if(event.key==='Enter'){const visible=buttons.filter(b=>!b.hidden&&getComputedStyle(b).display!=='none');if(visible.length===1){visible[0].click();input.value='';input.dispatchEvent(new Event('input'));}}});
  const metrics=[['statPendingRequests',"registrations"],['statNewViolations','violations']];
  for(const [source,id] of metrics){const el=document.getElementById(source);const target=document.querySelector('.needs-action-secondary button[onclick*="'+id+'"]');if(!el||!target)continue;const count=document.createElement('span');count.className='modern-count';target.append(count);const update=()=>{count.textContent=el.textContent;};new MutationObserver(update).observe(el,{childList:true,subtree:true,characterData:true});update();}
  const drawer=document.createElement('dialog');drawer.className='admin-row-drawer';drawer.setAttribute('aria-label','معاينة بيانات الصف');document.body.append(drawer);
  let returnFocus;
  drawer.addEventListener('close',()=>{drawer.replaceChildren();returnFocus?.focus();});
  function preview(row,button){returnFocus=button;const close=document.createElement('button');close.className='drawer-close';close.textContent='إغلاق ×';close.onclick=()=>drawer.close();const title=document.createElement('h2');title.textContent='تفاصيل السجل';const description=document.createElement('p');description.textContent='معاينة للبيانات المعروضة حاليًا. الإجراءات متاحة في القسم الأصلي.';const list=document.createElement('dl');const headers=[...row.closest('table').querySelectorAll('thead th')];[...row.cells].forEach((cell,i)=>{if(cell.querySelector('button:not(.row-preview-button),input,select'))return;const term=document.createElement('dt');term.textContent=headers[i]?.textContent||'بيانات';const value=document.createElement('dd');const copy=cell.cloneNode(true);copy.querySelectorAll('.row-preview-button').forEach(b=>b.remove());value.textContent=copy.textContent.trim();list.append(term,value);});drawer.replaceChildren(close,title,description,list);drawer.showModal();close.focus();}
  function enhance(){document.querySelectorAll('.dashboard-activity-grid tbody tr').forEach(row=>{if(row.querySelector('.row-preview-button')||row.cells.length<2||row.cells[0].colSpan>1)return;const button=document.createElement('button');button.type='button';button.className='row-preview-button';button.textContent='التفاصيل';button.addEventListener('click',()=>preview(row,button));row.cells[0].append(button);});}
  new MutationObserver(enhance).observe(document.querySelector('.dashboard-activity-grid'),{childList:true,subtree:true});enhance();

  // Debounce character-by-character search without changing filter semantics.
  const originalApplyDashboardFilters = window.applyDashboardFilters;
  if (typeof originalApplyDashboardFilters === 'function') {
    let searchTimer = 0;
    window.applyDashboardFilters = function (...args) {
      if (document.activeElement?.id === 'dashboardSearch') {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => originalApplyDashboardFilters.apply(this, args), 220);
        return;
      }
      clearTimeout(searchTimer);
      return originalApplyDashboardFilters.apply(this, args);
    };
  }

  // Release photo references before replacing registration cards.
  const originalRenderRegistrations = window.renderRegistrations;
  if (typeof originalRenderRegistrations === 'function') {
    window.renderRegistrations = function (...args) {
      window.EmployeePhoto?.release?.(document.getElementById('registrationsBody'));
      return originalRenderRegistrations.apply(this, args);
    };
  }
})();
