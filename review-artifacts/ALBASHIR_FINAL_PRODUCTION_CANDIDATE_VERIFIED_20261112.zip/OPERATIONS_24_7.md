# ALBASHIR current operating checklist

## QR and result delivery

1. Treat expires_at/server_now as authoritative; current server validity is 30 seconds. Validity is not the refresh interval. Public guard prewarming starts six seconds before expiry; display/rotation behavior must be measured separately from older 15/30-second operational assumptions.
2. Keep only the last unexpired server-issued QR during failure; clear an expired QR. Never issue local fallback tokens or extend validity.
3. QR generation and polling must remain single-flight, bounded by a network deadline, and recover visibly after failure. Preserve the same claim/decision request identity on retry.
4. The result read_key remains screen-specific and is never included in the QR. Do not log tokens, keys or employee data.
5. Confirm that an actual employee result reaches the guard, shows the registered private photo when present, and clears identifying information after ten seconds. Mocked CI is not real-phone acceptance.
6. Manual emergency entry requires server guard authorization and proof of failure on the same screen. A full backend outage cannot be bypassed by cached pages or an operational snapshot.

## Acceptance and monitoring

- A sustained run passes only after 24 hours, at least 95% coverage and zero errors. RUNNING is not success. Record pauses, missing samples, QR rotation, request failures and browser restarts.
- The replacement Staging run started 11 October 2026 at 17:05 Asia/Amman and is scheduled to end 12 October at 17:05. Local SOAK_20261011_STATUS.json and samples under operational-review are its evidence; do not publish employee data or raw credentials.
- Previous 300/400 result-reading and QR-session tests are bounded measurements, not full employee/daily-limit or 72-hour acceptance.
- Use CI offline-sync regression for deduplication, bounded batches and retry preservation. Historical offline procedures are archived; they do not authorize offline entry.
- Test PWA updates without forcing an incompatible worker takeover. Never cache authenticated responses or Supabase API data.
- Confirm anonymous, employee, guard and administrator access boundaries using synthetic tests and an authorized real-device check. Keep employee images private and short-lived.

## Release and rollback

- Build the allowlisted runtime from the reviewed main commit. Match the intended Vercel project, environment and database before release.
- Do not run old schema_patch files or fresh-install SQL on an existing database. SQL presence in Git is not proof of live application.
- The Staging alignment SQL remains declined for application and available for review. A repository cleanup does not override that decision.
- A code revert or known Vercel deployment rollback restores the runtime; it does not reverse database changes. Preserve separate reviewed database rollback plans.
- Independent backup internet and database restore capability are operational provisions, not capabilities created by an offline snapshot or cleanup.
