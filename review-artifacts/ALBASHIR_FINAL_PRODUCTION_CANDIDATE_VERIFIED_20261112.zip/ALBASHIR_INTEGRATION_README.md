# ALBASHIR INTEGRATED QA SOURCE BACKUP — NOT A PRODUCTION RELEASE

This ZIP is assembled from **the four ZIP uploads**, not from any inaccessible Claude local workspace. The source is the exact file-content union of GitHub main + review PR #61 + PR #62 + PR #63, with NO manual code edits. This is an archive/source snapshot, NOT a Git repository with history (no `.git`), and no installed `node_modules`.

Baseline GitHub main: `28743757da60988d64262073c3217a0a4cf2b5e4`.
PR #61: `4db6fb58b6b72882f101d4ab8f409c4504ffb04c` — new registration page and tests.
PR #62: `efcde202b284b54f679e8949644d2af9acf6d65a` — SQL migration and rollback are deliberately LOCKED with `RAISE EXCEPTION`.
PR #63: `7dc164f00bc19075c2571509bcf2d7fe874b8ce0` — standalone new-only photo reader and tests, not deployed.

## Content verification
- 237 baseline files (all byte-identical except two additive-only config manifests).
- +6 new files from PR #61; +7 from PR #62; +13 from PR #63.
- Two original files updated by PR #61 only: `config/runtime-baseline.json`, `config/runtime-files.json`.
- No overlapping changed paths, no deleted baseline paths, no other preexisting application file modifications.
- `tests/package.json` is byte-identical to `main`. Claude's last unpushed edit adding tests to its scripts is NOT in any uploaded ZIP. New tests are included as files but must be called explicitly or added by a reviewed QA-only change.

## Safety
- Not validated on live Staging/Production.
- SQL/Edge new-only functions were NOT deployed by creating this archive.
- Do not remove `RAISE EXCEPTION` locks or deploy to Production.
- Do not merge PR #58 or legacy PR stack.
- Production staff records, photos, devices, policies and QR remain untouched.
- The original production registration, guard, admin, profile and photo code remains byte-identical in this archive.
- Current frontend routes and picture viewers are not yet integrated end-to-end with new-only backend.
- This ZIP contains no live database or private Storage images.

## Running tests locally (where Node.js, npm, and Playwright are installed)
cd tests
npm ci --ignore-scripts --no-audit --no-fund
npm test
npm run test:staging-alignment
npm run test:browser
node new-only-route-contract.cjs
node production-new-only-backend-review.cjs
node new-only-photo-resolver.cjs
node new-only-ui-browser.cjs   # must be run after installing Playwright Chromium

These tests do not replace real Staging end-to-end sign-in, admin approval, QR and private photo tests.
