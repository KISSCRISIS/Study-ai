# Current image assets

The published image inventory is defined by config/runtime-files.json. about.html uses albashir-emergency-logo.webp and founder-portrait.webp; portal.html uses portal-layout-approved.png and portal-reference.png. Other root logos/backgrounds are still referenced by runtime pages, CSS or the Service Worker.

The unused inquiry-profile-no-facebook.png was removed in PR #22 with a local design backup. There is no build step generating hospital-logo/logo.png or leadership portraits. Do not add employee photographs here: they belong in private authenticated Storage. Preserve original portraits; crop/resize/alignment only, with no face edits.
