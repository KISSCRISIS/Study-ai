-- Owner-approved record deletion. Reviewed additive SQL, not an automatic migration.
begin;
create table if not exists private.employee_deletion_jobs (
 registration_id uuid primary key, employee_id text not null,
 photo_paths jsonb not null default '[]', created_by uuid not null,
 created_at timestamptz not null default now(), completed_at timestamptz
);
alter table private.employee_deletion_jobs enable row level security;
revoke all on private.employee_deletion_jobs from public,anon,authenticated;

create or replace function public.super_admin_delete_employee_record(p_registration_id uuid,p_employee_id text)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare r public.employee_registrations; j private.employee_deletion_jobs; paths jsonb;
begin
 if not public.is_super_admin() then return jsonb_build_object('ok',false,'message','الحذف للسوبر أدمن فقط.'); end if;
 perform pg_advisory_xact_lock(8101009);
 perform 1 from public.admin_profiles where auth_user_id=auth.uid() and role='SUPER_ADMIN' and is_active for update;
 if not found then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 select * into j from private.employee_deletion_jobs where registration_id=p_registration_id for update;
 if j.registration_id is not null then
  if j.employee_id is distinct from btrim(p_employee_id) then return jsonb_build_object('ok',false,'message','رقم التأكيد غير مطابق.'); end if;
  return jsonb_build_object('ok',true,'job_id',j.registration_id,'complete',j.completed_at is not null);
 end if;
 select * into r from public.employee_registrations where id=p_registration_id for update;
 if r.id is null or r.employee_id is distinct from btrim(p_employee_id) then return jsonb_build_object('ok',false,'message','السجل أو رقم التأكيد غير مطابق.'); end if;
 if exists(select 1 from private.employee_admin_assignments a left join public.admin_profiles ap on ap.auth_user_id=a.auth_user_id where a.registration_id=r.id and (a.status in ('PENDING','ACTIVE') or coalesce(ap.is_active,false))) then
  return jsonb_build_object('ok',false,'message','ألغِ تعيين الإدارة وصلاحيات الموظف أولًا، ثم أعد الحذف.');
 end if;
 if nullif(btrim(r.employee_photo_url),'') is not null and not private.is_valid_employee_photo_path(r.employee_photo_url) then
  return jsonb_build_object('ok',false,'message','مرجع الصورة يحتاج مراجعة قبل الحذف.');
 end if;
 if exists(select 1 from private.pending_employee_uploads where registration_id=r.id and not private.is_valid_employee_photo_path(object_path)) then
  return jsonb_build_object('ok',false,'message','يوجد مرجع صورة قديم يحتاج مراجعة قبل الحذف.');
 end if;
 select coalesce(jsonb_agg(p),'[]') into paths from (
  select distinct private.employee_photo_object_path(v) p from (
   select r.employee_photo_url v union all select object_path from private.pending_employee_uploads where registration_id=r.id
  ) refs where private.is_valid_employee_photo_path(v)
 ) normalized;
 if exists(select 1 from public.employee_registrations other where other.id<>r.id and paths ? private.employee_photo_object_path(other.employee_photo_url)) then
  return jsonb_build_object('ok',false,'message','الصورة مرتبطة بسجل آخر؛ يلزم مراجعتها قبل الحذف.');
 end if;
 insert into private.employee_deletion_jobs(registration_id,employee_id,photo_paths,created_by) values(r.id,r.employee_id,paths,auth.uid());
 delete from private.employee_admin_proofs where assignment_id in (select id from private.employee_admin_assignments where registration_id=r.id);
 delete from private.employee_admin_assignments where registration_id=r.id;
 delete from public.employee_registrations where id=r.id;
 insert into public.admin_audit_logs(admin_auth_user_id,action,target_table,target_id,details)
 values(auth.uid(),'DELETE_EMPLOYEE_RECORD','employee_registrations',r.id::text,jsonb_build_object('employee_id',r.employee_id,'photo_cleanup_pending',true));
 return jsonb_build_object('ok',true,'job_id',r.id,'complete',false);
end $$;

create or replace function private.block_retired_employee_photo()
returns trigger language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if exists(select 1 from private.employee_deletion_jobs where photo_paths ? private.employee_photo_object_path(new.employee_photo_url)) then
  raise exception 'This photo is being removed and cannot be linked to a registration';
 end if;
 return new;
end $$;
drop trigger if exists block_retired_employee_photo on public.employee_registrations;
create trigger block_retired_employee_photo before insert or update of employee_photo_url on public.employee_registrations for each row execute function private.block_retired_employee_photo();
revoke all on function private.block_retired_employee_photo() from public,anon,authenticated;

create or replace function public.super_admin_employee_deletion_jobs()
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if not public.is_super_admin() then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 return jsonb_build_object('ok',true,'jobs',coalesce((select jsonb_agg(jsonb_build_object('id',registration_id,'employee_id',employee_id)) from private.employee_deletion_jobs where completed_at is null),'[]'));
end $$;

create or replace function public.service_employee_deletion_job(p_id uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare j private.employee_deletion_jobs;
begin
 select * into j from private.employee_deletion_jobs where registration_id=p_id;
 if j.registration_id is null then return jsonb_build_object('ok',false); end if;
 if exists(select 1 from public.employee_registrations where j.photo_paths ? private.employee_photo_object_path(employee_photo_url)) then return jsonb_build_object('ok',false); end if;
 return jsonb_build_object('ok',true,'complete',j.completed_at is not null,'paths',j.photo_paths);
end $$;

create or replace function public.service_complete_employee_deletion(p_id uuid,p_actor uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare j private.employee_deletion_jobs;
begin
 select * into j from private.employee_deletion_jobs where registration_id=p_id for update;
 if j.registration_id is null or not exists(select 1 from public.admin_profiles where auth_user_id=p_actor and role='SUPER_ADMIN' and is_active) then return jsonb_build_object('ok',false); end if;
 if j.completed_at is not null then return jsonb_build_object('ok',true); end if;
 if exists(select 1 from storage.objects where bucket_id='employee-photos' and j.photo_paths ? name) then return jsonb_build_object('ok',false); end if;
 delete from private.pending_employee_uploads where j.photo_paths ? object_path;
 update private.employee_deletion_jobs set completed_at=now(),photo_paths='[]' where registration_id=p_id;
 insert into public.admin_audit_logs(admin_auth_user_id,action,target_table,target_id,details) values(p_actor,'DELETE_EMPLOYEE_PHOTOS','employee_registrations',p_id::text,jsonb_build_object('removed_paths',jsonb_array_length(j.photo_paths)));
 return jsonb_build_object('ok',true);
end $$;

revoke all on function public.super_admin_delete_employee_record(uuid,text),public.super_admin_employee_deletion_jobs() from public,anon;
grant execute on function public.super_admin_delete_employee_record(uuid,text),public.super_admin_employee_deletion_jobs() to authenticated;
revoke all on function public.service_employee_deletion_job(uuid),public.service_complete_employee_deletion(uuid,uuid) from public,anon,authenticated;
grant execute on function public.service_employee_deletion_job(uuid),public.service_complete_employee_deletion(uuid,uuid) to service_role;
commit;
