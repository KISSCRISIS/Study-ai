-- Review-only canonical SQL patch for owner approval.
-- This is NOT a migration and has NOT been applied to Staging or Production.
-- Broadcasts carry no employee data or raw read key. The existing RPC remains authoritative.

create or replace function private.broadcast_public_guard_result_ready()
returns trigger
language plpgsql
security definer
set search_path to 'pg_catalog', 'private', 'extensions'
as $function$
declare
  v_topic_hash text;
  v_proof text;
begin
  if new.result is null then
    return new;
  end if;

  if tg_op = 'UPDATE' then
    if old.result is not distinct from new.result then
      return new;
    end if;
  end if;

  v_topic_hash := encode(
    extensions.digest('guard-result-topic:' || new.read_key_hash, 'sha256'),
    'hex'
  );
  v_proof := encode(
    extensions.digest('guard-result-signal:' || new.read_key_hash, 'sha256'),
    'hex'
  );

  begin
    perform realtime.send(
      jsonb_build_object('proof', v_proof),
      'result-ready',
      'guard-result:' || v_topic_hash,
      false
    );
  exception when others then
    -- A failed signal must never roll back the saved access decision.
    raise warning 'Public guard Realtime signal unavailable; RPC polling remains authoritative';
  end;

  return new;
end;
$function$;

revoke all on function private.broadcast_public_guard_result_ready()
  from public, anon, authenticated;

drop trigger if exists public_guard_result_ready_broadcast
  on private.public_guard_sessions;

create trigger public_guard_result_ready_broadcast
after insert or update of result
on private.public_guard_sessions
for each row
when (new.result is not null)
execute function private.broadcast_public_guard_result_ready();
