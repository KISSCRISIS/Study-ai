-- Bounded synthetic QA in isolated Staging, all data/functions rolled back.
BEGIN;
DO $guard$
BEGIN
  IF NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING')
     OR NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA261108-5751216')
     OR to_regclass('private.new_employee_photo_view_limits') IS NOT NULL
     OR to_regprocedure('public.new_employee_photo_view_admit(text)') IS NOT NULL
     OR to_regprocedure('public.new_employee_photo_signed_url_admit(text)') IS NOT NULL
  THEN RAISE EXCEPTION 'Not isolated reviewed Staging: refuse'; END IF;
END;
$guard$;
CREATE TABLE private.new_employee_photo_view_limits (
  scope_key text PRIMARY KEY,
  window_started_at timestamptz NOT NULL,
  attempt_count integer NOT NULL CHECK (attempt_count>=0),
  updated_at timestamptz NOT NULL
);
ALTER TABLE private.new_employee_photo_view_limits ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private.new_employee_photo_view_limits FROM PUBLIC,anon,authenticated,service_role;

CREATE OR REPLACE FUNCTION public.new_employee_photo_view_admit(p_employee_id text)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id,''));
  v_scope text;
  v_count integer;
  v_window timestamptz;
  v_limit integer;
  v_now timestamptz := clock_timestamp();
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
      OR v_employee_id='' OR char_length(v_employee_id)>32
      OR v_employee_id ~ '[[:cntrl:]]'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  -- Bounded housekeeping of this NEW table only. Do not touch old queues.
  DELETE FROM private.new_employee_photo_view_limits WHERE scope_key IN (
    SELECT scope_key FROM private.new_employee_photo_view_limits
    WHERE updated_at < v_now - interval '1 day'
    ORDER BY updated_at LIMIT 20
    FOR UPDATE SKIP LOCKED
  );

  -- Pre-auth stage: ONLY per-ID throttle, atomically updated.
  -- Forged credentials cannot consume the global signed-URL budget.
  -- Do not treat a caller-provided ID, Origin or IP as authentication.
  FOR v_scope,v_limit IN
    SELECT scope_key,max_calls
    FROM (
      VALUES
        ('employee:'||encode(extensions.digest(
          convert_to('new-photo-view:'||v_employee_id,'UTF8'),'sha256'),'hex'),12)
    ) AS quotas(scope_key,max_calls)
    ORDER BY scope_key
  LOOP
    INSERT INTO private.new_employee_photo_view_limits
      (scope_key,window_started_at,attempt_count,updated_at)
    VALUES (v_scope,v_now,1,v_now)
    ON CONFLICT(scope_key) DO UPDATE
    SET window_started_at=CASE WHEN
      private.new_employee_photo_view_limits.window_started_at <= v_now - interval '10 minutes'
      THEN v_now ELSE private.new_employee_photo_view_limits.window_started_at END,
      attempt_count=CASE WHEN
      private.new_employee_photo_view_limits.window_started_at <= v_now - interval '10 minutes'
      THEN 1 ELSE least(private.new_employee_photo_view_limits.attempt_count+1,602) END,
      updated_at=v_now
    RETURNING attempt_count,window_started_at INTO v_count,v_window;
    IF v_count>v_limit THEN
      RETURN jsonb_build_object('ok',false);
    END IF;
  END LOOP;
  RETURN jsonb_build_object('ok',true);
END;
$function$;

REVOKE ALL ON FUNCTION public.new_employee_photo_view_admit(text)
  FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.new_employee_photo_view_admit(text)
  TO service_role;

-- Second stage: ONLY successfully authenticated + SQL-bound image requests
-- reach this service-role-only global signed-URL limiter.
CREATE OR REPLACE FUNCTION public.new_employee_photo_signed_url_admit(p_employee_id text)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id,''));
  v_count integer;
  v_now timestamptz := clock_timestamp();
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
    OR v_employee_id='' OR char_length(v_employee_id)>32
    OR v_employee_id ~ '[[:cntrl:]]'
  THEN RETURN jsonb_build_object('ok',false); END IF;
  INSERT INTO private.new_employee_photo_view_limits
    (scope_key,window_started_at,attempt_count,updated_at)
  VALUES ('global',v_now,1,v_now)
  ON CONFLICT(scope_key) DO UPDATE
  SET window_started_at=CASE WHEN
    private.new_employee_photo_view_limits.window_started_at <= v_now - interval '10 minutes'
    THEN v_now ELSE private.new_employee_photo_view_limits.window_started_at END,
      attempt_count=CASE WHEN
    private.new_employee_photo_view_limits.window_started_at <= v_now - interval '10 minutes'
    THEN 1 ELSE least(private.new_employee_photo_view_limits.attempt_count+1,602) END,
      updated_at=v_now
  RETURNING attempt_count INTO v_count;
  RETURN jsonb_build_object('ok',v_count <= 600);
END;
$function$;

REVOKE ALL ON FUNCTION public.new_employee_photo_signed_url_admit(text)
  FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.new_employee_photo_signed_url_admit(text)
  TO service_role;

CREATE TEMP TABLE qa_rate_results(scenario text,result jsonb) ON COMMIT DROP;
SELECT set_config('request.jwt.claim.role','anon',true);
INSERT INTO qa_rate_results VALUES('anon_pre_denied',public.new_employee_photo_view_admit('QA-PR63-NEW'));
INSERT INTO qa_rate_results VALUES('anon_global_denied',public.new_employee_photo_signed_url_admit('QA-PR63-NEW'));
SELECT set_config('request.jwt.claim.role','service_role',true);
INSERT INTO qa_rate_results VALUES('new_first',public.new_employee_photo_view_admit('QA-PR63-NEW'));
SELECT public.new_employee_photo_view_admit('QA-PR63-NEW') FROM generate_series(1,11);
INSERT INTO qa_rate_results VALUES('id_limit_denied',public.new_employee_photo_view_admit('QA-PR63-NEW'));
INSERT INTO qa_rate_results VALUES('other_id_unaffected',public.new_employee_photo_view_admit('QA-PR63-OTHER'));
INSERT INTO qa_rate_results VALUES('global_first',public.new_employee_photo_signed_url_admit('QA-PR63-NEW'));
-- Simulate 600 *verified* sign requests without repeated HTTP calls.
UPDATE private.new_employee_photo_view_limits SET attempt_count=600 WHERE scope_key='global';
INSERT INTO qa_rate_results VALUES('aggregate_limit_denied',public.new_employee_photo_signed_url_admit('QA-PR63-THIRD'));
INSERT INTO qa_rate_results VALUES('preauth_still_allowed_after_global',public.new_employee_photo_view_admit('QA-PR63-THIRD'));
SELECT jsonb_object_agg(scenario,result) AS results,
 has_function_privilege('anon','public.new_employee_photo_view_admit(text)','EXECUTE') AS anon_preauth_exec,
 has_function_privilege('authenticated','public.new_employee_photo_signed_url_admit(text)','EXECUTE') AS auth_global_exec,
 has_function_privilege('service_role','public.new_employee_photo_signed_url_admit(text)','EXECUTE') AS service_global_exec,
 (SELECT count(*) FROM private.new_employee_photo_view_limits
  WHERE scope_key<>'global' AND scope_key !~ '^employee:[0-9a-f]{64}$') AS plaintext_or_invalid_keys,
 (SELECT count(*) FROM private.new_employee_photo_view_limits WHERE scope_key='global') AS global_scope_count
FROM qa_rate_results;
ROLLBACK;
