-- REVIEW ONLY. This DDL has not been run in Production or Staging.
-- This lock must remain until separate, explicit release authorization.
DO $release_lock$
BEGIN
 RAISE EXCEPTION 'REVIEW ONLY: new employee photo binding is disabled';
END;
$release_lock$;

-- Endpoint is service-role ONLY and never returns historical employee data.
-- Newly approved employees and pending applicants can view only their
-- *exact* photo object, if it was server-attested AFTER cohort freeze.
CREATE OR REPLACE FUNCTION public.resolve_attested_new_employee_photo(
 p_employee_id text,p_object_path text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $fn$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id,''));
  v_object_path text := btrim(coalesce(p_object_path,''));
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
     OR v_employee_id='' OR char_length(v_employee_id)>32 OR v_employee_id ~ '[[:cntrl:]]'
     OR v_object_path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  RETURN jsonb_build_object('ok',EXISTS(
    SELECT 1 FROM public.employee_registrations r
    JOIN private.legacy_registration_cutoff c ON c.singleton=true
    JOIN private.new_employee_photo_attestations a
      ON a.employee_id=r.employee_id AND a.object_path=r.employee_photo_url
    JOIN storage.objects o
      ON o.bucket_id='employee-photos' AND o.name=a.object_path
    WHERE r.employee_id=v_employee_id AND r.employee_photo_url=v_object_path
      AND r.created_at>c.freeze_at
      AND r.status IN ('PENDING','APPROVED')
  ));
END;
$fn$;

REVOKE ALL ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 TO service_role;
