# Production-derived new-employee backend: LOCKED REVIEW ONLY
Date: 2026-11-11

**This code has NOT been applied to Production or Staging.**
Explicit release approval and independent Staging tests are required to
remove the mandatory fail-closed `RAISE EXCEPTION` statements.

The original live Production 15-parameter registration function was read
without reading or writing any employee details. Original definition md5:
`ac4a045048cd7cf1b9cdda9cfb573774`.

Only one early guard is inserted into the original public registration
routine before its `reg.id IS NULL` branch: an ID absent from the
historical cutoff is denied. All APPROVED, PENDING, REJECTED, QR, phone,
trusted-device and photo logic for frozen legacy records stays verbatim.
A private copy of the original code is used for first-time-only
registration, with an additional guard against ever updating existing IDs,
including concurrent registration races.

A new RPC requires server-attested private JPEG plus pending ledger and
object existence. New-only registrations do not receive a QR token through
the registration RPC. Eligibility and attestation RPCs are granted only
to service_role. No old Storage policy or employee row/image is altered.

**Open safety blockers:** The Production uploader remains Edge v2 and
resolver v2; reviewed Staging Edge v9 cannot be directly promoted without
proof of Production-specific contract compatibility. Existing Staging
register function differs from the original Production function, so test
this production-derived implementation on isolated Staging with synthetic
QA data before considering release. Independently review SECURITY DEFINER
and access control, recent signatures, storage ownership, race conditions,
and safe rollback. Ensure a new release-time snapshot captures every real
historical employee; this review's fixed 254-row preflight deliberately
fails closed if any new users joined in the meantime.

Rollback is locked; restoring the old function would re-enable its
historical first-time registration behavior, so review this separately.
No PR merge, Edge deployment, Production SQL, image migration or live
employee changes are authorized by this review.

## Reviewed SQL syntax correction
A first read-only Staging transaction exposed a malformed JPEG regex in
the review-only new RPC (caused by JavaScript replacement handling `$'`
as replacement syntax). The candidate was repaired with literal
replacement semantics and a regression contract. No SQL was applied.
Syntax and behavior still require isolated Staging transaction tests.

## SQL-level isolated Staging compatibility test — PASSED
The corrected production-derived functions were created **only inside a
single Staging transaction** in temporary `qa_prod_parity_1111` schema,
using synthetic QA employee ID and **613-byte fake JPEG metadata only**,
with a private pending ledger and attestation. Exact results:

| Scenario | Actual result |
| --- | --- |
| First-time new-only registration | PENDING |
| Repeat new-only internal core for registered QA | DENIED |
| Post-cutover new QA through legacy RPC | DENIED |
| Unknown QA through legacy RPC | DENIED |

The transaction executed `ROLLBACK`; no QA image bytes were created,
and no original employee records/photos were edited. The committed
reviewed reproduction script is
`STAGING_ROLLBACK_PRODUCTION_PARITY_20261111.sql` and contains a
Staging-only marker check. This SQL-level synthetic test does **not**
establish a Production release pass, real JPEG image bytes/Edge upload,
full browser+QR flow or concurrency stress coverage. Both Production
DDL and rollback remain execution-locked.

## Additional original legacy-ID compatibility test — PASSED
A separate isolated Staging transaction created a synthetic PENDING
employee with a non-strict legacy ID containing `/`, its historical
photo reference, and a valid synthetic pending ownership proof. The
Production-derived historical 15-arg function returned
`ok:true,result:PENDING` and preserved the exact photo path.
All QA changes were **ROLLED BACK**. This does not modify or
test any of the 16 real Production employees and is not a replacement
for their ongoing private image-display path validation.

No Production SQL was applied; no production image or employee row
was downloaded, updated, overwritten, moved or removed.

## Confirmed separate image-display release blocker (read-only Edge review)
Production `employee-photo-url` **v2** authorizes employee/device photo
access using the **legacy sanitized employee ID folder**. The reviewed
new image uploader uses a **SHA-256-derived folder** for otherwise accepted
new identifiers containing characters outside `[A-Za-z0-9_-]`.
Therefore, promoting only the new onboarding backend would allow a
first-time nonstandard ID to register but could make that person's photo
inaccessible on Production profile/verification via resolver v2.

Isolated Staging resolver **v8** instead supports verified exact
registered photo-path binding and was exercised in the earlier synthetic
image-download test, but replacing Production v2 with v8 without its
complete independent legacy-cohort compatibility audit is **not
authorized**. Do not overwrite/rename/recompress any historical photo.
A new-only compatible resolver strategy and QA tests must be reviewed
before enabling onboarding on Production. This is an explicit
**NO-GO release gate** even if SQL parity checks pass.
