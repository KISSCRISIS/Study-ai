-- Fictitious ID containing a slash, hashed photo path, all rolled back.
-- This script MUST run only on an isolated existing Staging QA environment.
BEGIN;
DO $guard$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING')
 OR to_regprocedure('public.resolve_attested_new_employee_photo(text,text)') IS NOT NULL
 OR EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA/NEW-20261111')
 THEN RAISE EXCEPTION 'not isolated QA staging'; END IF;
END; $guard$;
CREATE OR REPLACE FUNCTION public.resolve_attested_new_employee_photo(
 p_employee_id text,p_object_path text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $fn$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id,''));
  v_object_path text := btrim(coalesce(p_object_path,''));
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
     OR v_employee_id='' OR char_length(v_employee_id)>32 OR v_employee_id ~ '[[:cntrl:]]'
     OR v_object_path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  RETURN jsonb_build_object('ok',EXISTS(
    SELECT 1 FROM public.employee_registrations r
    JOIN private.legacy_registration_cutoff c ON c.singleton=true
    JOIN private.new_employee_photo_attestations a
      ON a.employee_id=r.employee_id AND a.object_path=r.employee_photo_url
    JOIN storage.objects o
      ON o.bucket_id='employee-photos' AND o.name=a.object_path
    WHERE r.employee_id=v_employee_id AND r.employee_photo_url=v_object_path
      AND r.created_at>c.freeze_at
      AND r.status IN ('PENDING','APPROVED')
  ));
END;
$fn$;

REVOKE ALL ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 TO service_role;

CREATE TEMP TABLE qa_new_photo_setup(emp_id text,photo_path text) ON COMMIT DROP;
INSERT INTO qa_new_photo_setup SELECT 'QA/NEW-20261111',
 'registrations/'||encode(extensions.digest(convert_to('employee-photo-folder-v1:QA/NEW-20261111','UTF8'),'sha256'),'hex')||'/abc12345-1234-4234-a234-123456789abc.jpg';
INSERT INTO storage.objects(bucket_id,name,metadata)
 SELECT 'employee-photos',photo_path,'{"mimetype":"image/jpeg","size":613}'::jsonb FROM qa_new_photo_setup;
INSERT INTO public.employee_registrations(full_name,employee_id,mobile_number,specialty,job_type,department,
 employee_photo_url,registration_category,status,first_entry_used,created_at)
 SELECT 'QA NEW-ONLY SYNTHETIC',emp_id,'0000000000','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',
 'طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)',photo_path,'PERMANENT','PENDING',false,clock_timestamp() FROM qa_new_photo_setup;
INSERT INTO private.new_employee_photo_attestations(object_path,employee_id)
 SELECT photo_path,emp_id FROM qa_new_photo_setup;
SELECT set_config('request.jwt.claim.role','service_role',true);
SELECT
 public.resolve_attested_new_employee_photo((SELECT emp_id FROM qa_new_photo_setup),(SELECT photo_path FROM qa_new_photo_setup)) AS new_nonstandard_id_authorized,
 public.resolve_attested_new_employee_photo('QA-PR58!STAGING',(SELECT photo_path FROM qa_new_photo_setup)) AS old_id_wrong_photo_denied,
 public.resolve_attested_new_employee_photo((SELECT emp_id FROM qa_new_photo_setup),'registrations/someone-else/fake.jpg') AS wrong_photo_denied,
 (SELECT count(*) FROM public.employee_registrations WHERE employee_id='QA/NEW-20261111') AS synthetic_rows_inside_tx;
ROLLBACK;
