-- Isolated Staging only: every CREATE/GRANT below is rolled back.
-- Never run in Production: guard requires a pre-existing fictitious QA row
-- that has never existed in the historical Production cohort.
BEGIN;
DO $qa_guard$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING')
 OR NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA261108-5751216')
 OR to_regprocedure('public.resolve_attested_new_employee_photo(text,text)') IS NOT NULL
 THEN RAISE EXCEPTION 'ABORT: not original isolated Staging QA database'; END IF;
END; $qa_guard$;
CREATE OR REPLACE FUNCTION public.resolve_attested_new_employee_photo(
 p_employee_id text,p_object_path text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $fn$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id,''));
  v_object_path text := btrim(coalesce(p_object_path,''));
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
     OR v_employee_id='' OR char_length(v_employee_id)>32 OR v_employee_id ~ '[[:cntrl:]]'
     OR v_object_path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  RETURN jsonb_build_object('ok',EXISTS(
    SELECT 1 FROM public.employee_registrations r
    JOIN private.legacy_registration_cutoff c ON c.singleton=true
    JOIN private.new_employee_photo_attestations a
      ON a.employee_id=r.employee_id AND a.object_path=r.employee_photo_url
    JOIN storage.objects o
      ON o.bucket_id='employee-photos' AND o.name=a.object_path
    WHERE r.employee_id=v_employee_id AND r.employee_photo_url=v_object_path
      AND r.created_at>c.freeze_at
      AND r.status IN ('PENDING','APPROVED')
  ));
END;
$fn$;

REVOKE ALL ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.resolve_attested_new_employee_photo(text,text)
 TO service_role;

CREATE TEMP TABLE photo_binding_qa_results(scenario text PRIMARY KEY, result jsonb) ON COMMIT DROP;
SELECT set_config('request.jwt.claim.role','service_role',true);
INSERT INTO photo_binding_qa_results VALUES
('new_attested',public.resolve_attested_new_employee_photo('QA261108-5751216',
 (SELECT employee_photo_url FROM public.employee_registrations WHERE employee_id='QA261108-5751216'))),
('old_unattested',public.resolve_attested_new_employee_photo('QA-PR58!STAGING',
 (SELECT employee_photo_url FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING'))),
('wrong_path',public.resolve_attested_new_employee_photo('QA261108-5751216',
 'registrations/QA261108-5751216/other.jpg'));
SELECT set_config('request.jwt.claim.role','anon',true);
INSERT INTO photo_binding_qa_results VALUES ('anon_claim_denied',
 public.resolve_attested_new_employee_photo('QA261108-5751216',
 (SELECT employee_photo_url FROM public.employee_registrations WHERE employee_id='QA261108-5751216')));
SELECT jsonb_object_agg(scenario,result) AS results,
 has_function_privilege('anon','public.resolve_attested_new_employee_photo(text,text)','EXECUTE') AS anon_execute,
 has_function_privilege('authenticated','public.resolve_attested_new_employee_photo(text,text)','EXECUTE') AS authenticated_execute,
 has_function_privilege('service_role','public.resolve_attested_new_employee_photo(text,text)','EXECUTE') AS service_role_execute
FROM photo_binding_qa_results;
ROLLBACK;
