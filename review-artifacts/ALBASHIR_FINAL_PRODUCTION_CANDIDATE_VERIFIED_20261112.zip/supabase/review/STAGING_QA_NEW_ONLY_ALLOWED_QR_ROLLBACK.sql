-- ISOLATED STAGING QA ONLY. Synthetic fixtures are transaction-scoped;
-- NO image bytes, no historical employee writes, no Production access.
BEGIN;
DO $qa_only$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING')
 OR EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-NEW-GUARD-20261111')
 OR to_regprocedure('public.resolve_new_allowed_guard_photo(text,text,text)') IS NOT NULL
 THEN RAISE EXCEPTION 'Not isolated Staging or conflicting QA fixture'; END IF;
END; $qa_only$;
CREATE OR REPLACE FUNCTION public.resolve_new_allowed_guard_photo(
  p_read_key text,p_employee_id text,p_object_path text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $new_guard$
DECLARE
  v_id text:=btrim(coalesce(p_employee_id,''));
  v_path text:=btrim(coalesce(p_object_path,''));
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
     OR coalesce(p_read_key,'') !~ '^[0-9a-f]{64}$'
     OR v_id='' OR char_length(v_id)>32 OR v_id ~ '[[:cntrl:]]'
     OR v_path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  RETURN jsonb_build_object('ok',EXISTS(
    SELECT 1 FROM private.public_guard_sessions s
    JOIN public.qr_sessions q ON q.id=s.qr_session_id
    JOIN public.employee_registrations r ON r.id=s.employee_registration_id
    JOIN private.legacy_registration_cutoff c ON c.singleton=true
    JOIN private.new_employee_photo_attestations a
      ON a.employee_id=r.employee_id AND a.object_path=r.employee_photo_url
    JOIN storage.objects o ON o.bucket_id='employee-photos' AND o.name=a.object_path
    WHERE s.read_key_hash=encode(extensions.digest(p_read_key,'sha256'),'hex')
      AND s.result='ALLOWED'
      AND s.expires_at>now() AND q.expires_at>now()
      AND r.employee_id=v_id AND r.employee_photo_url=v_path
      AND r.created_at>c.freeze_at AND r.status='APPROVED'
  ));
END;
$new_guard$;

REVOKE ALL ON FUNCTION public.resolve_new_allowed_guard_photo(text,text,text)
FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.resolve_new_allowed_guard_photo(text,text,text)
TO service_role;

CREATE TEMP TABLE qa_allowed_qr_sessions(name text,session_id uuid) ON COMMIT DROP;
INSERT INTO storage.objects(bucket_id,name,metadata)
VALUES('employee-photos','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg','{"size":613,"mimetype":"image/jpeg"}'::jsonb);
INSERT INTO public.employee_registrations(full_name,employee_id,mobile_number,specialty,job_type,department,employee_photo_url,registration_category,status,first_entry_used,created_at)
VALUES('QA GUARD SYNTHETIC','QA-NEW-GUARD-20261111','0000000000','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg','PERMANENT','APPROVED',false,clock_timestamp());
INSERT INTO private.new_employee_photo_attestations(object_path,employee_id)
VALUES('registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg','QA-NEW-GUARD-20261111');
INSERT INTO public.gate_devices(device_code,gate_name,is_active)
VALUES('QA-GATE-20261111','QA Staging Only',true);
INSERT INTO public.offline_device_tokens(gate_device_id,device_code,token_hash,is_active)
SELECT g.id,'QA-GATE-20261111',public.hash_offline_device_token('qa-guard-device-token-1111'),true
FROM public.gate_devices g WHERE g.device_code='QA-GATE-20261111';
WITH x AS (INSERT INTO public.qr_sessions(expires_at) VALUES(now()+interval '6 min') RETURNING id)
INSERT INTO qa_allowed_qr_sessions SELECT 'ALLOWED',id FROM x;
WITH x AS (INSERT INTO public.qr_sessions(expires_at) VALUES(now()+interval '6 min') RETURNING id)
INSERT INTO qa_allowed_qr_sessions SELECT 'DENIED',id FROM x;
WITH x AS (INSERT INTO public.qr_sessions(expires_at) VALUES(now()-interval '1 min') RETURNING id)
INSERT INTO qa_allowed_qr_sessions SELECT 'EXPIRED',id FROM x;
INSERT INTO private.public_guard_sessions(qr_session_id,read_key_hash,expires_at,result,employee_registration_id,decided_at)
SELECT qa.session_id,encode(extensions.digest(
 repeat(CASE qa.name WHEN 'ALLOWED' THEN 'a' WHEN 'DENIED' THEN 'b' ELSE 'c' END,64),'sha256'),'hex'),
 now()+interval '6 min',
 CASE WHEN qa.name='DENIED' THEN 'DENIED' ELSE 'ALLOWED' END,
 (SELECT id FROM public.employee_registrations WHERE employee_id='QA-NEW-GUARD-20261111'),now()
FROM qa_allowed_qr_sessions qa;
CREATE TEMP TABLE qa_qr_results(scenario text,response jsonb) ON COMMIT DROP;
SELECT set_config('request.jwt.claim.role','service_role',true);
INSERT INTO qa_qr_results VALUES
('gate_device_active',public.verify_gate_device_credentials('QA-GATE-20261111','qa-guard-device-token-1111')),
('allowed_new_photo',public.resolve_new_allowed_guard_photo(repeat('a',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg')),
('denied_new_photo',public.resolve_new_allowed_guard_photo(repeat('b',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg')),
('expired_new_photo',public.resolve_new_allowed_guard_photo(repeat('c',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg')),
('unknown_key_denied',public.resolve_new_allowed_guard_photo(repeat('d',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg')),
('wrong_id_denied',public.resolve_new_allowed_guard_photo(repeat('a',64),'NOT-THE-OWNER','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg')),
('wrong_path_denied',public.resolve_new_allowed_guard_photo(repeat('a',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/wrong.jpg'));
SELECT set_config('request.jwt.claim.role','anon',true);
INSERT INTO qa_qr_results VALUES('anon_claim_denied',public.resolve_new_allowed_guard_photo(repeat('a',64),'QA-NEW-GUARD-20261111','registrations/QA-NEW-GUARD-20261111/12345678-1234-4234-a234-123456789abc.jpg'));
SELECT jsonb_object_agg(scenario,response) AS results,
 has_function_privilege('anon','public.resolve_new_allowed_guard_photo(text,text,text)','EXECUTE') AS anon_execute,
 has_function_privilege('authenticated','public.resolve_new_allowed_guard_photo(text,text,text)','EXECUTE') AS authenticated_execute,
 has_function_privilege('service_role','public.resolve_new_allowed_guard_photo(text,text,text)','EXECUTE') AS service_execute
FROM qa_qr_results;
ROLLBACK;
