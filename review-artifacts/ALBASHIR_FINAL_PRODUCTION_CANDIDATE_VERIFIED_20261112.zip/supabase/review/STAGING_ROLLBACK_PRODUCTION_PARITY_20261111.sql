-- Test is STRICTLY ISOLATED STAGING and ALWAYS rolled back.
-- Never apply to Production: requires existing Staging QA-only marker.
BEGIN;
DO $qa_only$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PR58!STAGING')
  OR to_regnamespace('qa_prod_parity_1111') IS NOT NULL
  OR EXISTS(SELECT 1 FROM public.employee_registrations WHERE employee_id='QA-PROD-CORE-20261111')
 THEN RAISE EXCEPTION 'Not isolated Staging or QA markers conflict'; END IF;
END;
$qa_only$;
CREATE SCHEMA qa_prod_parity_1111;
CREATE OR REPLACE FUNCTION qa_prod_parity_1111.new_core(p_full_name text, p_employee_id text, p_mobile_number text, p_specialty text, p_qr_token text, p_job_type text, p_department text, p_photo_url text, p_device_token text, p_device_id text, p_device_type text, p_device_name text, p_user_agent text, p_registration_category text, p_affiliated_entity text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  reg record;
  qr_ok boolean := false;
  clean_name text := trim(coalesce(p_full_name, ''));
  clean_emp text := trim(coalesce(p_employee_id, ''));
  clean_mobile text := trim(coalesce(p_mobile_number, ''));
  clean_specialty_in text := trim(coalesce(p_specialty, ''));
  clean_job_in text := nullif(trim(coalesce(p_job_type, '')), '');
  clean_dept_in text := nullif(trim(coalesce(p_department, '')), '');
  clean_photo text := trim(coalesce(p_photo_url, ''));
  clean_device_token text := trim(coalesce(p_device_token, ''));
  clean_category text := upper(trim(coalesce(p_registration_category, '')));
  clean_affiliated text := nullif(trim(coalesce(p_affiliated_entity, '')), '');
  effective_specialty text;
  store_job_type text;
  store_department text;
  store_affiliated text;
begin
  if char_length(clean_name) > 120
     or char_length(clean_emp) > 32
     or char_length(clean_mobile) > 20
     or char_length(clean_specialty_in) > 80
     or char_length(coalesce(clean_affiliated, '')) > 120 then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'تجاوزت البيانات الحد المسموح لطول الحقول');
  end if;

  if clean_category not in ('PERMANENT', 'TEMPORARY') then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'نوع التسجيل غير صالح. اختر موظف دائم أو موظف مؤقت / خارجي');
  end if;

  if clean_name = '' or clean_emp = '' or clean_mobile = '' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الرجاء تعبئة الاسم ورقم الموظف/الوطني ورقم الهاتف');
  end if;

  if clean_photo = '' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الصورة الشخصية مطلوبة');
  end if;

  if clean_photo not like 'registrations/%'
     and clean_photo not like 'https://%' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'رابط الصورة الشخصية غير صالح');
  end if;

  if clean_category = 'PERMANENT' then
    if clean_job_in is null or clean_dept_in is null then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الوظيفة والقسم مطلوبان للموظف الدائم');
    end if;
    effective_specialty := clean_dept_in;
    store_job_type := clean_job_in;
    store_department := clean_dept_in;
    store_affiliated := null;
  else
    if clean_specialty_in = '' or clean_affiliated is null then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الاختصاص والجهة التابعة مطلوبان للموظف المؤقت / الخارجي');
    end if;
    effective_specialty := clean_specialty_in;
    if clean_affiliated in ('مستشفى الجراحة والجراحات التخصصية', 'مستشفى النسائية والتوليد والأطفال', 'مستشفى الباطني والأشعة والجلدية: العناية القلبية وغسيل الكلى', 'مستشفى الأورام والأشعة العلاجية') then
      if clean_job_in is null then
        return jsonb_build_object('ok', false, 'result', 'DENIED', 'message', 'الوظيفة مطلوبة عند اختيار المستشفى');
      end if;
      store_job_type := clean_job_in;
    else
      store_job_type := null;
    end if;
    store_department := null;
    store_affiliated := clean_affiliated;
    if not exists (
      select 1 from public.specialty_daily_limits
      where specialty_name = effective_specialty
        and is_active = true
    ) then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الاختصاص غير معتمد للتسجيل المؤقت / الخارجي');
    end if;
  end if;

  select *
  into reg
  from public.employee_registrations
  where employee_id = clean_emp
  limit 1
  for update;

  -- Safety against concurrent registrations: a new-only request must
  -- never update a previously inserted employee row.
  if reg.id is not null then
    return jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  end if;

  if reg.id is null then
    insert into public.employee_registrations (
      full_name,employee_id,mobile_number,specialty,job_type,department,employee_photo_url,
      registration_category,affiliated_entity,status,first_entry_used,first_entry_at,
      pending_trusted_device_token_hash,pending_trusted_device_id,pending_trusted_device_type,
      pending_trusted_device_name,pending_trusted_device_user_agent,pending_trusted_device_created_at
    )
    values (
      clean_name,clean_emp,clean_mobile,effective_specialty,store_job_type,store_department,clean_photo,
      clean_category,store_affiliated,'PENDING',false,null,
      case when length(clean_device_token) >= 40 then public.hash_trusted_device_token(clean_device_token) else null end,
      nullif(trim(coalesce(p_device_id, '')), ''),
      nullif(trim(coalesce(p_device_type, '')), ''),
      nullif(trim(coalesce(p_device_name, '')), ''),
      nullif(trim(coalesce(p_user_agent, '')), ''),
      case when length(clean_device_token) >= 40 then now() else null end
    )
    returning * into reg;
  else
    if reg.status = 'PENDING' then
      if length(clean_device_token) < 40
         or reg.pending_trusted_device_token_hash is null
         or reg.pending_trusted_device_token_hash <> public.hash_trusted_device_token(clean_device_token) then
        return jsonb_build_object('ok', false,'result', 'DENIED','message', 'تعذر التحقق من ملكية الطلب المعلق. استخدم الجهاز الذي أرسل الطلب أو راجع الإدارة');
      end if;

      update public.employee_registrations
      set mobile_number = clean_mobile,
          specialty = effective_specialty,
          job_type = store_job_type,
          department = store_department,
          employee_photo_url = clean_photo,
          registration_category = clean_category,
          affiliated_entity = store_affiliated
      where id = reg.id
      returning * into reg;
    end if;
  end if;

  if reg.status = 'REJECTED' then
    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'DENIED', 'REJECTED_EMPLOYEE');
    perform public.set_guard_status('DENIED', reg.full_name, reg.employee_id, 'تم رفض الطلب مسبقًا');
    return jsonb_build_object('ok', true, 'result', 'DENIED', 'message', 'تم رفض الطلب، يرجى مراجعة الإدارة');
  end if;

  if reg.status = 'APPROVED' then
    if clean_mobile = ''
       or trim(coalesce(reg.mobile_number, '')) <> clean_mobile then
      return jsonb_build_object(
        'ok', false,
        'result', 'DENIED',
        'message', 'تعذر التحقق من بيانات الموظف'
      );
    end if;

    return public.manual_employee_check(reg.employee_id, clean_mobile, p_qr_token);
  end if;

  if reg.first_entry_used = true then
    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'DENIED', 'PENDING_FIRST_ENTRY_ALREADY_USED');
    perform public.set_guard_status('DENIED', reg.full_name, reg.employee_id, 'طلب قيد المراجعة — تم استخدام الدخول الأول سابقًا');
    return jsonb_build_object('ok', true, 'result', 'DENIED', 'message', 'طلبك قيد المراجعة، وتم استخدام الدخول الأول سابقًا');
  end if;

  qr_ok := public.validate_and_use_qr_token(p_qr_token);

  if qr_ok then
    update public.employee_registrations
    set first_entry_used = true,
        first_entry_at = now()
    where id = reg.id
    returning * into reg;

    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason, qr_token)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'PENDING_FIRST_ENTRY', 'FIRST_ENTRY_AFTER_REGISTRATION',
      case when p_qr_token is null or p_qr_token = '' then null else p_qr_token::uuid end);
    perform public.set_guard_status('LIMITED', reg.full_name, reg.employee_id, 'دخول أول مرة — بانتظار موافقة الإدارة');
    return jsonb_build_object('ok', true, 'result', 'LIMITED', 'message', 'تم إرسال طلبك. تم السماح بدخول أول مرة فقط، والطلب بانتظار موافقة الإدارة');
  end if;

  return jsonb_build_object('ok', true, 'result', 'PENDING', 'message', 'تم إرسال طلبك، الرجاء انتظار موافقة الإدارة');
end;
$function$;
CREATE OR REPLACE FUNCTION qa_prod_parity_1111.classic(p_full_name text, p_employee_id text, p_mobile_number text, p_specialty text, p_qr_token text, p_job_type text, p_department text, p_photo_url text, p_device_token text, p_device_id text, p_device_type text, p_device_name text, p_user_agent text, p_registration_category text, p_affiliated_entity text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  reg record;
  qr_ok boolean := false;
  clean_name text := trim(coalesce(p_full_name, ''));
  clean_emp text := trim(coalesce(p_employee_id, ''));
  clean_mobile text := trim(coalesce(p_mobile_number, ''));
  clean_specialty_in text := trim(coalesce(p_specialty, ''));
  clean_job_in text := nullif(trim(coalesce(p_job_type, '')), '');
  clean_dept_in text := nullif(trim(coalesce(p_department, '')), '');
  clean_photo text := trim(coalesce(p_photo_url, ''));
  clean_device_token text := trim(coalesce(p_device_token, ''));
  clean_category text := upper(trim(coalesce(p_registration_category, '')));
  clean_affiliated text := nullif(trim(coalesce(p_affiliated_entity, '')), '');
  effective_specialty text;
  store_job_type text;
  store_department text;
  store_affiliated text;
begin
  if char_length(clean_name) > 120
     or char_length(clean_emp) > 32
     or char_length(clean_mobile) > 20
     or char_length(clean_specialty_in) > 80
     or char_length(coalesce(clean_affiliated, '')) > 120 then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'تجاوزت البيانات الحد المسموح لطول الحقول');
  end if;

  if clean_category not in ('PERMANENT', 'TEMPORARY') then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'نوع التسجيل غير صالح. اختر موظف دائم أو موظف مؤقت / خارجي');
  end if;

  if clean_name = '' or clean_emp = '' or clean_mobile = '' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الرجاء تعبئة الاسم ورقم الموظف/الوطني ورقم الهاتف');
  end if;

  if clean_photo = '' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الصورة الشخصية مطلوبة');
  end if;

  if clean_photo not like 'registrations/%'
     and clean_photo not like 'https://%' then
    return jsonb_build_object('ok', false,'result', 'DENIED','message', 'رابط الصورة الشخصية غير صالح');
  end if;

  if clean_category = 'PERMANENT' then
    if clean_job_in is null or clean_dept_in is null then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الوظيفة والقسم مطلوبان للموظف الدائم');
    end if;
    effective_specialty := clean_dept_in;
    store_job_type := clean_job_in;
    store_department := clean_dept_in;
    store_affiliated := null;
  else
    if clean_specialty_in = '' or clean_affiliated is null then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الاختصاص والجهة التابعة مطلوبان للموظف المؤقت / الخارجي');
    end if;
    effective_specialty := clean_specialty_in;
    if clean_affiliated in ('مستشفى الجراحة والجراحات التخصصية', 'مستشفى النسائية والتوليد والأطفال', 'مستشفى الباطني والأشعة والجلدية: العناية القلبية وغسيل الكلى', 'مستشفى الأورام والأشعة العلاجية') then
      if clean_job_in is null then
        return jsonb_build_object('ok', false, 'result', 'DENIED', 'message', 'الوظيفة مطلوبة عند اختيار المستشفى');
      end if;
      store_job_type := clean_job_in;
    else
      store_job_type := null;
    end if;
    store_department := null;
    store_affiliated := clean_affiliated;
    if not exists (
      select 1 from public.specialty_daily_limits
      where specialty_name = effective_specialty
        and is_active = true
    ) then
      return jsonb_build_object('ok', false,'result', 'DENIED','message', 'الاختصاص غير معتمد للتسجيل المؤقت / الخارجي');
    end if;
  end if;

  select *
  into reg
  from public.employee_registrations
  where employee_id = clean_emp
  limit 1
  for update;

  -- New security applies to first-time employees only. Every frozen
  -- historic row enters the original source branch below unchanged.
  if reg.id is null or not exists (
    select 1 from private.legacy_registration_cutoff c
    where c.singleton=true and reg.created_at <= c.freeze_at
  ) then
    return jsonb_build_object('ok',false,'result','DENIED',
      'message','هذا المسار للموظفين المسجلين سابقاً فقط');
  end if;

  if reg.id is null then
    insert into public.employee_registrations (
      full_name,employee_id,mobile_number,specialty,job_type,department,employee_photo_url,
      registration_category,affiliated_entity,status,first_entry_used,first_entry_at,
      pending_trusted_device_token_hash,pending_trusted_device_id,pending_trusted_device_type,
      pending_trusted_device_name,pending_trusted_device_user_agent,pending_trusted_device_created_at
    )
    values (
      clean_name,clean_emp,clean_mobile,effective_specialty,store_job_type,store_department,clean_photo,
      clean_category,store_affiliated,'PENDING',false,null,
      case when length(clean_device_token) >= 40 then public.hash_trusted_device_token(clean_device_token) else null end,
      nullif(trim(coalesce(p_device_id, '')), ''),
      nullif(trim(coalesce(p_device_type, '')), ''),
      nullif(trim(coalesce(p_device_name, '')), ''),
      nullif(trim(coalesce(p_user_agent, '')), ''),
      case when length(clean_device_token) >= 40 then now() else null end
    )
    returning * into reg;
  else
    if reg.status = 'PENDING' then
      if length(clean_device_token) < 40
         or reg.pending_trusted_device_token_hash is null
         or reg.pending_trusted_device_token_hash <> public.hash_trusted_device_token(clean_device_token) then
        return jsonb_build_object('ok', false,'result', 'DENIED','message', 'تعذر التحقق من ملكية الطلب المعلق. استخدم الجهاز الذي أرسل الطلب أو راجع الإدارة');
      end if;

      update public.employee_registrations
      set mobile_number = clean_mobile,
          specialty = effective_specialty,
          job_type = store_job_type,
          department = store_department,
          employee_photo_url = clean_photo,
          registration_category = clean_category,
          affiliated_entity = store_affiliated
      where id = reg.id
      returning * into reg;
    end if;
  end if;

  if reg.status = 'REJECTED' then
    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'DENIED', 'REJECTED_EMPLOYEE');
    perform public.set_guard_status('DENIED', reg.full_name, reg.employee_id, 'تم رفض الطلب مسبقًا');
    return jsonb_build_object('ok', true, 'result', 'DENIED', 'message', 'تم رفض الطلب، يرجى مراجعة الإدارة');
  end if;

  if reg.status = 'APPROVED' then
    if clean_mobile = ''
       or trim(coalesce(reg.mobile_number, '')) <> clean_mobile then
      return jsonb_build_object(
        'ok', false,
        'result', 'DENIED',
        'message', 'تعذر التحقق من بيانات الموظف'
      );
    end if;

    return public.manual_employee_check(reg.employee_id, clean_mobile, p_qr_token);
  end if;

  if reg.first_entry_used = true then
    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'DENIED', 'PENDING_FIRST_ENTRY_ALREADY_USED');
    perform public.set_guard_status('DENIED', reg.full_name, reg.employee_id, 'طلب قيد المراجعة — تم استخدام الدخول الأول سابقًا');
    return jsonb_build_object('ok', true, 'result', 'DENIED', 'message', 'طلبك قيد المراجعة، وتم استخدام الدخول الأول سابقًا');
  end if;

  qr_ok := public.validate_and_use_qr_token(p_qr_token);

  if qr_ok then
    update public.employee_registrations
    set first_entry_used = true,
        first_entry_at = now()
    where id = reg.id
    returning * into reg;

    insert into public.gate_access_logs (employee_registration_id, employee_id, mobile_number, full_name, specialty, result, reason, qr_token)
    values (reg.id, reg.employee_id, reg.mobile_number, reg.full_name, reg.specialty, 'PENDING_FIRST_ENTRY', 'FIRST_ENTRY_AFTER_REGISTRATION',
      case when p_qr_token is null or p_qr_token = '' then null else p_qr_token::uuid end);
    perform public.set_guard_status('LIMITED', reg.full_name, reg.employee_id, 'دخول أول مرة — بانتظار موافقة الإدارة');
    return jsonb_build_object('ok', true, 'result', 'LIMITED', 'message', 'تم إرسال طلبك. تم السماح بدخول أول مرة فقط، والطلب بانتظار موافقة الإدارة');
  end if;

  return jsonb_build_object('ok', true, 'result', 'PENDING', 'message', 'تم إرسال طلبك، الرجاء انتظار موافقة الإدارة');
end;
$function$;
CREATE OR REPLACE FUNCTION qa_prod_parity_1111.new_rpc(p_full_name text, p_employee_id text, p_mobile_number text, p_specialty text, p_qr_token text, p_job_type text, p_department text, p_photo_url text, p_device_token text, p_device_id text, p_device_type text, p_device_name text, p_user_agent text, p_registration_category text, p_affiliated_entity text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  clean_emp text := btrim(coalesce(p_employee_id, ''));
  clean_photo text := btrim(coalesce(p_photo_url, ''));
  folder text;
  expected_folder text;
BEGIN
  -- Use one opaque response for all ineligible requests. Never reveal an
  -- old employee's existence to the caller.
  IF clean_emp = '' OR char_length(clean_emp) > 32 OR
     clean_emp ~ '[[:cntrl:]]' OR
     clean_photo !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN
    RETURN jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  END IF;
  folder := split_part(clean_photo,'/',2);
  IF clean_emp ~ '^[A-Za-z0-9_-]{1,32}$' THEN
    expected_folder := clean_emp;
  ELSE
    expected_folder := encode(extensions.digest(
      convert_to('employee-photo-folder-v1:' || clean_emp,'UTF8'),'sha256'),'hex');
  END IF;
  IF folder <> expected_folder THEN
    RETURN jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  END IF;
  -- Require an already uploaded private synthetic/new image before even
  -- evaluating whether an employee ID exists; unauthenticated callers
  -- should not use this RPC to enumerate historical employee IDs.
  IF NOT EXISTS (
    SELECT 1 FROM private.pending_employee_uploads p
    JOIN storage.objects o
      ON o.bucket_id='employee-photos' AND o.name=p.object_path
    WHERE p.object_path=clean_photo AND p.status='PENDING'
  ) THEN
    RETURN jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  END IF;
  -- Only the validated upload server may attest a NEW employee photo. The
  -- classic browser's legacy pending-upload RPC cannot forge this binding.
  IF NOT EXISTS (
    SELECT 1 FROM private.new_employee_photo_attestations a
    WHERE a.object_path = clean_photo AND a.employee_id = clean_emp
  ) THEN
    RETURN jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.employee_registrations er
    WHERE er.employee_id=clean_emp
  ) THEN
    RETURN jsonb_build_object('ok',false,'result','DENIED',
      'message','تعذر إكمال طلب التسجيل الجديد.');
  END IF;
  -- The original Staging registration function keeps the final authoritative
  -- owner token and photo ledger checks. In a concurrent registration race
  -- the original PENDING-owner check denies ownership changes.
  RETURN qa_prod_parity_1111.new_core(
    p_full_name,p_employee_id,p_mobile_number,p_specialty,NULL,
    p_job_type,p_department,p_photo_url,p_device_token,p_device_id,
    p_device_type,p_device_name,p_user_agent,p_registration_category,
    p_affiliated_entity
  );
END;
$function$;
-- Only 613-byte fictitious JPEG METADATA; does not create or download image bytes.
INSERT INTO storage.objects(bucket_id,name,metadata)
VALUES('employee-photos','registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg','{"size":613,"mimetype":"image/jpeg"}'::jsonb);
INSERT INTO private.pending_employee_uploads(object_path,employee_id,status)
VALUES('registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg','QA-PROD-CORE-20261111','PENDING');
INSERT INTO private.new_employee_photo_attestations(object_path,employee_id)
VALUES('registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg','QA-PROD-CORE-20261111');
CREATE TEMP TABLE qa_prod_parity_results(scenario text,response jsonb) ON COMMIT DROP;
INSERT INTO qa_prod_parity_results VALUES('new_pending',qa_prod_parity_1111.new_rpc('QA SOURCE PARITY ONLY','QA-PROD-CORE-20261111','0000000000',NULL,NULL,'طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg',repeat('a',96),NULL,NULL,NULL,NULL,'PERMANENT',NULL));
INSERT INTO qa_prod_parity_results VALUES('duplicate_core_denied',qa_prod_parity_1111.new_core('QA SOURCE PARITY ONLY','QA-PROD-CORE-20261111','0000000000',NULL,NULL,'طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg',repeat('a',96),NULL,NULL,NULL,NULL,'PERMANENT',NULL));
INSERT INTO qa_prod_parity_results VALUES('new_id_legacy_denied',qa_prod_parity_1111.classic('QA SOURCE PARITY ONLY','QA-PROD-CORE-20261111','0000000000',NULL,NULL,'طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','registrations/QA-PROD-CORE-20261111/aa123456-78ab-41cd-91ab-123456789abc.jpg',repeat('a',96),NULL,NULL,NULL,NULL,'PERMANENT',NULL));
INSERT INTO qa_prod_parity_results VALUES('unregistered_legacy_denied',qa_prod_parity_1111.classic('QA UNKNOWN','QA-LEGACY-UNREGISTERED-1111','0000000000',NULL,NULL,'طبيب','الإسعاف والطوارئ (DRS/NRS/EMT/MLT)','registrations/QA-LEGACY-UNREGISTERED-1111/missing.jpg',repeat('f',96),NULL,NULL,NULL,NULL,'PERMANENT',NULL));
SELECT jsonb_object_agg(scenario,response ORDER BY scenario) AS scenarios,
 (SELECT count(*) FROM public.employee_registrations WHERE employee_id='QA-PROD-CORE-20261111') AS qa_rows_inside_transaction
FROM qa_prod_parity_results;
ROLLBACK;
-- After completion verify 0 persistent QA rows, objects, attestations,
-- pending-upload ledger entries, and 0 qa_prod_parity_1111 schema objects.
