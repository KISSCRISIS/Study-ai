-- LOCKED / REVIEW ONLY: never apply to Production or Staging without
-- independent security review and explicit release authorization.
DO $no_release$
BEGIN
  RAISE EXCEPTION 'REVIEW ONLY: QR ALLOWED photo verifier is not deployable';
END;
$no_release$;

-- Dedicated *new employee only* QR authorization. No change to the old
-- resolve_public_guard_photo() or existing guard/photo/employee data.
CREATE OR REPLACE FUNCTION public.resolve_new_allowed_guard_photo(
  p_read_key text,p_employee_id text,p_object_path text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'pg_catalog'
AS $new_guard$
DECLARE
  v_id text:=btrim(coalesce(p_employee_id,''));
  v_path text:=btrim(coalesce(p_object_path,''));
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role'
     OR coalesce(p_read_key,'') !~ '^[0-9a-f]{64}$'
     OR v_id='' OR char_length(v_id)>32 OR v_id ~ '[[:cntrl:]]'
     OR v_path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9-]{1,80}[.]jpg$'
  THEN RETURN jsonb_build_object('ok',false); END IF;

  RETURN jsonb_build_object('ok',EXISTS(
    SELECT 1 FROM private.public_guard_sessions s
    JOIN public.qr_sessions q ON q.id=s.qr_session_id
    JOIN public.employee_registrations r ON r.id=s.employee_registration_id
    JOIN private.legacy_registration_cutoff c ON c.singleton=true
    JOIN private.new_employee_photo_attestations a
      ON a.employee_id=r.employee_id AND a.object_path=r.employee_photo_url
    JOIN storage.objects o ON o.bucket_id='employee-photos' AND o.name=a.object_path
    WHERE s.read_key_hash=encode(extensions.digest(p_read_key,'sha256'),'hex')
      AND s.result='ALLOWED'
      AND s.expires_at>now() AND q.expires_at>now()
      AND r.employee_id=v_id AND r.employee_photo_url=v_path
      AND r.created_at>c.freeze_at AND r.status='APPROVED'
  ));
END;
$new_guard$;

REVOKE ALL ON FUNCTION public.resolve_new_allowed_guard_photo(text,text,text)
FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.resolve_new_allowed_guard_photo(text,text,text)
TO service_role;
