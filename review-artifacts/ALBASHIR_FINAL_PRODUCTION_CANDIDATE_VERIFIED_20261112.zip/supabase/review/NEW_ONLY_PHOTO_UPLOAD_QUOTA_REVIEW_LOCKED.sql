-- REVIEW ONLY. FAIL-CLOSED until separately authorized.
-- Keep the lock and every statement in one transaction: clients that continue
-- after an error cannot apply the remainder of this review file.
BEGIN;
DO $deployment_lock$
BEGIN
  RAISE EXCEPTION 'REVIEW ONLY: never deploy new-photo upload quota without explicit approval';
END;
$deployment_lock$;

-- Dedicated atomic quota table for new employee photo uploads.
-- Completely isolated in private schema. Zero reads, writes, alters, or deletions
-- of historical employee/photo/QR/approval or existing rate-limit data.
CREATE TABLE IF NOT EXISTS private.new_photo_upload_quotas (
  scope_key text PRIMARY KEY,
  window_started_at timestamptz NOT NULL,
  attempt_count integer NOT NULL CHECK (attempt_count >= 0),
  updated_at timestamptz NOT NULL
);

ALTER TABLE private.new_photo_upload_quotas ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private.new_photo_upload_quotas FROM PUBLIC, anon, authenticated, service_role;

-- Dedicated lease ledger to prevent double-release and replay attacks.
-- Every granted claim issues a cryptographically random lease_id.
-- Releasing requires an active 'CLAIMED' lease, which transitions to 'RELEASED'.
-- Duplicate release calls for the same lease return ALREADY_RELEASED and CANNOT
-- decrement quota counters again.
CREATE TABLE IF NOT EXISTS private.new_photo_upload_claims (
  lease_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  emp_scope text NOT NULL,
  src_scope text NOT NULL,
  emp_window_started_at timestamptz,
  src_window_started_at timestamptz,
  global_window_started_at timestamptz,
  status text NOT NULL CHECK (status IN ('CLAIMED', 'CONSUMED', 'FINALIZED', 'RELEASED', 'SUPERSEDED', 'EXPIRED')),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  finalized_at timestamptz,
  released_at timestamptz
);

CREATE INDEX IF NOT EXISTS new_photo_upload_claims_emp_idx
  ON private.new_photo_upload_claims(emp_scope, status, created_at);

-- Existing review installations may have created the lease table before the
-- window identifiers were added. Older leases are never refunded across windows.
ALTER TABLE private.new_photo_upload_claims
  ADD COLUMN IF NOT EXISTS emp_window_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS src_window_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS global_window_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS finalized_at timestamptz;

ALTER TABLE private.new_photo_upload_claims ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private.new_photo_upload_claims FROM PUBLIC, anon, authenticated, service_role;

-- Atomic quota claim function.
-- Designed for Edge Function (Argon) to call BEFORE photo upload handling.
-- Restricts:
--   1. Per Employee (by SHA-256 hash of clean employee_id)
--   2. Per Source (by SHA-256 hash of client fingerprint / hashed IP)
--   3. Global Hard Cap (system-wide concurrency/load brake)
CREATE OR REPLACE FUNCTION public.claim_new_photo_upload_quota(
  p_employee_id text,
  p_source_fingerprint text,
  p_max_per_emp integer DEFAULT 5,
  p_max_per_source integer DEFAULT 10,
  p_max_global integer DEFAULT 100,
  p_window_seconds integer DEFAULT 3600
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  v_employee_id text := btrim(coalesce(p_employee_id, ''));
  v_source text := btrim(coalesce(p_source_fingerprint, ''));
  v_window_sec integer := greatest(coalesce(p_window_seconds, 3600), 10);
  v_limit_emp integer := greatest(coalesce(p_max_per_emp, 5), 1);
  v_limit_src integer := greatest(coalesce(p_max_per_source, 10), 1);
  v_limit_global integer := greatest(coalesce(p_max_global, 100), 1);

  v_emp_scope text;
  v_src_scope text;
  v_global_scope text := 'global';

  v_now timestamptz := clock_timestamp();
  v_window_interval interval := (v_window_sec || ' seconds')::interval;

  rec record;
  v_emp_count integer := 0;
  v_emp_window timestamptz := v_now;
  v_src_count integer := 0;
  v_src_window timestamptz := v_now;
  v_global_count integer := 0;
  v_global_window timestamptz := v_now;

  v_retry_after integer := 0;
  v_lease_id uuid;
BEGIN
  -- Strict Service Role authorization check
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', 0,
      'reason', 'UNAUTHORIZED_ROLE'
    );
  END IF;

  -- Validate inputs: never store raw IP or allow control characters
  IF v_employee_id = '' OR char_length(v_employee_id) > 32 OR v_employee_id ~ '[[:cntrl:]]' THEN
    RETURN jsonb_build_object('allowed', false, 'retry_after_seconds', 0, 'reason', 'INVALID_EMPLOYEE_ID');
  END IF;

  IF v_source = '' OR char_length(v_source) > 128 OR v_source ~ '[[:cntrl:]]' THEN
    RETURN jsonb_build_object('allowed', false, 'retry_after_seconds', 0, 'reason', 'INVALID_SOURCE_FINGERPRINT');
  END IF;

  -- Derive deterministic SHA-256 scope keys. Never stores raw values.
  v_emp_scope := 'emp:' || encode(extensions.digest(convert_to('new-photo-upload-emp:' || v_employee_id, 'UTF8'), 'sha256'), 'hex');
  v_src_scope := 'src:' || encode(extensions.digest(convert_to('new-photo-upload-src:' || v_source, 'UTF8'), 'sha256'), 'hex');

  -- Bounded non-blocking housekeeping of expired quota & claims records
  DELETE FROM private.new_photo_upload_claims WHERE created_at < v_now - interval '7 days';
  DELETE FROM private.new_photo_upload_quotas WHERE scope_key IN (
    SELECT scope_key FROM private.new_photo_upload_quotas
    WHERE updated_at < v_now - interval '7 days'
    ORDER BY updated_at LIMIT 20
    FOR UPDATE SKIP LOCKED
  );

  -- Ensure quota counter rows exist before locking
  INSERT INTO private.new_photo_upload_quotas (scope_key, window_started_at, attempt_count, updated_at)
  VALUES
    (v_emp_scope, v_now, 0, v_now),
    (v_src_scope, v_now, 0, v_now),
    (v_global_scope, v_now, 0, v_now)
  ON CONFLICT (scope_key) DO NOTHING;

  -- 1. Inspect all three scopes under row locks in deterministic order (prevents deadlocks)
  FOR rec IN
    SELECT scope_key, window_started_at, attempt_count
    FROM private.new_photo_upload_quotas
    WHERE scope_key IN (v_emp_scope, v_src_scope, v_global_scope)
    ORDER BY scope_key
    FOR UPDATE
  LOOP
    IF rec.scope_key = v_emp_scope THEN
      IF rec.window_started_at <= v_now - v_window_interval THEN
        v_emp_count := 0;
        v_emp_window := v_now;
      ELSE
        v_emp_count := rec.attempt_count;
        v_emp_window := rec.window_started_at;
      END IF;
    ELSIF rec.scope_key = v_src_scope THEN
      IF rec.window_started_at <= v_now - v_window_interval THEN
        v_src_count := 0;
        v_src_window := v_now;
      ELSE
        v_src_count := rec.attempt_count;
        v_src_window := rec.window_started_at;
      END IF;
    ELSIF rec.scope_key = v_global_scope THEN
      IF rec.window_started_at <= v_now - v_window_interval THEN
        v_global_count := 0;
        v_global_window := v_now;
      ELSE
        v_global_count := rec.attempt_count;
        v_global_window := rec.window_started_at;
      END IF;
    END IF;
  END LOOP;

  -- 2. Check limits and calculate retry_after_seconds if exceeded
  IF v_emp_count >= v_limit_emp THEN
    v_retry_after := greatest(1, ceil(extract(epoch FROM ((v_emp_window + v_window_interval) - v_now)))::integer);
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', v_retry_after,
      'reason', 'QUOTA_EXCEEDED_EMPLOYEE',
      'scope', 'employee',
      'current', v_emp_count,
      'limit', v_limit_emp
    );
  END IF;

  IF v_src_count >= v_limit_src THEN
    v_retry_after := greatest(1, ceil(extract(epoch FROM ((v_src_window + v_window_interval) - v_now)))::integer);
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', v_retry_after,
      'reason', 'QUOTA_EXCEEDED_SOURCE',
      'scope', 'source',
      'current', v_src_count,
      'limit', v_limit_src
    );
  END IF;

  IF v_global_count >= v_limit_global THEN
    v_retry_after := greatest(1, ceil(extract(epoch FROM ((v_global_window + v_window_interval) - v_now)))::integer);
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', v_retry_after,
      'reason', 'QUOTA_EXCEEDED_GLOBAL',
      'scope', 'global',
      'current', v_global_count,
      'limit', v_limit_global
    );
  END IF;

  -- Distributed Edge Concurrency: check for active in-flight lease or active upload for this employee
  IF EXISTS (
    SELECT 1 FROM private.new_photo_upload_claims
    WHERE emp_scope = v_emp_scope
      AND status IN ('CLAIMED', 'CONSUMED')
      AND finalized_at IS NULL
      AND created_at > v_now - interval '60 seconds'
  ) THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', 60,
      'reason', 'CONCURRENT_UPLOAD_LOCKED',
      'scope', 'concurrent',
      'message', 'يوجد رفع صورة جارٍ لهذا الرقم حالياً. انتظر اكتمال الطلب الحالي.'
    );
  END IF;

  -- Invalidate any stale in-flight lease older than 60s for this employee
  UPDATE private.new_photo_upload_claims
  SET status = 'SUPERSEDED', released_at = v_now
  WHERE emp_scope = v_emp_scope
    AND status IN ('CLAIMED', 'CONSUMED')
    AND finalized_at IS NULL;

  -- 3. All within limits: atomically increment all three counters
  UPDATE private.new_photo_upload_quotas
  SET window_started_at = v_emp_window,
      attempt_count = v_emp_count + 1,
      updated_at = v_now
  WHERE scope_key = v_emp_scope;

  UPDATE private.new_photo_upload_quotas
  SET window_started_at = v_src_window,
      attempt_count = v_src_count + 1,
      updated_at = v_now
  WHERE scope_key = v_src_scope;

  UPDATE private.new_photo_upload_quotas
  SET window_started_at = v_global_window,
      attempt_count = v_global_count + 1,
      updated_at = v_now
  WHERE scope_key = v_global_scope;

  -- 4. Issue a single-use lease ticket for this claim
  v_lease_id := gen_random_uuid();
  INSERT INTO private.new_photo_upload_claims (
    lease_id, emp_scope, src_scope,
    emp_window_started_at, src_window_started_at, global_window_started_at,
    status, created_at
  ) VALUES (
    v_lease_id, v_emp_scope, v_src_scope,
    v_emp_window, v_src_window, v_global_window, 'CLAIMED', v_now
  );

  RETURN jsonb_build_object(
    'allowed', true,
    'lease_id', v_lease_id,
    'retry_after_seconds', 0,
    'reason', 'ALLOWED',
    'employee_remaining', v_limit_emp - (v_emp_count + 1),
    'source_remaining', v_limit_src - (v_src_count + 1),
    'global_remaining', v_limit_global - (v_global_count + 1)
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.claim_new_photo_upload_quota(text, text, integer, integer, integer, integer)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_new_photo_upload_quota(text, text, integer, integer, integer, integer)
  TO service_role;

-- Release quota via lease_id (Idempotent, Replay-Proof).
-- Strictly verifies that the lease is in 'CLAIMED' state before decrementing counters.
-- Multiple calls with the same lease_id return ALREADY_RELEASED and NEVER decrement twice.
CREATE OR REPLACE FUNCTION public.release_new_photo_upload_quota(
  p_lease_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  claim_rec record;
  rec record;
  v_now timestamptz := clock_timestamp();
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'UNAUTHORIZED_ROLE');
  END IF;

  IF p_lease_id IS NULL THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'INVALID_LEASE_ID');
  END IF;

  -- 1. Inspect claim state under lock
  SELECT * INTO claim_rec
  FROM private.new_photo_upload_claims
  WHERE lease_id = p_lease_id
  FOR UPDATE;

  IF claim_rec.lease_id IS NULL THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'LEASE_NOT_FOUND');
  END IF;

  IF claim_rec.status = 'RELEASED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'ALREADY_RELEASED', 'message', 'تم تحرير هذه الحصة مسبقاً');
  END IF;

  IF claim_rec.status = 'FINALIZED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'ALREADY_FINALIZED', 'message', 'تم تثبيت الحصة ولا يمكن تحريرها');
  END IF;

  IF claim_rec.status = 'CONSUMED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'ALREADY_CONSUMED', 'message', 'تم استهلاك الحصة بنجاح ولا يمكن تحريرها');
  END IF;

  IF claim_rec.status = 'SUPERSEDED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'LEASE_SUPERSEDED', 'message', 'تم استبدال هذا الحجز بحجز أحدث');
  END IF;

  IF claim_rec.status = 'EXPIRED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'LEASE_EXPIRED', 'message', 'انتهت صلاحية الحجز');
  END IF;

  IF claim_rec.status <> 'CLAIMED' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'LEASE_NOT_CLAIMED');
  END IF;

  -- 2. Transition lease state to RELEASED atomically
  UPDATE private.new_photo_upload_claims
  SET status = 'RELEASED',
      released_at = v_now
  WHERE lease_id = p_lease_id AND status = 'CLAIMED';

  -- 3. Decrement quota counters under deterministic lock ordering
  FOR rec IN
    SELECT scope_key, attempt_count, window_started_at
    FROM private.new_photo_upload_quotas
    WHERE scope_key IN (claim_rec.emp_scope, claim_rec.src_scope, 'global')
    ORDER BY scope_key
    FOR UPDATE
  LOOP
    -- A stale lease must never decrement an attempt in a newer window.
    IF (rec.scope_key = claim_rec.emp_scope AND rec.window_started_at = claim_rec.emp_window_started_at)
       OR (rec.scope_key = claim_rec.src_scope AND rec.window_started_at = claim_rec.src_window_started_at)
       OR (rec.scope_key = 'global' AND rec.window_started_at = claim_rec.global_window_started_at)
    THEN
      UPDATE private.new_photo_upload_quotas
      SET attempt_count = greatest(0, attempt_count - 1),
          updated_at = v_now
      WHERE scope_key = rec.scope_key;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'allowed', true,
    'lease_id', p_lease_id,
    'reason', 'RELEASED'
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.release_new_photo_upload_quota(uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.release_new_photo_upload_quota(uuid)
  TO service_role;

-- A caller must provide the exact lease. Remove the ambiguous older overload.
DROP FUNCTION IF EXISTS public.release_new_photo_upload_quota(text, text);

-- Confirm quota consumed on successful upload (Idempotent)
CREATE OR REPLACE FUNCTION public.consume_new_photo_upload_quota(
  p_lease_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  claim_rec record;
  v_updated integer := 0;
  v_now timestamptz := clock_timestamp();
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'UNAUTHORIZED_ROLE');
  END IF;

  IF p_lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_LEASE_ID');
  END IF;

  SELECT * INTO claim_rec
  FROM private.new_photo_upload_claims
  WHERE lease_id = p_lease_id
  FOR UPDATE;

  IF claim_rec.lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_NOT_FOUND', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'FINALIZED' THEN
    RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id, 'already_consumed', true, 'finalized', true);
  END IF;

  IF claim_rec.status = 'CONSUMED' THEN
    RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id, 'already_consumed', true);
  END IF;

  IF claim_rec.status = 'RELEASED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_RELEASED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'SUPERSEDED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'EXPIRED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status <> 'CLAIMED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_NOT_CLAIMED', 'lease_id', p_lease_id);
  END IF;

  -- Fencing Token Check: if a newer claim exists for this employee, this claim is superseded!
  IF EXISTS (
    SELECT 1 FROM private.new_photo_upload_claims
    WHERE emp_scope = claim_rec.emp_scope
      AND created_at > claim_rec.created_at
  ) THEN
    UPDATE private.new_photo_upload_claims
    SET status = 'SUPERSEDED', released_at = v_now
    WHERE lease_id = p_lease_id;
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;

  -- Absolute Lifetime Check: if older than 120s, mark expired
  IF claim_rec.created_at < v_now - interval '120 seconds' THEN
    UPDATE private.new_photo_upload_claims
    SET status = 'EXPIRED', released_at = v_now
    WHERE lease_id = p_lease_id;
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'lease_id', p_lease_id);
  END IF;

  UPDATE private.new_photo_upload_claims
  SET status = 'CONSUMED'
  WHERE lease_id = p_lease_id AND status = 'CLAIMED';

  GET DIAGNOSTICS v_updated = ROW_COUNT;
  IF v_updated <> 1 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_STATE_CONFLICT', 'lease_id', p_lease_id);
  END IF;

  RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id);
END;
$function$;

REVOKE ALL ON FUNCTION public.consume_new_photo_upload_quota(uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_new_photo_upload_quota(uuid)
  TO service_role;

-- Finalize quota claim after successful storage upload and attestation
CREATE OR REPLACE FUNCTION public.finalize_new_photo_upload_quota(
  p_lease_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  claim_rec record;
  v_updated integer := 0;
  v_now timestamptz := clock_timestamp();
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'UNAUTHORIZED_ROLE');
  END IF;

  IF p_lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_LEASE_ID');
  END IF;

  SELECT * INTO claim_rec
  FROM private.new_photo_upload_claims
  WHERE lease_id = p_lease_id
  FOR UPDATE;

  IF claim_rec.lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_NOT_FOUND', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'FINALIZED' THEN
    RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id, 'already_finalized', true);
  END IF;

  IF claim_rec.status = 'SUPERSEDED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'EXPIRED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'RELEASED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_RELEASED', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status NOT IN ('CLAIMED', 'CONSUMED') THEN
    RETURN jsonb_build_object('ok', false, 'reason', claim_rec.status, 'lease_id', p_lease_id);
  END IF;

  -- Fencing Token Check: if a newer claim exists for this employee, this claim is superseded!
  IF EXISTS (
    SELECT 1 FROM private.new_photo_upload_claims
    WHERE emp_scope = claim_rec.emp_scope
      AND created_at > claim_rec.created_at
  ) THEN
    UPDATE private.new_photo_upload_claims
    SET status = 'SUPERSEDED', released_at = v_now
    WHERE lease_id = p_lease_id;
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;

  UPDATE private.new_photo_upload_claims
  SET status = 'FINALIZED', finalized_at = v_now
  WHERE lease_id = p_lease_id AND status IN ('CLAIMED', 'CONSUMED');

  GET DIAGNOSTICS v_updated = ROW_COUNT;
  IF v_updated <> 1 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_STATE_CONFLICT', 'lease_id', p_lease_id);
  END IF;

  RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id, 'finalized', true);
END;
$function$;

REVOKE ALL ON FUNCTION public.finalize_new_photo_upload_quota(uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.finalize_new_photo_upload_quota(uuid)
  TO service_role;

-- Fencing check performed by the Edge function IMMEDIATELY BEFORE the
-- irreversible attestation step. Read-only: it never changes quota state.
-- Returns ok=true only while this lease is still the newest, un-finalized,
-- un-released claim of the employee. A lease that was superseded (for example
-- because it ran past the 60 s in-flight window and a newer upload started)
-- can therefore never attest a photo.
CREATE OR REPLACE FUNCTION public.assert_new_photo_upload_lease(
  p_lease_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  claim_rec record;
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'UNAUTHORIZED_ROLE');
  END IF;

  IF p_lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_LEASE_ID');
  END IF;

  -- FOR SHARE blocks a concurrent claim from superseding this row while we read it.
  SELECT * INTO claim_rec
  FROM private.new_photo_upload_claims
  WHERE lease_id = p_lease_id
  FOR SHARE;

  IF claim_rec.lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_NOT_FOUND', 'lease_id', p_lease_id);
  END IF;

  IF claim_rec.status = 'SUPERSEDED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;
  IF claim_rec.status = 'EXPIRED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'lease_id', p_lease_id);
  END IF;
  IF claim_rec.status = 'RELEASED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_RELEASED', 'lease_id', p_lease_id);
  END IF;
  IF claim_rec.status = 'FINALIZED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_FINALIZED', 'lease_id', p_lease_id);
  END IF;
  IF claim_rec.status NOT IN ('CLAIMED', 'CONSUMED') THEN
    RETURN jsonb_build_object('ok', false, 'reason', claim_rec.status, 'lease_id', p_lease_id);
  END IF;

  IF EXISTS (
    SELECT 1 FROM private.new_photo_upload_claims
    WHERE emp_scope = claim_rec.emp_scope
      AND created_at > claim_rec.created_at
  ) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'lease_id', p_lease_id);
  END IF;

  RETURN jsonb_build_object('ok', true, 'lease_id', p_lease_id);
END;
$function$;

REVOKE ALL ON FUNCTION public.assert_new_photo_upload_lease(uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.assert_new_photo_upload_lease(uuid)
  TO service_role;

-- ============================================================================
-- ATOMIC LEASE-VERIFYING ATTESTATION (Race Window Fix & Bypass Closure)
-- ============================================================================
-- Closes the race window between assert_new_photo_upload_lease and attestation:
-- checking lease ownership/fencing and writing attestation are executed atomically
-- inside the database within a single transaction under an exclusive FOR UPDATE lock.
-- Overloaded 3-argument variant: public.attest_new_employee_photo(text, text, uuid).
-- If another claim was created for this employee, or the lease expired, attestation
-- fails atomically and no attestation record is written.
CREATE OR REPLACE FUNCTION public.attest_new_employee_photo(
  p_employee_id text,
  p_object_path text,
  p_lease_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  eid text := btrim(coalesce(p_employee_id, ''));
  path text := btrim(coalesce(p_object_path, ''));
  expected_folder text;
  claim_rec record;
  v_emp_scope text;
BEGIN
  IF coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role'
     AND coalesce(current_setting('role', true), '') <> 'service_role'
     AND session_user <> 'service_role'
  THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'UNAUTHORIZED_ROLE');
  END IF;

  IF eid = '' OR char_length(eid) > 32 OR eid ~ '[[:cntrl:]]' OR
     path !~ '^registrations/[A-Za-z0-9_-]{1,64}/[A-Za-z0-9._-]{1,120}[.]jpg$'
  THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_INPUT');
  END IF;

  IF eid ~ '^[A-Za-z0-9_-]{1,32}$' THEN
    expected_folder := eid;
  ELSE
    expected_folder := encode(extensions.digest(
      convert_to('employee-photo-folder-v1:' || eid, 'UTF8'), 'sha256'), 'hex');
  END IF;

  IF split_part(path, '/', 2) <> expected_folder THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'FOLDER_MISMATCH');
  END IF;

  IF EXISTS (SELECT 1 FROM public.employee_registrations r WHERE r.employee_id = eid) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_REGISTERED');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM private.pending_employee_uploads p
    JOIN storage.objects o ON o.bucket_id = 'employee-photos' AND o.name = p.object_path
    WHERE p.object_path = path AND p.status = 'PENDING'
      AND lower(coalesce(o.metadata->>'mimetype', '')) = 'image/jpeg'
      AND coalesce((o.metadata->>'size')::bigint, 0) BETWEEN 1 AND 2097152
  ) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'PENDING_UPLOAD_NOT_FOUND');
  END IF;

  -- ATOMIC LEASE FENCING CHECK:
  IF p_lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_REQUIRED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  v_emp_scope := 'emp:' || encode(extensions.digest(convert_to('new-photo-upload-emp:' || eid, 'UTF8'), 'sha256'), 'hex');

  SELECT * INTO claim_rec
  FROM private.new_photo_upload_claims
  WHERE lease_id = p_lease_id
  FOR UPDATE;

  IF claim_rec.lease_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_NOT_FOUND', 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  IF claim_rec.emp_scope <> v_emp_scope THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EMPLOYEE_MISMATCH', 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  IF claim_rec.status = 'SUPERSEDED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;
  IF claim_rec.status = 'EXPIRED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;
  IF claim_rec.status = 'RELEASED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_RELEASED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;
  IF claim_rec.status = 'FINALIZED' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ALREADY_FINALIZED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;
  IF claim_rec.status NOT IN ('CLAIMED', 'CONSUMED') THEN
    RETURN jsonb_build_object('ok', false, 'reason', claim_rec.status, 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  IF clock_timestamp() > claim_rec.created_at + interval '60 seconds' THEN
    UPDATE private.new_photo_upload_claims
    SET status = 'EXPIRED'
    WHERE lease_id = p_lease_id;
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_EXPIRED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  -- Check if a newer claim exists for this employee (lease superseded by another request)
  IF EXISTS (
    SELECT 1 FROM private.new_photo_upload_claims
    WHERE emp_scope = claim_rec.emp_scope
      AND created_at > claim_rec.created_at
  ) THEN
    UPDATE private.new_photo_upload_claims
    SET status = 'SUPERSEDED'
    WHERE lease_id = p_lease_id;
    RETURN jsonb_build_object('ok', false, 'reason', 'LEASE_SUPERSEDED', 'code', 'UPLOAD_SUPERSEDED');
  END IF;

  -- Atomic attestation write
  INSERT INTO private.new_employee_photo_attestations(object_path, employee_id)
  VALUES (path, eid)
  ON CONFLICT (object_path) DO NOTHING;

  -- Atomically transition claim to CONSUMED if lease was provided
  UPDATE private.new_photo_upload_claims
  SET status = 'CONSUMED'
  WHERE lease_id = p_lease_id AND status = 'CLAIMED';

  RETURN jsonb_build_object(
    'ok', EXISTS(
      SELECT 1 FROM private.new_employee_photo_attestations a
      WHERE a.object_path = path AND a.employee_id = eid
    ),
    'lease_id', p_lease_id
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.attest_new_employee_photo(text, text, uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.attest_new_employee_photo(text, text, uuid)
  TO service_role;

-- Legacy 2-argument variant: strictly CLOSED to prevent bypassing upload lease check.
-- Any direct call without lease_id returns LEASE_REQUIRED and fails attestation.
CREATE OR REPLACE FUNCTION public.attest_new_employee_photo(
  p_employee_id text,
  p_object_path text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog'
AS $function$
BEGIN
  -- Strict security closure: A new registration is NEVER allowed to bypass
  -- quota, fencing, or lease checks. Calling attestation without a lease_id is rejected.
  RETURN jsonb_build_object(
    'ok', false,
    'reason', 'LEASE_REQUIRED',
    'code', 'UPLOAD_SUPERSEDED',
    'message', 'New employee photo attestation requires an active upload lease'
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.attest_new_employee_photo(text, text)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.attest_new_employee_photo(text, text)
  TO service_role;

-- The deployment lock at the top aborts the transaction, so this COMMIT never
-- applies changes while the file is marked REVIEW ONLY.
COMMIT;
