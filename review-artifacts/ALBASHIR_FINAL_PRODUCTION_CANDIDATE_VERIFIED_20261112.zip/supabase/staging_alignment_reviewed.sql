-- REVIEW ONLY: owner declined database application on 2026-10-11.
-- Isolated tests passed; NOT APPLIED. Requires a new explicit approval.
-- Staging & Production Stage 1 alignment: unified guard manual/emergency routines.
BEGIN;
INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
VALUES('admin-avatars','admin-avatars',false,2097152,ARRAY['image/jpeg'])
ON CONFLICT (id) DO NOTHING;
DROP POLICY IF EXISTS "Admin deletes own avatar" ON storage.objects;
CREATE POLICY "Admin deletes own avatar" ON storage.objects FOR DELETE TO authenticated USING (((bucket_id = 'admin-avatars'::text) AND is_admin() AND ((storage.foldername(name))[1] = (auth.uid())::text))) ;
DROP POLICY IF EXISTS "Admin reads own avatar" ON storage.objects;
CREATE POLICY "Admin reads own avatar" ON storage.objects FOR SELECT TO authenticated USING (((bucket_id = 'admin-avatars'::text) AND is_admin() AND ((storage.foldername(name))[1] = (auth.uid())::text))) ;
DROP POLICY IF EXISTS "Admin uploads own avatar" ON storage.objects;
CREATE POLICY "Admin uploads own avatar" ON storage.objects FOR INSERT TO authenticated WITH CHECK (((bucket_id = 'admin-avatars'::text) AND is_admin() AND (name ~ (('^'::text || (auth.uid())::text) || '/[a-f0-9-]{36}[.]jpg$'::text))));
ALTER TABLE private.guard_manual_entries ADD COLUMN IF NOT EXISTS screen_read_key_hash text;

CREATE OR REPLACE FUNCTION private.guard_qr_generation_failure_status()
 RETURNS jsonb
 LANGUAGE plpgsql
 VOLATILE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public', 'private', 'extensions'
AS $function$
declare
  probe jsonb;
  probe_token text;
  probe_read_key text;
begin
  probe := public.create_public_guard_qr();
  if coalesce(probe->>'ok','false') = 'true' then
    probe_token := nullif(probe->>'token','');
    probe_read_key := nullif(probe->>'read_key','');
    if probe_read_key is not null then
      delete from private.public_guard_sessions
      where read_key_hash = encode(extensions.digest(probe_read_key,'sha256'),'hex');
    end if;
    if probe_token is not null then
      delete from public.qr_sessions
      where token::text = probe_token;
    end if;
    return jsonb_build_object(
      'failed', false,
      'code', 'QR_HEALTHY',
      'probe', jsonb_build_object('ok', true)
    );
  end if;

  if probe->>'error' = 'QR_GENERATION_FAILED' then
    return jsonb_build_object(
      'failed', true,
      'code', 'QR_GENERATION_FAILED',
      'probe', probe
    );
  end if;

  return jsonb_build_object(
    'failed', false,
    'code', coalesce(nullif(probe->>'error',''), 'QR_UNVERIFIED'),
    'probe', coalesce(probe, '{}'::jsonb)
  );
end;
$function$
;

CREATE OR REPLACE FUNCTION public.guard_manual_employee_entry(p_token text, p_employee_id text, p_request_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public', 'private', 'extensions'
AS $function$
declare g_id uuid; reg public.employee_registrations%rowtype; q public.qr_sessions%rowtype;
  prior private.guard_manual_entries%rowtype; r jsonb; response jsonb; read_key text; emp text:=translate(trim(coalesce(p_employee_id,'')),'٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789');
begin
  g_id:=private.guard_session_id(p_token);
  if g_id is null then return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا'); end if;
  -- Lock the account against revocation for this decision, then recheck session.
  perform 1 from private.guard_accounts where id=g_id for share;
  if private.guard_session_id(p_token) is null then return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا'); end if;
  if p_request_id is null or length(emp) not between 1 and 100 then return jsonb_build_object('ok',false,'error','INVALID_EMPLOYEE_ID','message','أدخل الرقم الوظيفي أو الوطني'); end if;
  perform pg_advisory_xact_lock(610100902);
  select * into prior from private.guard_manual_entries where guard_id=g_id and request_id=p_request_id;
  if prior.request_id is not null then
    if prior.employee_id<>emp then return jsonb_build_object('ok',false,'error','REQUEST_MISMATCH'); end if;
    return prior.response;
  end if;
  if not coalesce((select bool_or(enabled) from private.guard_emergency_settings),false) then
    return jsonb_build_object('ok',false,'error','EMERGENCY_DISABLED','message','الدخول اليدوي للطوارئ غير مفعّل؛ راجع الإدارة');
  end if;
  if (select count(*) from private.guard_manual_entries where guard_id=g_id and created_at>now()-interval '1 minute')>=30 then
    return jsonb_build_object('ok',false,'error','RATE_LIMITED','message','محاولات كثيرة؛ انتظر دقيقة');
  end if;
  select * into reg from public.employee_registrations where employee_id=emp order by created_at desc limit 1;
  if reg.id is null then
    response:=jsonb_build_object('ok',true,'result','DENIED','message','الموظف غير موجود أو غير مصرح','employee',null,'counted',false);
  else
    -- Reuse the existing decision function, including status/device/specialty
    -- and daily-limit rules. A server-only single-use QR is issued ONLY after
    -- guard authorization; no caller receives or supplies this token.
    insert into public.qr_sessions(expires_at) values(now()+interval '30 seconds') returning * into q;
    r:=public.manual_employee_check(reg.employee_id,reg.mobile_number,q.token::text);
    read_key:=encode(extensions.gen_random_bytes(32),'hex');
    insert into private.public_guard_sessions(qr_session_id,read_key_hash,expires_at,result,employee_registration_id,decided_at)
    values(q.id,encode(extensions.digest(read_key,'sha256'),'hex'),now()+interval '60 seconds',
      case when r->>'result' in ('ALLOWED','LIMITED') then r->>'result' else 'DENIED' end,reg.id,now());
    response:=public.get_public_guard_result(read_key)||jsonb_build_object('message',r->>'message','read_key',read_key,
      'counted',(r->>'result') in ('ALLOWED','LIMITED'));
    update public.gate_access_logs set reason='GUARD_MANUAL_EMERGENCY:'||coalesce(reason,'') where qr_token=q.token;
  end if;
  insert into private.guard_manual_entries(guard_id,request_id,employee_id,response) values(g_id,p_request_id,emp,response);
  insert into public.admin_audit_logs(admin_auth_user_id,action,target_table,target_id,details)
  values(null,'GUARD_MANUAL_ENTRY','employee_registrations',reg.id::text,
    jsonb_build_object('guard_id',g_id,'request_id',p_request_id,'result',response->>'result','counted',response->'counted'));
  return response;
end; $function$
;

CREATE OR REPLACE FUNCTION public.guard_manual_employee_entry_v2(p_token text, p_employee_id text, p_request_id uuid, p_screen_read_key text DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public', 'private', 'extensions'
AS $function$
declare
  gid uuid;
  sid uuid;
  raw_key text := nullif(btrim(coalesce(p_screen_read_key, '')), '');
  h text;
  health jsonb;
  qr_failed boolean := false;
  q_expires timestamptz;
  s_expires timestamptz;
  prior private.guard_manual_entries%rowtype;
  r jsonb;
  emp text := translate(trim(coalesce(p_employee_id,'')),'٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789');
begin
  gid := private.guard_session_id(p_token);
  if gid is null then
    return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا');
  end if;
  perform 1 from private.guard_accounts where id=gid for share;
  if private.guard_session_id(p_token) is null then
    return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا');
  end if;

  if p_request_id is null then
    return jsonb_build_object('ok',false,'error','SCREEN_REQUIRED','message','يجب استخدام شاشة QR معروفة للخادم.');
  end if;

  if raw_key is not null and raw_key !~ '^[a-f0-9]{64}$' then
    return jsonb_build_object('ok',false,'error','SCREEN_REQUIRED','message','يجب استخدام شاشة QR معروفة للخادم.');
  end if;

  h := case
    when raw_key is null then 'COLD_START_NO_READ_KEY'
    else encode(extensions.digest(raw_key,'sha256'),'hex')
  end;

  perform pg_advisory_xact_lock(610100902);

  select * into prior
  from private.guard_manual_entries
  where guard_id=gid and request_id=p_request_id;

  if prior.request_id is not null then
    if prior.employee_id is distinct from emp or prior.screen_read_key_hash is distinct from h then
      return jsonb_build_object('ok',false,'error','REQUEST_MISMATCH','message','لا يمكن إعادة استخدام الطلب لبيانات مختلفة.');
    end if;
    if prior.created_at < now()-interval '30 seconds' then
      return jsonb_build_object('ok',false,'error','RETRY_EXPIRED','message','انتهت مهلة استعادة النتيجة.');
    end if;
    return prior.response;
  end if;

  if raw_key is not null then
    select s.id, q.expires_at, s.expires_at
    into sid, q_expires, s_expires
    from private.public_guard_sessions s
    join public.qr_sessions q on q.id=s.qr_session_id
    where s.read_key_hash=h;

    if sid is null or s_expires<=now() or q_expires>now() then
      return jsonb_build_object('ok',false,'error','SCREEN_NOT_EXPIRED','message','رمز الشاشة صالح أو انتهى إثبات الشاشة.');
    end if;
  end if;

  -- A browser-reported network/render failure or RATE_LIMITED is insufficient.
  health := private.guard_qr_generation_failure_status();
  qr_failed := coalesce((health->>'failed')::boolean, false);

  if not qr_failed then
    update private.guard_emergency_settings set enabled=false;
    insert into public.admin_audit_logs(action,target_table,target_id,details)
    values(
      'GUARD_MANUAL_ENTRY_DENIED_QR_HEALTHY',
      'guard_emergency_settings',
      'true',
      jsonb_build_object('guard_id',gid,'request_id',p_request_id,'cold_start',(raw_key is null),'qr_health',health)
    );
    if raw_key is null then
      return jsonb_build_object('ok',false,'error','SCREEN_REQUIRED','emergency_enabled',false,'message','رمز QR يعمل بشكل سليم؛ لا يُسمح بالدخول اليدوي بدون تعطل مؤكد.');
    end if;
    return jsonb_build_object('ok',false,'error','QR_AVAILABLE','emergency_enabled',false,'message','التوليد الخادمي متاح؛ حدّث QR وأعد المسح.');
  end if;

  -- Server detection of QR generation failure is sufficient to activate emergency mode.
  update private.guard_emergency_settings set enabled=true;

  r := public.guard_manual_employee_entry(p_token,p_employee_id,p_request_id);
  if coalesce((r->>'ok')::boolean,false) then
    update private.guard_manual_entries set screen_read_key_hash=h where guard_id=gid and request_id=p_request_id;
    insert into public.admin_audit_logs(action,target_table,target_id,details)
    values(
      'GUARD_SCREEN_EMERGENCY',
      'public_guard_sessions',
      coalesce(sid::text,'COLD_START'),
      jsonb_build_object('guard_id',gid,'request_id',p_request_id,'result',r->>'result','cold_start',(raw_key is null),'qr_health',health)
    );
  end if;
  return r;
end $function$
;

CREATE OR REPLACE FUNCTION public.guard_session_status(p_token text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public', 'private', 'extensions'
AS $function$
declare
  g_id uuid := private.guard_session_id(p_token);
  q jsonb;
  failed boolean := false;
  configured boolean := false;
begin
  if g_id is null then
    return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا');
  end if;

  q := private.guard_qr_generation_failure_status();
  failed := coalesce((q->>'failed')::boolean, false);
  select coalesce(bool_or(enabled), false) into configured from private.guard_emergency_settings;

  if failed and not configured then
    update private.guard_emergency_settings set enabled=true;
    configured := true;
    insert into public.admin_audit_logs(action,target_table,target_id,details)
    values(
      'GUARD_EMERGENCY_AUTO_ENABLED',
      'guard_emergency_settings',
      'true',
      jsonb_build_object('guard_id',g_id,'reason',q->>'code')
    );
  elsif not failed and configured then
    update private.guard_emergency_settings set enabled=false;
    configured := false;
    insert into public.admin_audit_logs(action,target_table,target_id,details)
    values(
      'GUARD_EMERGENCY_AUTO_DISABLED',
      'guard_emergency_settings',
      'true',
      jsonb_build_object('guard_id',g_id,'reason',q->>'code')
    );
  end if;

  return jsonb_build_object(
    'ok',true,
    'full_name',(select full_name from private.guard_accounts where id=g_id),
    'emergency_enabled',(failed and configured),
    'emergency_available',failed,
    'emergency_configured',configured,
    'emergency_reason',q->>'code',
    'qr_generation_failed',failed
  );
end; $function$
;

CREATE OR REPLACE FUNCTION public.guard_set_emergency(p_token text, p_enabled boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'private', 'public', 'extensions'
AS $function$
declare
  gid uuid := private.guard_session_id(p_token);
  q jsonb;
  failed boolean := false;
begin
  if gid is null then
    return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا');
  end if;
  if p_enabled is null then
    return jsonb_build_object('ok',false,'message','اختيار غير صالح');
  end if;
  perform 1 from private.guard_accounts where id=gid for share;
  if private.guard_session_id(p_token) is null then
    return jsonb_build_object('ok',false,'error','AUTH_REQUIRED','message','سجّل دخول الحارس أولًا');
  end if;

  q := private.guard_qr_generation_failure_status();
  failed := coalesce((q->>'failed')::boolean, false);

  if p_enabled and not failed then
    update private.guard_emergency_settings set enabled=false;
    insert into public.admin_audit_logs(action,target_table,target_id,details)
    values(
      'GUARD_EMERGENCY_ENABLE_DENIED',
      'guard_emergency_settings',
      'true',
      jsonb_build_object('guard_id',gid,'reason',q->>'code')
    );
    return jsonb_build_object(
      'ok',false,
      'error','QR_NOT_FAILED',
      'emergency_enabled',false,
      'emergency_available',false,
      'reason',q->>'code',
      'message','الدخول اليدوي لا يتاح إلا عند تعطل توليد QR الذي يرصده الخادم تلقائيًا'
    );
  end if;

  update private.guard_emergency_settings set enabled=(p_enabled and failed);
  insert into public.admin_audit_logs(action,target_table,target_id,details)
  values(
    'GUARD_SET_EMERGENCY',
    'guard_emergency_settings',
    'true',
    jsonb_build_object('guard_id',gid,'enabled',(p_enabled and failed),'qr_health',q)
  );
  return jsonb_build_object(
    'ok',true,
    'emergency_enabled',(p_enabled and failed),
    'emergency_available',failed,
    'reason',q->>'code',
    'message',case
      when p_enabled and failed then 'تم تفعيل الدخول اليدوي للطوارئ؛ كل زيارة تسجل وتحتسب'
      else 'تم إيقاف الدخول اليدوي للطوارئ'
    end
  );
end;$function$
;

REVOKE ALL ON FUNCTION private.guard_qr_generation_failure_status() FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.guard_manual_employee_entry(text,text,uuid) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.guard_manual_employee_entry_v2(text,text,uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.guard_manual_employee_entry_v2(text,text,uuid,text) TO anon,authenticated;
REVOKE ALL ON FUNCTION public.guard_session_status(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.guard_session_status(text) TO anon,authenticated;
REVOKE ALL ON FUNCTION public.guard_set_emergency(text,boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.guard_set_emergency(text,boolean) TO anon,authenticated;
NOTIFY pgrst,'reload schema';
COMMIT;
