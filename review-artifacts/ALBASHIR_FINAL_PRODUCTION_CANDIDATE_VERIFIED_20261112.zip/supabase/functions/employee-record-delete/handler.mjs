export async function handleDelete(request,ctx){
  if(request.method !== 'POST') return Response.json({ok:false,message:'POST required'},{status:405});
  let body;
  try { body=await request.json(); } catch { return Response.json({ok:false,message:'Invalid request'},{status:400}); }
  if(typeof body?.registration_id!=='string'||typeof body?.employee_id!=='string') return Response.json({ok:false,message:'Invalid request'},{status:400});
  const {data:approved,error}=await ctx.supabase.rpc('super_admin_delete_employee_record',{p_registration_id:body.registration_id,p_employee_id:body.employee_id});
  if(error||approved?.ok!==true) return Response.json({ok:false,message:approved?.message||'تعذر حذف السجل.'},{status:403});
  if(approved.complete) return Response.json({ok:true,message:'الحذف مكتمل بالفعل.'});
  try {
   const {data:job,error:jobError}=await ctx.supabaseAdmin.rpc('service_employee_deletion_job',{p_id:approved.job_id});
   if(jobError||job?.ok!==true) throw Error('Deletion job unavailable');
   if(!job.complete && job.paths.length){
    const {error:storageError}=await ctx.supabaseAdmin.storage.from('employee-photos').remove(job.paths);
    if(storageError) throw Error('Storage removal failed');
   }
   const {data:finished,error:finishError}=await ctx.supabaseAdmin.rpc('service_complete_employee_deletion',{p_id:approved.job_id,p_actor:ctx.userClaims.sub});
   if(finishError||finished?.ok!==true) throw Error('Removal not confirmed');
   return Response.json({ok:true,message:'تم حذف سجل الموظف والصور والأجهزة المرتبطة. بقي سجل الدخول والتدقيق محفوظًا.'});
  } catch {
   console.error('Employee deletion photo cleanup pending',approved.job_id);
   return Response.json({ok:false,pending_cleanup:true,message:'حُذف سجل الموظف، لكن تنظيف الصورة لم يكتمل. استخدم إعادة تنظيف الصورة في دليل الموظفين.'},{status:503});
  }
}
