import { withSupabase } from 'npm:@supabase/server@1.9.2';
import { handleDelete } from './handler.mjs';
export default { fetch: withSupabase({ auth: 'user' }, handleDelete) };
