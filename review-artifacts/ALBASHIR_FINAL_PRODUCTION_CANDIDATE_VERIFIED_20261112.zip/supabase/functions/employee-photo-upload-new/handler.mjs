// ============================================================================
// employee-photo-upload-new/handler.mjs
// Standalone, zero-touch upload validator, shared PostgreSQL quota consumer,
// and attester for first-time employee registrations (PR #61 + PR #62 + PR #63).
//
// Security & Operational Guarantees:
// 1. Shared PostgreSQL Quota (public.claim_new_photo_upload_quota):
//    - Enforces multi-level rate limits across all Edge Function instances:
//      Per-Employee, Per-Trusted-Source (when verified platform source exists),
//      and Global Hard Cap.
//    - Never trusts client-provided IP headers (X-Forwarded-For, X-Real-IP,
//      Forwarded, True-Client-IP). Only a platform-verified source passed by
//      the trusted gateway configuration is hashed and forwarded.
//    - Fails closed (503) when the quota RPC is unreachable, without deleting
//      any existing or prior photos.
// 2. Request Body Size & JPEG Structure Validation:
//    - Rejects bodies exceeding MAX_MULTIPART_BYTES before full buffering.
//    - Inspects real JPEG Magic Bytes (SOI 0xFFD8FF, SOF0/1/2 dimensions
//      1..4096, 8-bit precision, 1 or 3 channels, SOS 0xFFDA, EOI 0xFFD9).
// 3. Path Traversal & Shared-Folder Isolation:
//    - Rejects control chars, path traversal tokens, and punctuation-only IDs
//      (such as "-") so no new upload can ever land in registrations/-/.
//    - Derives 64-hex SHA-256 folder for non-standard/Arabic IDs.
// 4. Safe Uncertain-Outcome Handling:
//    - Never deletes an uploaded Storage object if a post-upload database/RPC
//      call fails with a timeout or uncertain transport error (outcomeUnknown),
//      preventing deletion of a photo that may have been attested or linked.
//    - Deletes the temporary object ONLY on a deterministic, confirmed DB
//      rejection prior to attestation completion.
// ============================================================================

const webcrypto = globalThis.crypto?.subtle
  ? globalThis.crypto
  : await import("node:crypto").then((m) => m.webcrypto);

export const BUCKET_ID = "employee-photos";
export const MIN_PHOTO_BYTES = 32;
export const MAX_PHOTO_BYTES = 2097152;
export const MAX_MULTIPART_BYTES = MAX_PHOTO_BYTES + 65536;
export const MAX_DIMENSION_PX = 4096;
export const DEDUP_TTL_MS = 5 * 60 * 1000;
export const DEFAULT_RETRY_AFTER_SECONDS = 600;

const SAFE_ID = /^[A-Za-z0-9_-]{1,32}$/;
const PUNCTUATION_ONLY_ID = /^[-_.\s]+$/;
const PATH_TRAVERSAL_TOKEN = /(\.\.|[\\/]|%2e|%2f|%5c)/i;
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const VALID_OBJECT_PATH = /^registrations\/[A-Za-z0-9_-]{1,64}\/[A-Za-z0-9-]{1,80}\.jpg$/;

export function validEmployeeId(value) {
  const id = String(value ?? "").trim();
  if (!id || Array.from(id).length > 32) return false;
  if (/[\u0000-\u001f\u007f]/.test(id)) return false;
  // Block punctuation-only IDs (such as "-") so a new registrant can NEVER
  // map to the legacy shared folder registrations/-/
  if (PUNCTUATION_ONLY_ID.test(id)) return false;
  if (id.includes("..") || id.includes("\\") || /%2e|%2f|%5c/i.test(id)) return false;
  return true;
}

export async function sha256Hex(inputBytes) {
  const bytes = inputBytes instanceof Uint8Array
    ? inputBytes
    : new TextEncoder().encode(String(inputBytes ?? ""));
  const digest = await webcrypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function folderFor(employeeId) {
  if (!validEmployeeId(employeeId)) return "";
  const clean = String(employeeId).trim();
  if (SAFE_ID.test(clean) && clean !== "-") return clean;
  return sha256Hex("employee-photo-folder-v1:" + clean);
}

/**
 * Derives a domain-separated SHA-256 source key ONLY from a platform-verified
 * source string (never from untrusted client headers like X-Forwarded-For).
 */
export async function deriveTrustedSourceKey(trustedSourceValue) {
  const raw = String(trustedSourceValue ?? "").trim();
  if (!raw || raw.length > 256 || /[\u0000-\u001f\u007f]/.test(raw)) return null;
  return "src:" + (await sha256Hex("new-photo-upload-source-v1:" + raw));
}

/**
 * Validates a Cloudflare Turnstile token using the official siteverify API.
 *
 * FAIL-CLOSED BY DEFAULT: the function behaves as "production" unless the
 * caller explicitly passes `allowTestTokens === true`. The Edge entry point
 * only does that for an explicitly local/test environment AND an explicit
 * opt-in variable; an unset or unknown environment is therefore treated as
 * production. Test tokens, Cloudflare's public test secrets and a missing
 * secret are all rejected unless `allowTestTokens` is true.
 */
const CLOUDFLARE_TEST_SECRET = /^[123]x0{10,}[A-Za-z0-9]*$/;
const LOCAL_TEST_TOKENS = new Set(["TEST_TURNSTILE_TOKEN"]);

export async function verifyCloudflareTurnstile(token, secretKey, remoteIp, fetchFn = globalThis.fetch, allowTestTokens = false) {
  const cleanToken = String(token ?? "").trim();
  const cleanSecret = String(secretKey ?? "").trim();
  const testMode = allowTestTokens === true;

  if (!testMode) {
    if (!cleanSecret || CLOUDFLARE_TEST_SECRET.test(cleanSecret)) {
      return { ok: false, code: "TURNSTILE_NOT_CONFIGURED", message: "خدمة التحقق الأمني غير مهيأة." };
    }
    if (!cleanToken) {
      return { ok: false, code: "MISSING_TURNSTILE_TOKEN", message: "رمز التحقق الأمني (Turnstile) مطلوب." };
    }
    if (LOCAL_TEST_TOKENS.has(cleanToken) || cleanToken.startsWith("XXXX.")) {
      return { ok: false, code: "INVALID_TURNSTILE_TOKEN", message: "رمز التحقق التجريبي غير مسموح به خارج الاختبارات المحلية." };
    }
  } else if (!cleanSecret) {
    // Local tests without a Turnstile secret: only the explicit local token passes.
    if (LOCAL_TEST_TOKENS.has(cleanToken)) return { ok: true, testMode: true };
    return { ok: false, code: cleanToken ? "INVALID_TURNSTILE_TOKEN" : "MISSING_TURNSTILE_TOKEN", message: "رمز التحقق الأمني (Turnstile) غير صالح." };
  }

  if (!cleanToken) {
    return { ok: false, code: "MISSING_TURNSTILE_TOKEN", message: "رمز التحقق الأمني (Turnstile) مطلوب." };
  }

  try {
    const body = new URLSearchParams();
    body.append("secret", cleanSecret);
    body.append("response", cleanToken);
    if (remoteIp) body.append("remoteip", String(remoteIp).trim());

    const res = await fetchFn("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body,
      headers: { "content-type": "application/x-www-form-urlencoded" }
    });

    if (!res.ok) {
      return { ok: false, code: "TURNSTILE_SERVICE_ERROR", message: "تعذر الاتصال بخدمة التحقق الأمني." };
    }

    const data = await res.json();
    if (data.success === true) {
      return { ok: true, data };
    }
    return {
      ok: false,
      code: "INVALID_TURNSTILE_TOKEN",
      message: "رمز التحقق الأمني غير صالح أو منتهي الصلاحية.",
      errors: data["error-codes"]
    };
  } catch (err) {
    return { ok: false, code: "TURNSTILE_NETWORK_ERROR", message: "فشل التحقق الأمني بسبب انقطاع الاتصال." };
  }
}

/**
 * Inspects raw bytes to verify genuine JPEG structure (Magic Bytes + markers +
 * frame dimensions + scan data). Rejects disguised PNG/HEIC/HTML/executables,
 * truncated files, or zero-dimension frames.
 */
export function validateJpegBytes(bytes) {
  if (!(bytes instanceof Uint8Array)) {
    return { ok: false, code: "INVALID_FILE_TYPE", message: "ملف الصورة غير صالح." };
  }
  if (bytes.byteLength < MIN_PHOTO_BYTES) {
    return { ok: false, code: "INVALID_JPEG_BYTES", message: "ملف الصورة فارغ أو تالف." };
  }
  if (bytes.byteLength > MAX_PHOTO_BYTES) {
    return { ok: false, code: "FILE_TOO_LARGE", message: "حجم الصورة يتجاوز 2 ميغابايت." };
  }
  if (bytes[0] !== 0xff || bytes[1] !== 0xd8 || bytes[2] !== 0xff) {
    return { ok: false, code: "INVALID_JPEG_MAGIC", message: "صيغة الصورة غير صالحة؛ يلزم ملف JPEG حقيقي." };
  }
  if (bytes[bytes.byteLength - 2] !== 0xff || bytes[bytes.byteLength - 1] !== 0xd9) {
    return { ok: false, code: "TRUNCATED_JPEG", message: "ملف الصورة غير مكتمل أو تالف." };
  }

  let offset = 2;
  let hasSof = false;
  let hasSos = false;
  let width = 0;
  let height = 0;

  while (offset < bytes.byteLength - 1) {
    if (bytes[offset] !== 0xff) {
      return { ok: false, code: "CORRUPT_JPEG_MARKER", message: "بنية ملف JPEG غير صالحة." };
    }
    while (offset < bytes.byteLength && bytes[offset] === 0xff) {
      offset++;
    }
    if (offset >= bytes.byteLength) break;
    const marker = bytes[offset++];

    if (marker === 0x00 || (marker >= 0xd0 && marker <= 0xd7) || marker === 0x01) {
      continue;
    }
    if (marker === 0xd9) {
      break;
    }
    if (offset + 1 >= bytes.byteLength) {
      return { ok: false, code: "TRUNCATED_JPEG_SEGMENT", message: "بنية ملف JPEG مقطوعة." };
    }
    const segmentLength = (bytes[offset] << 8) | bytes[offset + 1];
    if (segmentLength < 2 || offset + segmentLength > bytes.byteLength) {
      return { ok: false, code: "INVALID_JPEG_SEGMENT", message: "حجم مقطع JPEG غير صالح." };
    }

    if (marker === 0xc0 || marker === 0xc1 || marker === 0xc2) {
      if (segmentLength < 8) {
        return { ok: false, code: "INVALID_SOF_HEADER", message: "ترويسة أبعاد الصورة غير صالحة." };
      }
      const precision = bytes[offset + 2];
      height = (bytes[offset + 3] << 8) | bytes[offset + 4];
      width = (bytes[offset + 5] << 8) | bytes[offset + 6];
      const components = bytes[offset + 7];
      if (
        precision !== 8 ||
        width < 1 ||
        height < 1 ||
        width > MAX_DIMENSION_PX ||
        height > MAX_DIMENSION_PX ||
        (components !== 1 && components !== 3)
      ) {
        return { ok: false, code: "INVALID_IMAGE_DIMENSIONS", message: "أبعاد الصورة أو قنواتها اللونية غير مدعومة." };
      }
      hasSof = true;
    } else if (marker === 0xda) {
      if (!hasSof) {
        return { ok: false, code: "SOS_BEFORE_SOF", message: "بيانات الصورة غير صالحة." };
      }
      const scanDataStart = offset + segmentLength;
      if (scanDataStart >= bytes.byteLength - 2) {
        return { ok: false, code: "EMPTY_JPEG_SCAN", message: "ملف الصورة لا يحتوي على بيانات مصورة." };
      }
      hasSos = true;
      break;
    }

    offset += segmentLength;
  }

  if (!hasSof || !hasSos) {
    return { ok: false, code: "INCOMPLETE_JPEG_STRUCTURE", message: "ملف JPEG لا يحتوي على إطار صورة كامل." };
  }

  return { ok: true, width, height, byteLength: bytes.byteLength };
}

function corsHeaders(origin, allowedOrigins) {
  const allowList = String(allowedOrigins || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  if (!allowList.includes(origin)) return null;
  return {
    "access-control-allow-origin": origin,
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "apikey, authorization, content-type, x-client-info",
    "vary": "Origin"
  };
}

function jsonResponse(status, payload, cors = {}, extraHeaders = {}) {
  return {
    status,
    body: payload,
    headers: {
      "cache-control": "private, no-store",
      "pragma": "no-cache",
      "expires": "0",
      ...cors,
      ...extraHeaders
    }
  };
}

/**
 * Creates an in-process state helper ONLY for local concurrent request locking
 * and short-lived idempotent retry deduplication of already-attested digests.
 * Rate limiting is enforced authoritatively in PostgreSQL via
 * public.claim_new_photo_upload_quota.
 */
export function createUploadState() {
  return {
    inflightByEmployee: new Map(), // employeeId -> { fileHash }
    attestedByDigest: new Map() // fileHash -> { employeeId, path, expiresAt }
  };
}

const defaultState = createUploadState();

function pruneState(state, now) {
  for (const [hash, entry] of state.attestedByDigest.entries()) {
    if (entry.expiresAt <= now) {
      state.attestedByDigest.delete(hash);
    }
  }
}

function isUncertainOutcomeError(errOrResult) {
  if (!errOrResult) return false;
  if (errOrResult.outcomeUnknown === true || errOrResult.uncertain === true) return true;
  const msg = String(errOrResult.message || errOrResult.error || "").toLowerCase();
  return /timeout|timed out|abort|network|fetch|econnreset|socket|504|502/.test(msg);
}

export async function handleNewPhotoUpload(input, deps, state = defaultState) {
  const now = typeof deps?.now === "function" ? deps.now() : Date.now();
  const origin = String(input?.headers?.origin || "").trim();
  const cors = corsHeaders(origin, deps?.allowedOrigins);

  if (!cors) {
    return jsonResponse(403, { ok: false, code: "ORIGIN_DENIED", message: "تعذر رفع الصورة." }, {});
  }
  if (input?.method === "OPTIONS") {
    return { status: 204, body: null, headers: { ...cors, "cache-control": "no-store" } };
  }
  if (input?.method !== "POST") {
    return jsonResponse(405, { ok: false, code: "METHOD_NOT_ALLOWED", message: "طريقة الطلب غير مسموحة." }, cors);
  }

  // Enforce hard request body size limit before processing form contents
  if (input?.bodyTooLarge === true) {
    return jsonResponse(413, {
      ok: false,
      code: "REQUEST_TOO_LARGE",
      message: "حجم طلب رفع الصورة يتجاوز الحد المسموح (2 ميغابايت)."
    }, cors);
  }

  const form = input?.form;
  if (!form || typeof form !== "object") {
    return jsonResponse(400, { ok: false, code: "INVALID_FORM", message: "بيانات رفع الصورة غير صالحة." }, cors);
  }

  const employeeId = String(form.employee_id ?? "").trim();
  if (!validEmployeeId(employeeId)) {
    return jsonResponse(400, { ok: false, code: "INVALID_EMPLOYEE_ID", message: "رقم الموظف غير صالح." }, cors);
  }

  const fileName = String(form.fileName ?? "").trim();
  if (PATH_TRAVERSAL_TOKEN.test(fileName) || (fileName && !/^[A-Za-z0-9._-]{1,80}\.(jpg|jpeg)$/i.test(fileName))) {
    return jsonResponse(400, { ok: false, code: "INVALID_FILE_NAME", message: "اسم ملف الصورة غير صالح." }, cors);
  }

  const mimeType = String(form.mimeType ?? "").toLowerCase().trim();
  if (mimeType !== "image/jpeg") {
    return jsonResponse(400, { ok: false, code: "INVALID_MIME_TYPE", message: "صيغة الصورة غير مدعومة. يلزم ملف JPEG." }, cors);
  }

  const bytes = form.bytes instanceof Uint8Array ? form.bytes : null;
  if (bytes && bytes.byteLength > MAX_PHOTO_BYTES) {
    return jsonResponse(413, {
      ok: false,
      code: "FILE_TOO_LARGE",
      message: "حجم الصورة يتجاوز 2 ميغابايت."
    }, cors);
  }

  const jpegCheck = validateJpegBytes(bytes);
  if (!jpegCheck.ok) {
    const status = jpegCheck.code === "FILE_TOO_LARGE" ? 413 : 400;
    return jsonResponse(status, { ok: false, code: jpegCheck.code, message: jpegCheck.message }, cors);
  }

  // Cloudflare Turnstile gate: runs BEFORE dedupe, locks, quota and Storage so a
  // direct HTTP call can never reach any of them without a verified token.
  // The token travels ONLY in the multipart body (the browser sends no custom
  // Turnstile header, so CORS never has to allow one).
  const turnstileToken = String(form["cf-turnstile-response"] || form.turnstile_token || "").trim();

  // Fail closed: without a verifier the endpoint must not accept uploads.
  if (typeof deps?.verifyTurnstile !== "function") {
    return jsonResponse(503, {
      ok: false,
      code: "TURNSTILE_NOT_CONFIGURED",
      message: "خدمة التحقق الأمني غير مهيأة."
    }, cors);
  }
  {
    let turnstileCheck;
    try {
      turnstileCheck = await deps.verifyTurnstile(turnstileToken, input?.trustedSource);
    } catch {
      turnstileCheck = { ok: false, code: "TURNSTILE_SERVICE_ERROR", message: "تعذر الاتصال بخدمة التحقق الأمني." };
    }
    if (!turnstileCheck || turnstileCheck.ok !== true) {
      const code = turnstileCheck?.code || "TURNSTILE_VERIFICATION_FAILED";
      const unavailable = code === "TURNSTILE_NOT_CONFIGURED" || code === "TURNSTILE_SERVICE_ERROR" || code === "TURNSTILE_NETWORK_ERROR";
      return jsonResponse(unavailable ? 503 : 403, {
        ok: false,
        code,
        message: turnstileCheck?.message || "فشل التحقق الأمني (Turnstile). يرجى المحاولة مجدداً."
      }, cors);
    }
  }

  pruneState(state, now);
  const fileHash = await sha256Hex(bytes);

  // 1. Cross-employee photo reuse check & idempotent retry deduplication
  const priorDigestOwner = state.attestedByDigest.get(fileHash);
  if (priorDigestOwner && priorDigestOwner.expiresAt > now) {
    if (priorDigestOwner.employeeId !== employeeId) {
      return jsonResponse(403, {
        ok: false,
        code: "PHOTO_OWNERSHIP_CONFLICT",
        message: "لا يمكن استخدام صورة مرتبطة بطلب موظف آخر."
      }, cors);
    }
    return jsonResponse(200, {
      ok: true,
      path: priorDigestOwner.path,
      deduplicated: true
    }, cors);
  }

  // 2. Concurrent upload protection (per-employee lock)
  if (state.inflightByEmployee.has(employeeId)) {
    return jsonResponse(409, {
      ok: false,
      code: "UPLOAD_IN_PROGRESS",
      message: "يوجد رفع صورة جارٍ لهذا الرقم حالياً. انتظر اكتمال الطلب الحالي."
    }, cors);
  }

  state.inflightByEmployee.set(employeeId, { fileHash });
  let uploadedPath = "";
  let canSafelyRemoveOnDeterministicReject = false;
  let pendingLedgerRecorded = false;

  async function removeRejectedObject(path) {
    if (typeof deps.removeObject !== "function") {
      console.warn("PENDING_STORAGE_CLEANUP_UNAVAILABLE");
      return;
    }
    let removed;
    try { removed = await deps.removeObject(path); } catch {
      console.warn("PENDING_STORAGE_CLEANUP_FAILED");
      return;
    }
    if (removed?.ok !== true) {
      console.warn("PENDING_STORAGE_CLEANUP_FAILED");
      return;
    }
    if (!pendingLedgerRecorded) return;
    // The RPC deletes only unlinked ledger rows. Never confirm an uncertain
    // Storage result or an upload whose database outcome is unknown.
    try {
      const confirmed = await deps.confirmPendingRemoval?.(path);
      if (confirmed?.ok !== true) console.warn("PENDING_LEDGER_CLEANUP_FAILED");
    } catch { console.warn("PENDING_LEDGER_CLEANUP_FAILED"); }
  }

  try {
    // 2.5 Cloudflare Turnstile Verification Gate BEFORE Quota Claim (PR Security Hardening)
    // (Turnstile is verified before any state lookup, see above.)

    // 3. First-time registration eligibility gate (PR #62) BEFORE quota consumption or Storage write
    // Wait: Should eligibility or quota run first?
    // Running shared PostgreSQL quota first prevents unauthenticated callers from
    // enumerating historical employee IDs at unlimited rates!
    // Let's derive trusted source key ONLY from platform-verified input (never X-Forwarded-For).
    const sourceKey = await deriveTrustedSourceKey(input?.trustedSource ?? null)
      ?? "emp:" + await sha256Hex("new-photo-upload-unknown-source-v1:" + employeeId);

    if (typeof deps?.claimUploadQuota !== "function") {
      return jsonResponse(503, {
        ok: false,
        code: "QUOTA_SERVICE_UNAVAILABLE",
        message: "خدمة التحقق من حصص الرفع غير متاحة حالياً. حاول مرة أخرى."
      }, cors);
    }

    let quotaDecision;
    try {
      quotaDecision = await deps.claimUploadQuota({
        employeeId,
        sourceKey
      });
    } catch {
      // Fail closed on quota RPC outage without touching or deleting any photos
      return jsonResponse(503, {
        ok: false,
        code: "QUOTA_SERVICE_UNAVAILABLE",
        message: "تعذر التحقق من حصة رفع الصور حالياً. حاول مرة أخرى لاحقاً."
      }, cors);
    }

    if (!quotaDecision || typeof quotaDecision !== "object") {
      return jsonResponse(503, {
        ok: false,
        code: "QUOTA_SERVICE_UNAVAILABLE",
        message: "تعذر التحقق من حصة رفع الصور حالياً. حاول مرة أخرى لاحقاً."
      }, cors);
    }

    if (quotaDecision.allowed === false && (quotaDecision.reason === "QUOTA_EXCEEDED_EMPLOYEE" || quotaDecision.reason === "QUOTA_EXCEEDED_SOURCE" || quotaDecision.reason === "QUOTA_EXCEEDED_GLOBAL" || quotaDecision.reason === "CONCURRENT_UPLOAD_LOCKED")) {
      if (quotaDecision.reason === "CONCURRENT_UPLOAD_LOCKED" || quotaDecision.scope === "concurrent") {
        return jsonResponse(409, {
          ok: false,
          code: "UPLOAD_IN_PROGRESS",
          message: "يوجد رفع صورة جارٍ لهذا الرقم حالياً. انتظر اكتمال الطلب الحالي."
        }, cors);
      }
      const waitSec = Math.max(1, Math.min(3600, Number(quotaDecision.retry_after_seconds) || DEFAULT_RETRY_AFTER_SECONDS));
      return jsonResponse(
        429,
        {
          ok: false,
          code: "UPLOAD_RATE_LIMITED",
          scope: String(quotaDecision.scope || "quota"),
          retry_after_seconds: waitSec,
          message: quotaDecision.message || `تم تجاوز عدد محاولات رفع الصور. انتظر ${Math.ceil(waitSec / 60)} دقائق ثم حاول مجددًا.`
        },
        cors,
        { "retry-after": String(waitSec) }
      );
    }

    const leaseId = String(quotaDecision.lease_id || "");
    if (quotaDecision.allowed !== true || !UUID_V4.test(leaseId) || typeof deps?.consumeUploadQuota !== "function") {
      if (UUID_V4.test(leaseId) && typeof deps?.releaseUploadQuota === "function") {
        try { await deps.releaseUploadQuota(leaseId); } catch { /* best-effort reclaim */ }
      }
      return jsonResponse(503, {
        ok: false,
        code: "QUOTA_SERVICE_UNAVAILABLE",
        message: "تعذر التحقق من حصة رفع الصور حالياً. حاول مرة أخرى لاحقاً."
      }, cors);
    }

    // Charge every admitted attempt before eligibility or Storage. If the
    // consume outcome is uncertain, fail closed and never refund the lease.
    // If consume fails deterministically, reclaim the lease so the employee is not penalized.
    let consumption;
    let consumeError = null;
    try {
      consumption = await deps.consumeUploadQuota(leaseId);
    } catch (err) {
      consumption = null;
      consumeError = err;
    }
    if (consumption?.ok !== true || String(consumption.lease_id || "").toLowerCase() !== leaseId.toLowerCase()) {
      const isUncertain = isUncertainOutcomeError(consumeError) ||
                          consumption?.outcomeUnknown === true ||
                          isUncertainOutcomeError(consumption);
      if (isUncertain) {
        // Ambiguous failure: NEVER release lease! It may have been committed in PostgreSQL!
        return jsonResponse(503, {
          ok: false,
          code: "CONSUME_OUTCOME_UNCERTAIN",
          outcomeUnknown: true,
          message: "انتهت مهلة تأكيد حصة الرفع. أعد المحاولة دون فقدان الحصة."
        }, cors);
      }
      // Deterministic failure: only reclaim if DB rejected before consuming and lease is not finalized/superseded/expired
      if (typeof deps?.releaseUploadQuota === "function" &&
          consumption?.reason !== "ALREADY_RELEASED" &&
          consumption?.reason !== "ALREADY_CONSUMED" &&
          consumption?.reason !== "ALREADY_FINALIZED" &&
          consumption?.reason !== "LEASE_SUPERSEDED" &&
          consumption?.reason !== "LEASE_EXPIRED") {
        try { await deps.releaseUploadQuota(leaseId); } catch { /* best-effort reclaim */ }
      }
      return jsonResponse(503, {
        ok: false,
        code: "QUOTA_SERVICE_UNAVAILABLE",
        message: "تعذر تثبيت حصة رفع الصورة. حاول مرة أخرى لاحقاً."
      }, cors);
    }

    // 4. First-time registration eligibility check (PR #62) BEFORE writing bytes to Storage
    const eligibility = await deps.checkEligibility(employeeId);
    if (!eligibility || eligibility.ok !== true) {
      return jsonResponse(503, {
        ok: false,
        code: "ELIGIBILITY_UNAVAILABLE",
        message: "خدمة التحقق من التسجيل غير متاحة حالياً. حاول مرة أخرى."
      }, cors);
    }
    if (eligibility.is_new !== true) {
      return jsonResponse(403, {
        ok: false,
        code: "EXISTING_EMPLOYEE",
        message: "الموظف مسجل مسبقًا؛ استخدم صفحة التسجيل السابقة."
      }, cors);
    }

    // 5. Derive PR #62 / PR #63 compatible object path
    const folder = await folderFor(employeeId);
    const rawUuid = typeof deps?.randomUUID === "function"
      ? String(deps.randomUUID()).toLowerCase()
      : webcrypto.randomUUID().toLowerCase();
    if (!folder || folder === "-" || !UUID_V4.test(rawUuid)) {
      return jsonResponse(500, { ok: false, code: "PATH_GENERATION_FAILED", message: "تعذر تجهيز مسار الصورة." }, cors);
    }
    const objectPath = `registrations/${folder}/${rawUuid}.jpg`;
    if (!VALID_OBJECT_PATH.test(objectPath)) {
      return jsonResponse(500, { ok: false, code: "INVALID_GENERATED_PATH", message: "تعذر تجهيز مسار الصورة." }, cors);
    }

    // 6. Upload validated JPEG bytes to private Storage bucket (upsert: false prevents overwriting)
    const uploadResult = await deps.uploadObject(objectPath, bytes, "image/jpeg");
    if (!uploadResult || uploadResult.ok !== true) {
      return jsonResponse(503, {
        ok: false,
        code: "STORAGE_UPLOAD_FAILED",
        message: "تعذر رفع الصورة. حاول مرة أخرى."
      }, cors);
    }
    uploadedPath = objectPath;
    canSafelyRemoveOnDeterministicReject = true;

    // 7. Record PENDING upload in private.pending_employee_uploads ledger
    let pendingResult;
    try {
      pendingResult = await deps.registerPendingUpload(objectPath);
    } catch (err) {
      if (isUncertainOutcomeError(err)) {
        canSafelyRemoveOnDeterministicReject = false;
      }
      throw err;
    }
    if (!pendingResult || pendingResult.ok !== true) {
      if (!isUncertainOutcomeError(pendingResult) && canSafelyRemoveOnDeterministicReject) {
        await removeRejectedObject(objectPath);
      }
      uploadedPath = "";
      return jsonResponse(503, {
        ok: false,
        code: "PENDING_LEDGER_FAILED",
        message: "تعذر تسجيل الصورة المرفوعة. حاول مرة أخرى."
      }, cors);
    }

    pendingLedgerRecorded = true;

    // 7.5 FENCING CHECK before the irreversible attestation. A lease that was
    // superseded or expired (for example an upload that ran past the 60 s
    // in-flight window while a newer upload started) must never attest a photo.
    // Nothing has been attested yet, so deleting the not-yet-linked object is safe
    // when the rejection is deterministic. If the answer is uncertain we keep the
    // object (it is unlinked and the sweep owns it) and fail without a 201.
    if (typeof deps?.assertUploadLease !== "function") {
      return jsonResponse(503, {
        ok: false,
        code: "FENCING_UNAVAILABLE",
        message: "تعذر التحقق من صلاحية حجز الرفع. حاول مرة أخرى لاحقاً."
      }, cors);
    }
    let fence;
    let fenceError = null;
    try {
      fence = await deps.assertUploadLease(leaseId);
    } catch (err) {
      fence = null;
      fenceError = err;
    }
    if (!fence || fence.ok !== true) {
      const fenceUncertain = !!fenceError || !fence || fence.outcomeUnknown === true || isUncertainOutcomeError(fence);
      if (fenceUncertain) {
        canSafelyRemoveOnDeterministicReject = false;
        return jsonResponse(503, {
          ok: false,
          code: "FENCING_OUTCOME_UNKNOWN",
          outcomeUnknown: true,
          message: "تعذر التحقق من صلاحية حجز الرفع. أعد المحاولة."
        }, cors);
      }
      // Deterministic: the lease is no longer the owner. Nothing was attested.
      if (canSafelyRemoveOnDeterministicReject) {
        await removeRejectedObject(objectPath);
      }
      uploadedPath = "";
      return jsonResponse(409, {
        ok: false,
        code: "UPLOAD_SUPERSEDED",
        message: "تم استبدال هذا الرفع بطلب أحدث. يرجى إعادة المحاولة."
      }, cors);
    }

    // 8. Server-only atomic attestation in private.new_employee_photo_attestations
    // CRITICAL: We pass leaseId so DB verifies lease validity and attestation atomically in a single transaction.
    // If a concurrent request superseded this lease between step 7.5 and step 8,
    // the DB atomically detects it, rejects attestation, and leaves the new request's photo safe.
    let attested;
    try {
      attested = await deps.attestNewPhoto(employeeId, objectPath, leaseId);
    } catch (err) {
      canSafelyRemoveOnDeterministicReject = false;
      return jsonResponse(503, {
        ok: false,
        code: "ATTESTATION_OUTCOME_UNKNOWN",
        message: "انتهت مهلة توثيق الصورة. أعد المحاولة دون حذف الصورة."
      }, cors);
    }

    if (!attested || attested.ok !== true) {
      if (isUncertainOutcomeError(attested)) {
        canSafelyRemoveOnDeterministicReject = false;
        return jsonResponse(503, {
          ok: false,
          code: "ATTESTATION_OUTCOME_UNKNOWN",
          message: "حالة توثيق الصورة غير مؤكدة. أعد المحاولة."
        }, cors);
      }
      const reason = String(attested?.reason || "");
      const isSuperseded = reason === "LEASE_SUPERSEDED" || reason === "LEASE_EXPIRED" || attested?.code === "UPLOAD_SUPERSEDED";
      if (isSuperseded) {
        if (canSafelyRemoveOnDeterministicReject) {
          await removeRejectedObject(objectPath);
        }
        uploadedPath = "";
        return jsonResponse(409, {
          ok: false,
          code: "UPLOAD_SUPERSEDED",
          message: "تم استبدال هذا الحجز بطلب أحدث."
        }, cors);
      }
      // Confirmed deterministic rejection (e.g. employee registered concurrently)
      if (canSafelyRemoveOnDeterministicReject) {
        await removeRejectedObject(objectPath);
      }
      uploadedPath = "";
      return jsonResponse(403, {
        ok: false,
        code: "PHOTO_ATTESTATION_FAILED",
        message: "تعذر توثيق ملكية الصورة لطلب التسجيل الجديد."
      }, cors);
    }

    // From here on the photo IS attested. It must NEVER be deleted again: a
    // concurrent or retried registration may already reference it.
    canSafelyRemoveOnDeterministicReject = false;
    uploadedPath = "";

    // 9. Finalize the quota claim. HTTP 201 is returned ONLY when the database
    // positively confirms ok === true. Any failure, timeout, malformed answer or
    // missing dependency returns a non-2xx status and records nothing as done.
    if (typeof deps?.finalizeUploadQuota !== "function") {
      return jsonResponse(503, {
        ok: false,
        code: "FINALIZE_UNAVAILABLE",
        message: "تعذر تأكيد إتمام الرفع. حاول مرة أخرى لاحقاً."
      }, cors);
    }
    let finalization = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        finalization = await deps.finalizeUploadQuota(leaseId);
      } catch (err) {
        finalization = { ok: false, outcomeUnknown: true, reason: "FINALIZE_EXCEPTION" };
      }
      if (finalization?.ok === true) break;
      // Retry once only when the outcome is genuinely unknown (finalize is idempotent).
      const deterministic = finalization && finalization.outcomeUnknown !== true && !isUncertainOutcomeError(finalization);
      if (deterministic) break;
    }
    if (!finalization || finalization.ok !== true) {
      const reason = String(finalization?.reason || "");
      if (reason === "LEASE_SUPERSEDED" || reason === "LEASE_EXPIRED") {
        // The photo is attested (kept), but this upload no longer owns the slot.
        return jsonResponse(409, {
          ok: false,
          code: "UPLOAD_SUPERSEDED",
          message: "تم استبدال هذا الرفع بطلب أحدث. يرجى إعادة المحاولة."
        }, cors);
      }
      const uncertain = !finalization || finalization.outcomeUnknown === true || isUncertainOutcomeError(finalization);
      return jsonResponse(503, {
        ok: false,
        code: uncertain ? "FINALIZE_OUTCOME_UNCERTAIN" : "FINALIZE_FAILED",
        outcomeUnknown: uncertain,
        message: "تعذر تأكيد إتمام الرفع. حاول مرة أخرى بعد قليل."
      }, cors);
    }

    state.attestedByDigest.set(fileHash, {
      employeeId,
      path: objectPath,
      expiresAt: now + DEDUP_TTL_MS
    });

    return jsonResponse(201, {
      ok: true,
      path: objectPath
    }, cors);
  } catch (err) {
    if (uploadedPath && canSafelyRemoveOnDeterministicReject && !isUncertainOutcomeError(err)) {
      await removeRejectedObject(uploadedPath);
    }
    return jsonResponse(503, {
      ok: false,
      code: "UPLOAD_SERVICE_ERROR",
      message: "تعذر رفع الصورة حالياً. تحقق من الاتصال ثم حاول مجددًا."
    }, cors);
  } finally {
    state.inflightByEmployee.delete(employeeId);
  }
}
