// ============================================================================
// employee-photo-upload-new/index.ts
// Standalone Supabase Edge Function for first-time employee photo uploads.
// Integrates with PostgreSQL shared quota RPC (public.claim_new_photo_upload_quota)
// and PR #62 attestation RPCs while leaving Production v2 completely untouched.
// Service role key never leaves this server process.
// ============================================================================

import { createClient } from "npm:@supabase/supabase-js@2.117.2";
import {
  BUCKET_ID,
  MAX_MULTIPART_BYTES,
  MAX_PHOTO_BYTES,
  handleNewPhotoUpload,
  verifyCloudflareTurnstile
} from "./handler.mjs";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const ALLOWED_ORIGINS =
  Deno.env.get("NEW_EMPLOYEE_PHOTO_UPLOAD_ALLOWED_ORIGINS") ??
  Deno.env.get("NEW_EMPLOYEE_PHOTO_ALLOWED_ORIGINS") ??
  "";
// Optional platform-verified header name (e.g. "x-supabase-edge-client-id" when
// explicitly enabled by operator). Client-controlled IP headers (x-forwarded-for,
// x-real-ip, true-client-ip, forwarded) are NEVER trusted.
const TRUSTED_PLATFORM_SOURCE_HEADER = (
  Deno.env.get("NEW_UPLOAD_TRUSTED_PLATFORM_HEADER") ?? ""
).toLowerCase().trim();

const UNTRUSTED_CLIENT_IP_HEADERS = new Set([
  "x-forwarded-for",
  "x-real-ip",
  "x-client-ip",
  "true-client-ip",
  "forwarded",
  "cf-connecting-ip"
]);

if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !ALLOWED_ORIGINS) {
  throw new Error("New-only photo upload service is disabled until approved configuration");
}

const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});

/**
 * Reads request stream up to maxBytes, aborting immediately if the stream
 * exceeds the limit so oversized chunked requests cannot exhaust memory.
 */
async function readBoundedMultipart(request: Request, maxBytes = MAX_MULTIPART_BYTES) {
  const contentLengthHeader = request.headers.get("content-length");
  if (contentLengthHeader !== null) {
    const declaredLength = Number(contentLengthHeader);
    if (!Number.isFinite(declaredLength) || declaredLength < 0) return { invalid: true };
    if (declaredLength > maxBytes) return { bodyTooLarge: true };
  }
  const contentType = String(request.headers.get("content-type") || "");
  if (!contentType.toLowerCase().includes("multipart/form-data")) {
    return { invalid: true };
  }
  if (!request.body) return { invalid: true };

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let totalBytes = 0;

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      totalBytes += value.byteLength;
      if (totalBytes > maxBytes) {
        await reader.cancel();
        return { bodyTooLarge: true };
      }
      chunks.push(value);
    }
  } catch {
    return { invalid: true };
  } finally {
    reader.releaseLock();
  }

  const combined = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    combined.set(chunk, offset);
    offset += chunk.byteLength;
  }

  try {
    const syntheticReq = new Request("http://localhost/upload", {
      method: "POST",
      headers: { "content-type": contentType },
      body: combined
    });
    const formData = await syntheticReq.formData();
    const employeeId = formData.get("employee_id");
    const file = formData.get("file");
    const turnstileToken = String(formData.get("cf-turnstile-response") || formData.get("turnstile_token") || "").trim();
    if (typeof employeeId !== "string" || !(file instanceof File)) {
      return { invalid: true };
    }
    if (file.size > MAX_PHOTO_BYTES) {
      return { bodyTooLarge: true };
    }
    const bytes = new Uint8Array(await file.arrayBuffer());
    return {
      form: {
        employee_id: employeeId,
        fileName: file.name || "employee.jpg",
        mimeType: file.type || "image/jpeg",
        bytes,
        "cf-turnstile-response": turnstileToken
      }
    };
  } catch {
    return { invalid: true };
  }
}

function extractVerifiedPlatformSource(request: Request): string | null {
  if (
    !TRUSTED_PLATFORM_SOURCE_HEADER ||
    UNTRUSTED_CLIENT_IP_HEADERS.has(TRUSTED_PLATFORM_SOURCE_HEADER)
  ) {
    return null;
  }
  const val = request.headers.get(TRUSTED_PLATFORM_SOURCE_HEADER)?.trim() ?? "";
  return val ? val : null;
}

const deps = {
  allowedOrigins: ALLOWED_ORIGINS,
  async verifyTurnstile(token: string, remoteIp?: string) {
    const TURNSTILE_SECRET_KEY = Deno.env.get("TURNSTILE_SECRET_KEY") ?? "";
    // FAIL-CLOSED: test tokens are accepted ONLY when the environment is
    // explicitly a local/test one AND the operator opted in. An unset,
    // unknown or production environment never accepts them.
    const env = (Deno.env.get("ENVIRONMENT") || Deno.env.get("DENO_ENV") || "").toLowerCase();
    const allowTestTokens =
      ["local", "test", "development"].includes(env) &&
      Deno.env.get("TURNSTILE_ALLOW_TEST_TOKENS") === "true";
    return verifyCloudflareTurnstile(token, TURNSTILE_SECRET_KEY, remoteIp, globalThis.fetch, allowTestTokens);
  },
  async claimUploadQuota({ employeeId, sourceKey }: { employeeId: string; sourceKey: string | null }) {
    const { data, error } = await admin.rpc("claim_new_photo_upload_quota", {
      p_employee_id: employeeId,
      p_source_fingerprint: sourceKey
    });
    if (error) return { allowed: false, reason: "QUOTA_RPC_ERROR" };
    const row = Array.isArray(data) ? data[0] : data;
    if (!row || typeof row !== "object") return { allowed: false, reason: "QUOTA_RPC_ERROR" };
    return row;
  },
  async consumeUploadQuota(leaseId: string) {
    try {
      const { data, error } = await admin.rpc("consume_new_photo_upload_quota", { p_lease_id: leaseId });
      if (error) {
        const isTimeout = /timeout|abort|network|econnreset|econnrefused|fetch failed/i.test(error.message || "");
        return {
          ok: false,
          lease_id: leaseId,
          reason: error.code || "CONSUME_RPC_ERROR",
          error: error.message,
          outcomeUnknown: isTimeout
        };
      }
      const row = Array.isArray(data) ? data[0] : data;
      if (!row || typeof row !== "object") {
        return { ok: false, lease_id: leaseId, reason: "INVALID_RPC_RESPONSE", outcomeUnknown: true };
      }
      return {
        ok: row.ok === true,
        lease_id: row.lease_id || leaseId,
        reason: row.reason,
        already_consumed: row.already_consumed === true,
        finalized: row.finalized === true,
        outcomeUnknown: false
      };
    } catch (err: any) {
      return {
        ok: false,
        lease_id: leaseId,
        reason: "CONSUME_EXCEPTION",
        error: err?.message,
        outcomeUnknown: true
      };
    }
  },
  async assertUploadLease(leaseId: string) {
    try {
      const { data, error } = await admin.rpc("assert_new_photo_upload_lease", { p_lease_id: leaseId });
      if (error) {
        return { ok: false, lease_id: leaseId, reason: error.code || "FENCE_RPC_ERROR", outcomeUnknown: true };
      }
      const row = Array.isArray(data) ? data[0] : data;
      if (!row || typeof row !== "object") {
        return { ok: false, lease_id: leaseId, reason: "INVALID_RPC_RESPONSE", outcomeUnknown: true };
      }
      return { ok: row.ok === true, lease_id: row.lease_id || leaseId, reason: row.reason, outcomeUnknown: false };
    } catch {
      return { ok: false, lease_id: leaseId, reason: "FENCE_EXCEPTION", outcomeUnknown: true };
    }
  },
  async finalizeUploadQuota(leaseId: string) {
    try {
      const { data, error } = await admin.rpc("finalize_new_photo_upload_quota", { p_lease_id: leaseId });
      if (error) {
        return { ok: false, lease_id: leaseId, reason: error.code || "FINALIZE_RPC_ERROR", outcomeUnknown: true };
      }
      const row = Array.isArray(data) ? data[0] : data;
      if (!row || typeof row !== "object") {
        return { ok: false, lease_id: leaseId, reason: "INVALID_RPC_RESPONSE", outcomeUnknown: true };
      }
      return { ok: row.ok === true, lease_id: row.lease_id || leaseId, reason: row.reason, outcomeUnknown: false };
    } catch {
      return { ok: false, lease_id: leaseId, reason: "FINALIZE_EXCEPTION", outcomeUnknown: true };
    }
  },
  async releaseUploadQuota(leaseId: string) {
    const { data, error } = await admin.rpc("release_new_photo_upload_quota", { p_lease_id: leaseId });
    const row = Array.isArray(data) ? data[0] : data;
    return { ok: !error && row?.allowed === true, reason: row?.reason };
  },
  async checkEligibility(employeeId: string) {
    const { data, error } = await admin.rpc("employee_photo_new_registration_eligible", {
      p_employee_id: employeeId
    });
    const row = Array.isArray(data) ? data[0] : data;
    if (error || row?.ok !== true) return { ok: false };
    return { ok: true, is_new: row.is_new === true };
  },
  async uploadObject(path: string, bytes: Uint8Array, contentType: string) {
    const { error } = await admin.storage.from(BUCKET_ID).upload(path, bytes, {
      contentType,
      cacheControl: "0, no-store",
      upsert: false
    });
    return { ok: !error };
  },
  async registerPendingUpload(path: string) {
    const { data, error } = await admin.rpc("register_pending_employee_upload", {
      p_object_path: path
    });
    if (error) {
      const uncertain = /timeout|timed out|abort|network|fetch/i.test(String(error.message || ""));
      return { ok: false, outcomeUnknown: uncertain };
    }
    const row = Array.isArray(data) ? data[0] : data;
    return { ok: row?.ok === true, outcomeUnknown: false };
  },
  async attestNewPhoto(employeeId: string, path: string, leaseId?: string) {
    const { data, error } = await admin.rpc("attest_new_employee_photo", {
      p_employee_id: employeeId,
      p_object_path: path,
      p_lease_id: leaseId || null
    });
    if (error) {
      const uncertain = /timeout|timed out|abort|network|fetch/i.test(String(error.message || ""));
      return { ok: false, outcomeUnknown: uncertain, reason: error.message };
    }
    const row = Array.isArray(data) ? data[0] : data;
    return {
      ok: row?.ok === true,
      outcomeUnknown: false,
      reason: row?.reason,
      code: row?.code
    };
  },
  async removeObject(path: string) {
    const { error } = await admin.storage.from(BUCKET_ID).remove([path]);
    return { ok: !error };
  },
  async confirmPendingRemoval(path: string) {
    const { data, error } = await admin.rpc("employee_photo_confirm_removal", { p_paths: [path] });
    return { ok: !error, deleted: data };
  }
};

Deno.serve(async (request: Request) => {
  let parsed: { form?: unknown; bodyTooLarge?: boolean; invalid?: boolean } = {};
  if (request.method === "POST") {
    parsed = await readBoundedMultipart(request);
  }
  const result = await handleNewPhotoUpload(
    {
      method: request.method,
      headers: {
        origin: request.headers.get("origin") ?? "",
        authorization: request.headers.get("authorization") ?? ""
      },
      trustedSource: extractVerifiedPlatformSource(request),
      bodyTooLarge: parsed.bodyTooLarge === true,
      form: parsed.form ?? null
    },
    deps
  );
  return new Response(result.body === null ? null : JSON.stringify(result.body), {
    status: result.status,
    headers: { ...result.headers, "content-type": "application/json; charset=utf-8" }
  });
});
