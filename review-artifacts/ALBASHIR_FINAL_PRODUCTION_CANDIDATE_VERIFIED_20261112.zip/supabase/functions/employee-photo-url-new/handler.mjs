// Isolated first-time employee JPEG resolver. Original Production v2 untouched.
export const TTL_SECONDS=60;
const PATH=/^registrations\/[A-Za-z0-9_-]{1,64}\/[A-Za-z0-9-]{1,80}\.jpg$/;
const SAFE_ID=/^[A-Za-z0-9_-]{1,32}$/;
const MOBILE_MAX=64;
const deny=(status=403,cors={})=>({status,body:{ok:false,error:"DENIED"},headers:{"cache-control":"private, no-store",...cors}});
export function validEmployeeId(value){
  const id=String(value??"").trim();
  return Boolean(id)&&Array.from(id).length<=32&&!/[\u0000-\u001f\u007f]/.test(id);
}
export async function folderFor(id){
  if(!validEmployeeId(id))return "";
  const value=String(id).trim();
  if(SAFE_ID.test(value))return value;
  const h=await globalThis.crypto.subtle.digest("SHA-256",new TextEncoder().encode("employee-photo-folder-v1:"+value));
  return Array.from(new Uint8Array(h),b=>b.toString(16).padStart(2,"0")).join("");
}
const nonempty=(s,max)=>typeof s==="string"&&s.length>0&&s.length<=max;
export async function handleNewPhotoRequest(input,deps){
  const origin=String(input?.headers?.origin||"");
  const allowed=String(deps?.allowedOrigins||"").split(",").map(x=>x.trim()).filter(Boolean);
  const cors=allowed.includes(origin)?{
    "access-control-allow-origin":origin,
    "access-control-allow-methods":"POST, OPTIONS",
    "access-control-allow-headers":"apikey, authorization, content-type, x-client-info",
    "vary":"Origin"
  }:{};
  if(!allowed.includes(origin))return deny(403,cors);
  if(input?.method==="OPTIONS")return {status:204,body:null,headers:{...cors,"cache-control":"no-store"}};
  if(input?.method!=="POST")return deny(405,cors);
  const body=input?.body,actor=body?.actor;
  if(!body||typeof body!=="object"||Array.isArray(body)||body.action!=="resolve"||
     !actor||typeof actor!=="object"||Array.isArray(actor))return deny(403,cors);
  const type=String(actor.type||""),path=String(body.path??"");
  // Reject malformed/unknown actors BEFORE charging the global DB quota.
  // Origin is NOT authentication; this cheap gate limits trivial quota abuse.
  if(!["employee","employee_device","admin","guard_device","public_guard_session"].includes(type))
    return deny(403,cors);
  if(type==="employee"&&!nonempty(actor.mobile_number,MOBILE_MAX))return deny(403,cors);
  if(type==="employee_device"&&(!nonempty(actor.device_id,128)||!nonempty(actor.device_token,4096)))
    return deny(403,cors);
  if(type==="guard_device"&&(!nonempty(actor.device_code,128)||!nonempty(actor.device_token,4096)||
     !/^[0-9a-f]{64}$/.test(String(actor.read_key??""))))
    return deny(403,cors);
  if(type==="public_guard_session"&&!/^[0-9a-f]{64}$/.test(String(actor.read_key??"")))
    return deny(403,cors);
  if(type==="admin"){
    const bearer=String(input?.headers?.authorization??"").replace(/^Bearer\s+/i,"").trim();
    if(!nonempty(actor.access_token,4096)&&!nonempty(bearer,4096))return deny(403,cors);
  }
  let id=String(type==="employee"?actor.employee_id:(body.employee_id||actor.employee_id||"")).trim();
  if(!PATH.test(path))return deny(403,cors);
  if(!id && type==="employee_device" && typeof deps?.resolvePhotoOwnerByPath==="function"){
    try {
      const owner=await deps.resolvePhotoOwnerByPath(path);
      if(owner?.ok===true && validEmployeeId(owner.employeeId)) id=String(owner.employeeId).trim();
    } catch { return deny(503,cors); }
  }
  if(!validEmployeeId(id))return deny(403,cors);
  // An untrusted ID can select a rate bucket, NEVER authorize image access.
  // Authoritative SQL always checks this ID AND its exact attested photo path.
  if(path.split("/")[1]!==await folderFor(id))return deny(403,cors);
  try{
    // Quota precedes sensitive auth, Storage or URL signing for ALL actors.
    const admitted=await deps.admitRequest(id);
    if(admitted!==true)return deny(429,cors);
    // SECURITY / HISTORICAL ZERO-TOUCH: check exact NEW post-freeze
    // attested photo binding BEFORE calling any legacy auth RPC.
    // The original employee_profile_login RPC logs attempts and can
    // rate-limit historical employees. New-only endpoint requests
    // must not cause ANY legacy employee auth attempt or state change.
    // SQL attestation returns only a boolean; invalid, old and
    // unregistered IDs all receive the same opaque 403 response.
    if(await deps.verifyNewPhotoBinding(id,path)!==true)return deny(403,cors);
    let verified=false;
    if(type==="employee"){
      const mobile=actor.mobile_number;
      if(!nonempty(mobile,MOBILE_MAX))return deny(403,cors);
      const row=await deps.verifyEmployeeCredentials(id,mobile);
      verified=row?.ok===true&&row.employeeId===id&&row.photoPath===path;
    }else if(type==="employee_device"){
      if(!nonempty(actor.device_id,128)||!nonempty(actor.device_token,4096))return deny(403,cors);
      const row=await deps.verifyTrustedDevice(actor.device_token,actor.device_id);
      // Production's trusted-device RPC returns employee_id, NOT photoPath.
      // SQL binding below checks exact registered attested JPEG.
      verified=row?.ok===true&&row.employeeId===id;
    }else if(type==="admin"){
      const bearer=String(input?.headers?.authorization??"").replace(/^Bearer\s+/i,"").trim();
      const token=nonempty(actor.access_token,4096)?actor.access_token:bearer;
      if(!nonempty(token,4096))return deny(403,cors);
      const row=await deps.verifyAdmin(token);
      verified=row?.ok===true&&["SUPER_ADMIN","SUB_ADMIN"].includes(row.role);
    }else if(type==="guard_device"){
      if(!nonempty(actor.device_code,128)||!nonempty(actor.device_token,4096))return deny(403,cors);
      const row=await deps.verifyGateDevice(actor.device_code,actor.device_token);
      // Valid guard device alone does not authorize arbitrary new photo reads.
      // Require a matching, unexpired ALLOWED QR decision as well.
      if(row?.ok===true)
        verified=await deps.verifyAllowedGuardSession(actor.read_key,id,path)===true;
    }else if(type==="public_guard_session"){
      // A 256-bit read-key is a bearer capability, never trust path alone.
      if(!/^[0-9a-f]{64}$/.test(String(actor.read_key??"")))return deny(403,cors);
      // Never use the legacy resolver here: it can return a photo path
      // for any completed result, including DENIED. New-only is ALLOWED.
      verified=await deps.verifyAllowedGuardSession(actor.read_key,id,path)===true;
    }else return deny(403,cors);
    if(!verified)return deny(403,cors);
    // The global signed-URL budget is charged ONLY to authenticated,
    // new-only, exact-owner image requests. Failed passwords and forged
    // credentials may cost per-ID preflight, never the global budget.
    if(await deps.admitAuthenticatedRequest(id)!==true)return deny(429,cors);
    const signed=await deps.createSignedUrl(path,TTL_SECONDS);
    if(signed?.ok!==true||!nonempty(signed.url,8192))return deny(503,cors);
    return {status:200,body:{ok:true,url:signed.url,expires_in:TTL_SECONDS},
      headers:{"cache-control":"private, no-store",...cors}};
  }catch{return deny(503,cors);}
}
