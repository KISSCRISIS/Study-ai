// Standalone, opt-in Edge function. Do not deploy or point legacy clients
// here without a separate authorized release and dedicated rate limiting.
import {createClient} from "npm:@supabase/supabase-js@2.117.2";
import {handleNewPhotoRequest} from "./handler.mjs";
const URL_VALUE=Deno.env.get("SUPABASE_URL")??"";
const SERVICE_KEY=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")??"";
const ALLOWED=Deno.env.get("NEW_EMPLOYEE_PHOTO_ALLOWED_ORIGINS")??"";
const ANON_KEY=Deno.env.get("SUPABASE_ANON_KEY")??"";
if(!URL_VALUE||!SERVICE_KEY||!ALLOWED)throw new Error("New-only photo reader is disabled until approved configuration");
const admin=createClient(URL_VALUE,SERVICE_KEY,{
  auth:{autoRefreshToken:false,persistSession:false}
});
async function boundedBody(req:Request,max=4096){
  if(!req.body)return null;
  const reader=req.body.getReader();let chunks:Uint8Array[]=[],n=0;
  try {
    for(;;){
      const {done,value}=await reader.read();
      if(done)break;
      n+=value.byteLength;
      if(n>max){await reader.cancel();return null;}
      chunks.push(value);
    }
    const data=new Uint8Array(n);let offset=0;
    for(const c of chunks){data.set(c,offset);offset+=c.byteLength;}
    return JSON.parse(new TextDecoder().decode(data));
  }catch{return null;}finally{reader.releaseLock();}
}
// Authenticated users and admins are checked with ANON/publishable key,
// NEVER the service_role key in an end-user scoped Supabase client.
function userScopedClient(token:string){
  if(!ANON_KEY||!token)return null;
  return createClient(URL_VALUE,ANON_KEY,{
    auth:{autoRefreshToken:false,persistSession:false},
    global:{headers:{Authorization:"Bearer "+token}}
  });
}
const deps={
  allowedOrigins:ALLOWED,
  async admitRequest(employeeId:string){
    const {data,error}=await admin.rpc("new_employee_photo_view_admit",{
      p_employee_id:employeeId
    });
    const res=Array.isArray(data)?data[0]:data;
    return !error&&res?.ok===true;
  },
  async admitAuthenticatedRequest(employeeId:string){
    const {data,error}=await admin.rpc("new_employee_photo_signed_url_admit",{
      p_employee_id:employeeId
    });
    const value=Array.isArray(data)?data[0]:data;
    return !error&&value?.ok===true;
  },
  async verifyEmployeeCredentials(id:string,mobile:string){
    const {data,error}=await admin.rpc("employee_profile_login",{
      p_employee_id:id,p_mobile_number:mobile
    });
    const found=Array.isArray(data)?data[0]:data;
    if(error||found?.ok!==true)return {ok:false};
    return {ok:true,employeeId:String(found.profile?.employee_id??""),
      photoPath:String(found.profile?.employee_photo_url??"")};
  },
  async verifyTrustedDevice(token:string,deviceId:string){
    const {data,error}=await admin.rpc("verify_trusted_device_credentials",{
      p_device_token:token,p_device_id:deviceId
    });
    const row=Array.isArray(data)?data[0]:data;
    if(error||row?.ok!==true)return {ok:false};
    return {ok:true,employeeId:String(row.employee_id??""),
      photoPath:String(row.employee_photo_url??"")};
  },
  async verifyAdmin(token:string){
    const client=userScopedClient(token);
    if(!client)return {ok:false};
    const {data:user,error:userError}=await client.auth.getUser(token);
    if(userError||!user?.user)return {ok:false};
    const {data,error}=await client.rpc("get_my_admin_profile");
    const row=Array.isArray(data)?data[0]:data;
    return !error&&row?.ok===true?{ok:true,role:String(row.role??"")}:{ok:false};
  },
  async verifyGateDevice(code:string,token:string){
    const {data,error}=await admin.rpc("verify_gate_device_credentials",{
      p_device_code:code,p_device_token:token
    });
    const row=Array.isArray(data)?data[0]:data;
    return {ok:!error&&row?.ok===true};
  },
  async verifyAllowedGuardSession(key:string,employeeId:string,path:string){
    const {data,error}=await admin.rpc("resolve_new_allowed_guard_photo",{
      p_read_key:key,p_employee_id:employeeId,p_object_path:path
    });
    const value=Array.isArray(data)?data[0]:data;
    return !error&&value?.ok===true;
  },
    async resolvePhotoOwnerByPath(path:string){
    const {data,error}=await admin.rpc("lookup_attested_new_photo_owner",{
      p_object_path:path
    });
    const row=Array.isArray(data)?data[0]:data;
    if(error||row?.ok!==true)return {ok:false};
    return {ok:true,employeeId:String(row.employee_id??"")};
  },
    async verifyNewPhotoBinding(id:string,path:string){
    const {data,error}=await admin.rpc("resolve_attested_new_employee_photo",{
      p_employee_id:id,p_object_path:path
    });
    const row=Array.isArray(data)?data[0]:data;
    return !error&&row?.ok===true;
  },
  async createSignedUrl(path:string,seconds:number){
    const {data,error}=await admin.storage.from("employee-photos").createSignedUrl(path,seconds);
    if(error||!data?.signedUrl)return {ok:false};
    const url=new URL(data.signedUrl,URL_VALUE),project=new URL(URL_VALUE);
    if(url.hostname!==project.hostname||!url.pathname.startsWith("/storage/v1/object/sign/employee-photos/"))
      return {ok:false};
    return {ok:true,url:url.toString()};
  }
};
Deno.serve(async (request:Request)=>{
  const result=await handleNewPhotoRequest({
    method:request.method,
    headers:{origin:request.headers.get("origin")??"",
      authorization:request.headers.get("authorization")??""},
    body:request.method==="POST"?await boundedBody(request):null
  },deps);
  return new Response(result.body===null?null:JSON.stringify(result.body),{
    status:result.status,headers:{...result.headers,"content-type":"application/json; charset=utf-8"}
  });
});
