/**
 * Classify only known missing-object Storage errors.
 *
 * Supabase Storage's StorageApiError exposes the HTTP response code as
 * `status` (not `statusCode`). createSignedUrl may report a missing object
 * as HTTP 400 with a message such as "Object not found"; unrelated 400 errors
 * must remain signing failures.
 *
 * @param {unknown} error
 * @returns {boolean}
 */
export function isMissingStorageObject(error) {
  if (!error || typeof error !== "object") return false;

  const candidate = /** @type {{ status?: unknown, message?: unknown, error?: unknown, details?: unknown, code?: unknown }} */ (error);
  const status = Number(candidate.status);
  if (status === 404) return true;
  if (status !== 400) return false;

  const details = [
    candidate.message,
    candidate.error,
    candidate.details,
    candidate.code
  ].filter((value) => typeof value === "string").join(" ");

  return /(?:\b(?:object|file|key)\b[\s\S]{0,64}\b(?:not found|does not exist|missing)\b|\b(?:not found|does not exist)\b[\s\S]{0,64}\b(?:object|file|key)\b|\bmissing\b[\s\S]{0,64}\b(?:object|file|key)\b|\bno\s*such\s*key\b)/i.test(details);
}
