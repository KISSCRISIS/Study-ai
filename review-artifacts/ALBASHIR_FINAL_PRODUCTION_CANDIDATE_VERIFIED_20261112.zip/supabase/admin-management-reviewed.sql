-- Owner-approved administrator activation and recent connection. Additive, not a migration.
begin;
create table if not exists private.admin_connections (
 auth_user_id uuid primary key references auth.users(id) on delete cascade,
 last_seen timestamptz not null default now(), connected boolean not null default true
);
alter table private.admin_connections enable row level security;
revoke all on private.admin_connections from public,anon,authenticated;

create or replace function public.record_admin_connection(p_connected boolean default true)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if auth.uid() is null or not exists(select 1 from public.admin_profiles where auth_user_id=auth.uid() and is_active) then
  return jsonb_build_object('ok',false,'message','غير مصرح.');
 end if;
 insert into private.admin_connections(auth_user_id,last_seen,connected) values(auth.uid(),clock_timestamp(),coalesce(p_connected,false))
 on conflict(auth_user_id) do update set last_seen=case when excluded.connected then excluded.last_seen else admin_connections.last_seen end,connected=excluded.connected;
 delete from private.admin_connections where last_seen<now()-interval '30 days';
 return jsonb_build_object('ok',true);
end $$;

create or replace function public.super_admin_connections()
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if not public.is_super_admin() then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 return jsonb_build_object('ok',true,'server_now',clock_timestamp(),'admins',coalesce((
 select jsonb_agg(jsonb_build_object('auth_user_id',ap.auth_user_id,'full_name',ap.full_name,'email',ap.email,'role',ap.role,'is_active',ap.is_active,'last_seen',c.last_seen,
 'online',ap.is_active and coalesce(c.connected and c.last_seen>clock_timestamp()-interval '120 seconds',false)) order by ap.full_name)
 from public.admin_profiles ap left join private.admin_connections c on c.auth_user_id=ap.auth_user_id),'[]'::jsonb));
end $$;

create or replace function public.super_admin_assignment_accounts()
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if not public.is_super_admin() then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 return jsonb_build_object('ok',true,'assignments',coalesce((select jsonb_agg(jsonb_build_object(
 'id',a.id,'registration_id',r.id,'employee_id',r.employee_id,'full_name',r.full_name,'role',a.role,'permissions',a.permissions,'status',a.status,'employee_status',r.status,
 'email',coalesce(ap.email,p.email),'account_exists',exists(select 1 from auth.users u where lower(u.email)=p.email),'is_active',ap.is_active)
 order by a.created_at desc) from private.employee_admin_assignments a join public.employee_registrations r on r.id=a.registration_id
 left join public.admin_profiles ap on ap.auth_user_id=a.auth_user_id
 left join lateral(select lower(email) as email from private.employee_admin_proofs where assignment_id=a.id order by created_at desc limit 1) p on true),'[]'::jsonb));
end $$;

create or replace function public.super_admin_activate_employee_account(p_id uuid,p_email text)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare a private.employee_admin_assignments; r public.employee_registrations; u auth.users; mail text:=lower(trim(p_email));
begin
 if not public.is_super_admin() then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 perform pg_advisory_xact_lock(8101009);
 -- Recheck after the lock, in case the actor was disabled while waiting.
 perform 1 from public.admin_profiles where auth_user_id=auth.uid() and role='SUPER_ADMIN' and is_active for update;
 if not found then return jsonb_build_object('ok',false,'message','غير مصرح.'); end if;
 select * into a from private.employee_admin_assignments where id=p_id for update;
 if a.id is null then return jsonb_build_object('ok',false,'message','التعيين غير موجود.'); end if;
 if mail is null or length(mail)>254 or mail !~ '^[^[:space:]@]+@[^[:space:]@]+[.][^[:space:]@]+$' then return jsonb_build_object('ok',false,'message','أدخل بريد حساب الموظف الصحيح.'); end if;
 if (select count(*) from auth.users where lower(email)=mail)>1 then return jsonb_build_object('ok',false,'message','أكثر من حساب يحمل البريد؛ يحتاج مراجعة قبل الربط.'); end if;
 select * into u from auth.users where lower(email)=mail for update;
 if u.id is null then return jsonb_build_object('ok',false,'message','لم يسجل الموظف حسابًا بهذا البريد بعد. يسجل بيانات الدخول من ملفه الشخصي أولًا.'); end if;
 if a.status='ACTIVE' and a.auth_user_id=u.id and exists(select 1 from public.admin_profiles where auth_user_id=u.id and is_active) then
  return jsonb_build_object('ok',true,'message','الحساب مفعّل بالفعل.');
 end if;
 if a.status<>'PENDING' or a.auth_user_id is not null then return jsonb_build_object('ok',false,'message','التعيين غير متاح للتفعيل.'); end if;
 select * into r from public.employee_registrations where id=a.registration_id for update;
 if r.id is null or r.status<>'APPROVED' or a.role not in ('SUPER_ADMIN','SUB_ADMIN') then return jsonb_build_object('ok',false,'message','الموظف أو الدور غير صالح للتفعيل.'); end if;
 perform 1 from public.admin_profiles where auth_user_id=a.assigned_by and role='SUPER_ADMIN' and is_active for update;
 if not found then return jsonb_build_object('ok',false,'message','المشرف الذي أنشأ التعيين لم يعد مفعّلًا.'); end if;
 if coalesce(length(u.encrypted_password),0)=0 or (u.banned_until is not null and u.banned_until>now()) then return jsonb_build_object('ok',false,'message','الحساب لا يدعم الدخول بكلمة مرور أو محظور.'); end if;
 if exists(select 1 from public.admin_profiles where auth_user_id=u.id or lower(email)=mail)
 or exists(select 1 from private.employee_admin_assignments where auth_user_id=u.id and id<>a.id and status in ('PENDING','ACTIVE')) then
  return jsonb_build_object('ok',false,'message','البريد مرتبط بحساب إدارة آخر؛ لا يمكن إعادة ربطه.');
 end if;
 -- Explicit owner confirmation of the employee/account binding; the password hash is not changed or returned.
 update auth.users set email_confirmed_at=coalesce(email_confirmed_at,now()),updated_at=now() where id=u.id;
 insert into public.admin_profiles(auth_user_id,email,full_name,phone_number,role,is_active,permissions)
 values(u.id,mail,r.full_name,r.mobile_number,a.role,true,a.permissions);
 update private.employee_admin_assignments set status='ACTIVE',auth_user_id=u.id,activated_at=now() where id=a.id;
 update private.employee_admin_proofs set consumed_at=now() where assignment_id=a.id and consumed_at is null;
 insert into public.admin_audit_logs(admin_auth_user_id,action,target_table,target_id,details)
 values(auth.uid(),'APPROVE_EMPLOYEE_ADMIN_ACCOUNT','employee_admin_assignments',a.id::text,jsonb_build_object('employee_id',r.employee_id,'auth_user_id',u.id,'role',a.role,'approval_method','super_admin_confirmed_binding','password_changed',false));
 return jsonb_build_object('ok',true,'message','تم اعتماد الربط وتفعيل الحساب. يدخل الموظف ببريده وكلمة مروره الحالية دون رسالة تأكيد.');
end $$;

revoke all on function public.record_admin_connection(boolean) from public,anon;
revoke all on function public.super_admin_connections() from public,anon;
revoke all on function public.super_admin_assignment_accounts() from public,anon;
revoke all on function public.super_admin_activate_employee_account(uuid,text) from public,anon;
grant execute on function public.record_admin_connection(boolean),public.super_admin_connections(),public.super_admin_assignment_accounts(),public.super_admin_activate_employee_account(uuid,text) to authenticated;
commit;
