# Live backend source references

The dated Production and Staging JSON catalogs preserve inspected live function definitions, explicit routine ACLs, application table/column metadata, selected RLS policies and private-bucket configuration in the unified repository. They contain no employee rows, passwords, sessions or browser keys. Credential-pattern scanning was performed before saving them.

These are non-executable review references. They do not replace ordered migrations, full schema dumps, effective-privilege tests, Edge Function source reconciliation or recoverable data backups. Nothing imports them into the application build or database. Do not automatically generate or apply SQL from these snapshots. Confirm differences against the live system again before any future change.

At capture time, lexical inspection found 39 Production routine names not referenced by existing repository SQL, notably guard management, emergency entry, employee admin appointments and admin notices. Preserving their actual definitions here avoids relying on an old working directory for source review. Matching names or bodies does not establish correct install order or schema recovery.

See [backend review](../../docs/BACKEND_UNIFICATION_REVIEW_20261011.md) for environment differences and unresolved recovery/archival prerequisites. The application artifact excludes this entire directory.
